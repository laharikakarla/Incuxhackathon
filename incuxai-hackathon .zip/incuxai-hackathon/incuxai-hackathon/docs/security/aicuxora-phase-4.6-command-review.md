# AICUXORA Phase 4.6 — Read-Only Validation Command Review

**Review type:** Static review and correction of the proposed command sequence. No command was executed and no Supabase project was contacted.  
**Permitted database target:** `incuxai-hackathon-validation` (`bhnhhaurdnnalcozsviq`), region `ap-south-1`.  
**Decision:** **READY FOR OPERATOR APPROVAL** of the corrected read-only sequence in this document only. This is not approval to run mutations, migration probes, or the uncorrected grant-option diagnostic from Phase 4.5.

## 1. Executive review

The Phase 4.5 sheet is structurally useful and its `db query --remote=<ref> --read-only` form is consistent with the repository's Supabase CLI 3.1.0 records and current official CLI reference. It correctly separates `session_user` and `current_user`, uses the correct direction for role memberships, and treats `migration list` as a history listing rather than a schema inventory.

One query requires correction before execution: Phase 4.5 calls `has_schema_privilege(..., 'CREATE WITH GRANT OPTION')`. PostgreSQL 17 permits only `CREATE` and `USAGE` for `has_schema_privilege`; grant-option status is instead reported by the schema ACL's `aclexplode(...).is_grantable`. The corrected sequence below removes the invalid inquiry and explicitly separates effective CREATE from direct ACL grantability.

The Phase 4.5 sheet's local target-string guard does not verify the remote project. This sequence first runs account-level `supabase projects list` and requires the operator to match the disposable name/ref, plus independently verify the region in Dashboard, before any SQL query. Official CLI documentation says `projects list` lists projects visible to the signed-in user and is an account-level command with no project target. It does not connect to a database. Since it lists all accessible projects, the PowerShell step prints only the matching disposable row.

The Phase 4.5 collision check only covers legacy Phase 2.6 names. The current authoritative architecture does not specify exact Phase 4.3 test fixture names or exact custom runtime role names. Those names remain unresolved; no names are approved or invented here.

## 2. Command-by-command review of Phase 4.5

| Phase 4.5 command/query | Review result | Correction or limit |
|---|---|---|
| Local target-variable assertion | PowerShell syntax is valid; local-only. | It checks a literal against itself and cannot verify the remote project. Keep only as a guard; use command 2 below before any DB query. |
| CLI version/help checks | Valid local CLI invocations; no DB target. | Keep. Help output must be checked before remote commands. Exact authentication scope names are not stated by local docs and must not be guessed. |
| Identity/version SELECT | PostgreSQL 17 syntax valid and read-only. | Keep; the CLI-resolved target line is printed during the request, so Dashboard and account project-list confirmation must occur before this query. It proves only the identity of this query route. |
| Role inventory from `pg_roles` | PostgreSQL 17 column names are valid. It omits password fields. | Keep. Missing rows are not proof of absence unless catalog visibility is adequate. |
| Direct memberships from `pg_auth_members` | PostgreSQL 17 includes `grantor`, `admin_option`, `inherit_option`, and `set_option`. Direction is correct: `member` receives membership in `roleid`. | Keep. A direct-edge listing is not a transitive analysis. |
| Recursive membership paths / `pg_has_role` | CTE structure, cycle prevention and `MEMBER`/`USAGE`/`SET` inquiries are valid for PostgreSQL 17. The query records grantor and edge options. | Corrected sequence adds `MEMBER WITH ADMIN OPTION` inquiry. `all_inherit_options` is only a path-edge summary; use `pg_has_role(...,'USAGE')` for PostgreSQL's effective inheritance inquiry. A principal absent from roots must be distinguished using role inventory. |
| Schema/database ACL expansion | `aclexplode`, `acldefault('n')` for schema and `acldefault('d')` for database are valid. `is_grantable` records direct ACL grant-option state. | Keep, with limits: direct ACL options are not a general proof of the actual migration operator's authority. |
| Effective privilege query | Most inquiries are valid. **Defect:** `has_schema_privilege` does not accept `CREATE WITH GRANT OPTION`. | Corrected below: use `has_schema_privilege(...,'CREATE')` for effective CREATE. Inspect direct schema ACL rows for `privilege_type='CREATE' AND is_grantable`. Do not label that direct result as effective grantor capability for an unknown operator. |
| Private schema query | Valid catalog `SELECT`. | Keep. A zero-row result is only absence of that exact namespace in visible catalogs. |
| Migration history relation + `migration list` | Catalog query is read-only. CLI `migration list --remote=<ref>` is documented as listing local migration files against remote history. | Keep. No `--read-only` flag is documented for `migration list`; do not infer schema emptiness from an empty comparison. Inspect local help first. |
| Legacy fixture collision query | `to_regclass`/`to_regprocedure` and role `EXISTS` checks are read-only. | Keep only as legacy-name checks. The names do not constitute the missing Phase 4.3 fixture manifest. |
| Function owner/security/ACL query | PostgreSQL 17 catalog columns, `pg_get_function_identity_arguments`, `pg_get_function_result`, `acldefault('f')`, and `aclexplode` are appropriate for function/procedure inventory. | Keep. It inventories metadata and EXECUTE ACLs, not function-body safety or nested calls. |
| RLS policy inventory | `pg_policies` column names are valid. | Do not return raw `qual` or `with_check` expressions in an operational evidence transcript; those SQL expressions are unnecessary for a first inventory and could contain inappropriate literals. Corrected version returns booleans indicating whether expressions exist. This cannot validate policy semantics. |
| Table RLS flags | `relrowsecurity` and `relforcerowsecurity` are valid `pg_class` fields. | Keep; flags do not prove policy correctness or absence of bypass. |
| Audit/outbox relations and triggers | The relation pattern query is read-only. `pg_get_triggerdef` itself is read-only but returns full SQL expressions. | Corrected version reports trigger/function metadata but omits trigger definitions to minimize output. Name-pattern matches cannot prove absence under other names. |
| Migration listing interpretation | Correctly warns that an empty migration comparison does not mean the schema is empty. | Keep. The CLI compares migration timestamps; it does not establish migration execution identity. |

### PostgreSQL grant-option correction

The PostgreSQL 17 documentation lists only `CREATE` and `USAGE` as allowed `has_schema_privilege` privilege types; database inquiries allow `CREATE`, `CONNECT`, and `TEMPORARY`/`TEMP`. `WITH GRANT OPTION` belongs to the ACL representation/role-admin inquiry, not the schema privilege inquiry argument. Thus the Phase 4.5 expression with `'CREATE WITH GRANT OPTION'` is invalid and would fail the query rather than return a safe false. The reviewed command below corrects it.

## 3. Exact safe command sequence

Run in PowerShell from the repository root. The sequence is ordered so the remote project's name and reference are confirmed before any database query. Each `db query` includes the literal disposable reference and `--read-only`. Stop immediately on any mismatch or nonzero exit.

### Command 1 — Confirm local CLI version and syntax

```powershell
$ErrorActionPreference = 'Stop'
$env:SUPABASE_TELEMETRY_DISABLED = '1'
$env:SUPABASE_DISABLE_TELEMETRY = '1'
npx --no-install supabase --version
if ($LASTEXITCODE -ne 0) { throw 'CLI version check failed.' }
npx --no-install supabase projects list --help
if ($LASTEXITCODE -ne 0) { throw 'Could not verify projects list syntax.' }
npx --no-install supabase db query --help
if ($LASTEXITCODE -ne 0) { throw 'Could not verify db query syntax.' }
npx --no-install supabase migration list --help
if ($LASTEXITCODE -ne 0) { throw 'Could not verify migration list syntax.' }
```

**Purpose:** Verify the installed CLI/version and the exact local command forms first.  
**Expected:** CLI version; project-list, db-query, migration-list help. Prior repository evidence says version 3.1.0; if current output differs, stop and re-review syntax.  
**Proves:** local CLI binary/help only. **Does not prove:** project access, remote identity, SQL behavior or migration identity.  
**Failure:** stop; do not guess flags. **Read-only:** local metadata/help only. **Target:** none; no remote request or DB query. **Authentication:** none expected. This command must not print credentials.

### Command 2 — Resolve the disposable project before SQL

First independently confirm in Dashboard that the selected project is named `incuxai-hackathon-validation`, has reference `bhnhhaurdnnalcozsviq`, and is in `ap-south-1`. Then run:

```powershell
$expectedRef = 'bhnhhaurdnnalcozsviq'
$projects = npx --no-install supabase projects list
if ($LASTEXITCODE -ne 0) { throw 'Project listing failed; do not run database queries.' }
$targetRows = @($projects | Select-String -SimpleMatch $expectedRef)
if ($targetRows.Count -ne 1) { throw 'Expected exactly one disposable project row; stop and verify in Dashboard.' }
$targetRows | ForEach-Object { $_.Line }
```

**Purpose:** Confirm the signed-in CLI account can see the exact authorized reference; print only its matching row.  
**Expected:** exactly one row containing `bhnhhaurdnnalcozsviq`; operator confirms its name matches the disposable project and its region matches Dashboard. If the CLI output does not include sufficient name/ref information or the line is wrapped, stop and use Dashboard/manual review rather than guessing.  
**Proves:** the account-level project listing contains one matching ref.  
**Does not prove:** a database connection, database identity, actual region unless the row reports it, or any migration identity. It lists project metadata, not a database.  
**Failure:** no SQL has run; stop. **Read-only:** yes, account-level listing. **Target:** account-level list, no project/database target. This command does not act on production; it may enumerate account project metadata, and the script prints only the disposable row. **Authentication:** signed-in CLI account with project-list visibility; exact API scope names are not specified in inspected CLI docs.

### Command 3 — Database identity and PostgreSQL version

Only after command 2 and Dashboard confirmation pass:

```powershell
$sql = @'
SELECT current_database() AS database_name,
       session_user AS session_user,
       current_user AS current_user,
       current_setting('server_version') AS server_version,
       current_setting('server_version_num') AS server_version_num;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Identity/version query failed; stop.' }
```

**Purpose:** Establish the current remote query target/SQL identity and PostgreSQL version.  
**Expected:** CLI `Target:` output names `incuxai-hackathon-validation` and exact ref before the result; one SQL row. Reconfirm the exact target in captured output.  
**Proves:** identity/version only for this `db query` connection; `session_user` is the login, `current_user` is the effective statement identity.  
**Does not prove:** CLI account identity equals either DB identity; migration `session_user/current_user`; object owner; subsequent migration identity.  
**Failure:** no result means unknown; stop. If target output mismatch, stop and do not run further commands. **Read-only:** yes (`SELECT`, `--read-only`). **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** CLI access to this project and a database query identity permitted to execute the select.

### Command 4 — Role attributes

```powershell
$sql = @'
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb,
       rolreplication, rolbypassrls, rolcanlogin, rolconnlimit
FROM pg_catalog.pg_roles
ORDER BY rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Role inventory failed; stop.' }
```

**Purpose:** Inventory visible role attributes without selecting credential fields.  
**Expected:** rows for visible database roles, including API/platform roles if catalog visibility permits.  
**Proves:** returned role attributes. **Does not prove:** membership or privilege paths, complete catalog visibility, or migration identity.  
**Failure/omission:** treat missing roles or incomplete output as unknown; compare against successful query identity and permission visibility. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** remote query access and relevant catalog visibility.

### Command 5 — Direct membership edges

```powershell
$sql = @'
SELECT member_role.rolname AS member_role,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       m.admin_option, m.inherit_option, m.set_option
FROM pg_catalog.pg_auth_members AS m
JOIN pg_catalog.pg_roles AS member_role ON member_role.oid = m.member
JOIN pg_catalog.pg_roles AS granted_role ON granted_role.oid = m.roleid
JOIN pg_catalog.pg_roles AS grantor_role ON grantor_role.oid = m.grantor
ORDER BY member_role.rolname, granted_role.rolname, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Direct membership inventory failed; stop.' }
```

**Purpose:** Show every direct visible membership, grantor, and PostgreSQL 17 membership option.  
**Expected:** one row per direct membership edge. `member_role` is granted membership in `granted_role`; direction is not reversible.  
**Proves:** direct visible edges only. **Does not prove:** reachability or effective privileges. Use command 6 for listed roots.  
**Failure/empty:** failure is unknown; empty is not proof of no memberships unless role/catalog visibility is adequate. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 6 — Transitive membership, INHERIT, SET and ADMIN reachability

```powershell
$sql = @'
WITH RECURSIVE principals(rolname) AS (
  VALUES ('postgres'::name), ('anon'::name), ('authenticated'::name),
         ('authenticator'::name), ('service_role'::name),
         ('supabase_read_only_user'::name), ('supabase_privileged_role'::name),
         ('supabase_admin'::name), ('supabase_etl_admin'::name)
), roots AS (
  SELECT r.oid AS root_oid, r.rolname AS root_name, r.rolinherit AS root_inherit
  FROM principals p JOIN pg_catalog.pg_roles r ON r.rolname = p.rolname
), role_paths(
  root_oid, root_name, root_inherit, member_oid, granted_role_oid, grantor_oid,
  depth, oid_path, admin_option, inherit_option, set_option,
  all_inherit_options, all_set_options
) AS (
  SELECT roots.root_oid, roots.root_name, roots.root_inherit,
         m.member, m.roleid, m.grantor, 1,
         ARRAY[m.member, m.roleid]::oid[],
         m.admin_option, m.inherit_option, m.set_option,
         m.inherit_option, m.set_option
  FROM roots JOIN pg_catalog.pg_auth_members m ON m.member = roots.root_oid
  UNION ALL
  SELECT p.root_oid, p.root_name, p.root_inherit,
         m.member, m.roleid, m.grantor, p.depth + 1,
         p.oid_path || m.roleid,
         m.admin_option, m.inherit_option, m.set_option,
         p.all_inherit_options AND m.inherit_option,
         p.all_set_options AND m.set_option
  FROM role_paths p
  JOIN pg_catalog.pg_auth_members m ON m.member = p.granted_role_oid
  WHERE NOT m.roleid = ANY (p.oid_path)
)
SELECT p.root_name AS starting_principal,
       p.root_inherit AS starting_role_rolinherit,
       p.depth,
       member_role.rolname AS membership_member,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       p.admin_option, p.inherit_option, p.set_option,
       p.all_inherit_options AS all_edges_inherit,
       p.all_set_options AS all_edges_set,
       pg_has_role(p.root_oid, p.granted_role_oid, 'MEMBER') AS reachable_membership,
       pg_has_role(p.root_oid, p.granted_role_oid, 'USAGE') AS effective_inherited_privileges,
       pg_has_role(p.root_oid, p.granted_role_oid, 'SET') AS can_set_role,
       pg_has_role(p.root_oid, p.granted_role_oid, 'MEMBER WITH ADMIN OPTION') AS can_administer_membership,
       granted_role.rolsuper, granted_role.rolcreaterole,
       granted_role.rolcreatedb, granted_role.rolbypassrls
FROM role_paths p
JOIN pg_catalog.pg_roles member_role ON member_role.oid = p.member_oid
JOIN pg_catalog.pg_roles granted_role ON granted_role.oid = p.granted_role_oid
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = p.grantor_oid
ORDER BY p.root_name, p.depth, member_role.rolname, granted_role.rolname, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Membership-path query failed; stop.' }
```

**Purpose:** Trace direct/transitive membership from specified existing principals, preserving edge grantor/options and asking PostgreSQL for effective membership, inheritance, SET and ADMIN inquiry.  
**Expected:** path rows for reachable memberships. `all_edges_inherit/set` are simple path-edge summaries; `pg_has_role(...,'USAGE'/'SET')` is the effective inquiry.  
**Proves:** only graph paths rooted in principals present in role inventory.  
**Does not prove:** paths from an unlisted newly discovered principal, object privileges, or migration identity. The current domain-owner and runtime role names are not specified; add them only after an approved role manifest.  
**Failure/missing root:** compare against command 4; missing root is not a negative permission result. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility and PostgreSQL inquiry functions.

### Command 7 — Schema ownership and direct schema ACLs

```powershell
$sql = @'
SELECT n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       CASE WHEN x.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS grantee,
       grantor_role.rolname AS grantor,
       x.privilege_type,
       x.is_grantable
FROM pg_catalog.pg_namespace n
CROSS JOIN LATERAL aclexplode(COALESCE(n.nspacl, acldefault('n', n.nspowner))) x
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = x.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = x.grantor
WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
ORDER BY n.nspname, grantee, x.privilege_type, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Schema ACL query failed; stop.' }
```

**Purpose:** Inventory schema owners, direct ACL grantors, privilege types and grantability.  
**Expected:** ACL rows for visible user schemas. `privilege_type='CREATE'` plus `is_grantable=true` is evidence of a grantable CREATE entry for that ACL grantee.  
**Proves:** direct catalog ACL entries, including defaults expanded when ACL is NULL. **Does not prove:** actual migration operator authority until its identity is known; owner/role memberships or every effective path.  
**Failure/incomplete visibility:** unknown; stop. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility and `aclexplode`.

### Command 8 — Database ownership and direct ACLs

```powershell
$sql = @'
SELECT d.datname AS database_name,
       pg_get_userbyid(d.datdba) AS database_owner,
       CASE WHEN x.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS grantee,
       grantor_role.rolname AS grantor,
       x.privilege_type,
       x.is_grantable
FROM pg_catalog.pg_database d
CROSS JOIN LATERAL aclexplode(COALESCE(d.datacl, acldefault('d', d.datdba))) x
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = x.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = x.grantor
WHERE d.datname = current_database()
ORDER BY grantee, x.privilege_type, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Database ACL query failed; stop.' }
```

**Purpose:** Show database owner and direct database ACL grants for current database.  
**Expected:** current DB rows including CONNECT/CREATE/TEMPORARY where present and grant-option metadata.  
**Proves:** direct ACL entries; **does not prove:** effective privileges or grantor ability for an unknown migration operator.  
**Failure:** unknown. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 9 — Effective schema and database privileges

```powershell
$sql = @'
SELECT r.rolname AS checked_role,
       n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       has_schema_privilege(r.oid, n.oid, 'USAGE') AS effective_usage,
       has_schema_privilege(r.oid, n.oid, 'CREATE') AS effective_create,
       has_database_privilege(r.oid, current_database(), 'CONNECT') AS effective_db_connect,
       has_database_privilege(r.oid, current_database(), 'CREATE') AS effective_db_create,
       has_database_privilege(r.oid, current_database(), 'TEMPORARY') AS effective_db_temp
FROM pg_catalog.pg_roles r
CROSS JOIN pg_catalog.pg_namespace n
WHERE r.rolname IN ('postgres','anon','authenticated','authenticator','service_role',
                    'supabase_read_only_user','supabase_privileged_role',
                    'supabase_admin','supabase_etl_admin')
  AND n.nspname IN ('public','private','auth','extensions','supabase_migrations')
ORDER BY r.rolname, n.nspname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Effective privilege query failed; stop.' }
```

**Purpose:** Ask PostgreSQL for effective `USAGE`/`CREATE` on named schemas and `CONNECT`/`CREATE`/`TEMPORARY` on the current database.  
**Expected:** rows only for named roles/schemas that exist and are visible. `postgres` is included as a historically discussed candidate, not assumed to be the migration operator.  
**Proves:** effective privileges for returned named role/schema pairs. **Does not prove:** any grant option, actual migration identity, future `GRANT`/ownership-transfer feasibility, or role paths for unlisted roles. Direct schema grantability is command 7, not this inquiry.  
**Failure/missing role:** compare with role inventory; absent rows are unknown, not false. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility and privilege inquiry functions.

### Command 10 — Private schema existence and owner

```powershell
$sql = @'
SELECT n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       n.nspacl IS NULL AS uses_default_acl
FROM pg_catalog.pg_namespace n
WHERE n.nspname = 'private';
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Private schema query failed; stop.' }
```

**Purpose:** Check exact `private` namespace presence/owner. **Expected:** one row if present, zero if absent and catalog visibility is sufficient. **Proves:** only that exact namespace. **Does not prove:** no private schema under another name or its access controls. **Failure/zero rows:** failure is unknown; zero rows requires catalog visibility comparison. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 11 — Migration-history relation existence

```powershell
$sql = @'
SELECT n.nspname AS schema_name, c.relname, c.relkind,
       pg_get_userbyid(c.relowner) AS relation_owner
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'supabase_migrations'
  AND c.relname = 'schema_migrations';
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Migration-history relation query failed; stop.' }
```

**Purpose:** Check existence/owner of the conventional migration history relation without querying an absent table. **Expected:** one row if it exists. **Proves:** only this relation. **Does not prove:** migration records, schema completeness, or migration identity. **Failure/zero rows:** unknown/absent exact relation; continue only after review. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 12 — Migration history listing

```powershell
npx --no-install supabase migration list --remote=bhnhhaurdnnalcozsviq
if ($LASTEXITCODE -ne 0) { throw 'Migration list failed; history is unknown.' }
```

**Purpose:** Compare local migration files with this explicit remote project's migration history. **Expected:** local/remote version listing. **Proves:** only migration timestamps reported by CLI. **Does not prove:** database schema is empty if history is empty; history may be absent/incomplete while objects exist. Does not establish migration identity.  
**Failure:** history unknown; do not run migration repair/push. **Read-only:** official CLI documentation defines `migration list` as listing local files beside target history; no migration is applied. No `--read-only` flag is documented for this command. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** CLI authenticated project access and the read route used by this command; it may differ from `db query`.

### Command 13 — Known legacy fixture collisions

```powershell
$sql = @'
SELECT 'role: incux_rpc_owner' AS object_name,
       EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'incux_rpc_owner') AS already_exists
UNION ALL
SELECT 'table: public.phase_2_6_validation_table',
       to_regclass('public.phase_2_6_validation_table') IS NOT NULL
UNION ALL
SELECT 'view: public.phase_2_6_validation_view',
       to_regclass('public.phase_2_6_validation_view') IS NOT NULL
UNION ALL
SELECT 'function: public.phase_2_6_validation_rpc()',
       to_regprocedure('public.phase_2_6_validation_rpc()') IS NOT NULL
UNION ALL
SELECT 'view: private.phase_2_6_validation_view',
       to_regclass('private.phase_2_6_validation_view') IS NOT NULL
UNION ALL
SELECT 'function: private.phase_2_6_validation_rpc()',
       to_regprocedure('private.phase_2_6_validation_rpc()') IS NOT NULL;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Legacy collision query failed; stop.' }
```

**Purpose:** Check only previously documented Phase 2.6 legacy names. **Expected:** six rows with Boolean collision values. **Proves:** exact role/object names are resolvable or not. **Does not prove:** absence of overloads or any future Phase 4.3 fixture/runtime role collision. The Phase 4.3 names remain unresolved; do not use these legacy names as new test fixtures. **Failure:** unknown; no cleanup. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog lookup access.

### Command 14 — Function ownership, security attributes and EXECUTE grants

```powershell
$sql = @'
SELECT n.nspname AS function_schema,
       p.proname AS function_name,
       pg_get_function_identity_arguments(p.oid) AS identity_arguments,
       pg_get_function_result(p.oid) AS result_type,
       pg_get_userbyid(p.proowner) AS function_owner,
       p.prosecdef AS security_definer,
       p.provolatile AS volatility,
       p.proconfig AS function_settings,
       CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS execute_grantee,
       grantor_role.rolname AS acl_grantor,
       a.privilege_type,
       a.is_grantable
FROM pg_catalog.pg_proc p
JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) a
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = a.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = a.grantor
WHERE n.nspname IN ('public','private')
  AND p.prokind IN ('f','p')
ORDER BY n.nspname, p.proname, pg_get_function_identity_arguments(p.oid), execute_grantee;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Function inventory failed; stop.' }
```

**Purpose:** Inventory public/private function/procedure owner, signature, SECURITY DEFINER status, settings and effective EXECUTE ACL entries (defaults expanded). **Expected:** metadata rows for visible routines. **Proves:** catalog metadata/ACL only. **Does not prove:** body safety, nested calls, dynamic SQL, caller authorization or trigger attachment. No function bodies are selected. **Failure/incomplete output:** unknown. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog and ACL visibility.

### Command 15 — RLS policy metadata without returning policy expressions

```powershell
$sql = @'
SELECT schemaname, tablename, policyname, permissive, roles, cmd,
       (qual IS NOT NULL) AS has_using_expression,
       (with_check IS NOT NULL) AS has_check_expression
FROM pg_catalog.pg_policies
WHERE schemaname NOT IN ('pg_catalog','information_schema')
ORDER BY schemaname, tablename, policyname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'RLS policy inventory failed; stop.' }
```

**Purpose:** List visible policy names, roles, command and whether USING/WITH CHECK expressions exist, without printing expression bodies. **Expected:** one row per visible policy. **Proves:** metadata for policies visible through `pg_policies`. **Does not prove:** RLS enabled/forced, policy expression correctness, grant safety or policy behavior under JWT. Empty output is not proof of safety. **Failure/empty:** unknown until catalog visibility and RLS flags are reviewed. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 16 — Table RLS flags

```powershell
$sql = @'
SELECT n.nspname AS table_schema,
       c.relname AS table_name,
       pg_get_userbyid(c.relowner) AS table_owner,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind IN ('r','p')
  AND n.nspname NOT IN ('pg_catalog','information_schema')
ORDER BY n.nspname, c.relname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'RLS flag inventory failed; stop.' }
```

**Purpose:** Independently list ordinary/partitioned table ownership and RLS/force flags. **Expected:** visible table rows and Boolean flags. **Proves:** catalog flags only. **Does not prove:** correct policies, bypass-role absence, views or actual row filtering. **Failure/incomplete output:** unknown. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 17 — Audit/outbox/webhook relation names

```powershell
$sql = @'
SELECT n.nspname AS object_schema,
       c.relname AS object_name,
       c.relkind AS relation_kind,
       pg_get_userbyid(c.relowner) AS object_owner,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname NOT IN ('pg_catalog','information_schema')
  AND (lower(c.relname) LIKE '%audit%'
       OR lower(c.relname) LIKE '%outbox%'
       OR lower(c.relname) LIKE '%inbox%'
       OR lower(c.relname) LIKE '%webhook%')
ORDER BY n.nspname, c.relname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Audit/outbox relation inventory failed; stop.' }
```

**Purpose:** Find name-matching relations and ownership/RLS metadata. **Expected:** any visible relation whose name matches audit/outbox/inbox/webhook. **Proves:** matching names only. **Does not prove:** no differently named infrastructure exists or that any found object is secure/functional. **Failure/empty:** unknown/no matching visible names; inspect schema inventory and approved object manifest before concluding absence. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

### Command 18 — Noninternal trigger metadata

```powershell
$sql = @'
SELECT table_schema.nspname AS table_schema,
       table_rel.relname AS table_name,
       trigger_def.tgname AS trigger_name,
       trigger_def.tgenabled AS trigger_enabled_state,
       function_schema.nspname AS function_schema,
       trigger_func.proname AS trigger_function,
       pg_get_userbyid(trigger_func.proowner) AS trigger_function_owner,
       trigger_func.prosecdef AS trigger_security_definer
FROM pg_catalog.pg_trigger trigger_def
JOIN pg_catalog.pg_class table_rel ON table_rel.oid = trigger_def.tgrelid
JOIN pg_catalog.pg_namespace table_schema ON table_schema.oid = table_rel.relnamespace
JOIN pg_catalog.pg_proc trigger_func ON trigger_func.oid = trigger_def.tgfoid
JOIN pg_catalog.pg_namespace function_schema ON function_schema.oid = trigger_func.pronamespace
WHERE NOT trigger_def.tgisinternal
  AND table_schema.nspname NOT IN ('pg_catalog','information_schema')
ORDER BY table_schema.nspname, table_rel.relname, trigger_def.tgname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Trigger metadata inventory failed; stop.' }
```

**Purpose:** Inventory user-defined trigger names, enabled state, trigger-function owner and SECURITY DEFINER flag without returning trigger SQL/body. **Expected:** metadata for visible noninternal triggers. **Proves:** trigger catalog metadata only. **Does not prove:** function behavior, actor authenticity, event coverage, or that no trigger is hidden by catalog visibility. **Failure/empty:** unknown until visibility is confirmed. **Read-only:** yes. **Target:** explicit `--remote=bhnhhaurdnnalcozsviq`. **Authentication:** catalog visibility.

## 4. Fixture and runtime identity names

The authoritative architecture intentionally requires domain owners and distinct system logins only after feasibility is proven, but does not specify exact names. Phase 4.3 requires exact test manifests but leaves them unresolved. The only exact legacy names found in prior validation files are `incux_rpc_owner`, `phase_2_6_validation_table`, `phase_2_6_validation_view`, `phase_2_6_validation_rpc()`, and private equivalents. These are collision-check targets only and must not be reused as approved Phase 4.3 fixtures.

**No authoritative Phase 4.3 fixture names or runtime role names are available.** Do not silently assign production role names here. For a future disposable test manifest, a naming convention may be proposed as `aicuxora_v46_probe_<purpose>_<unique-suffix>` for objects and `aicuxora_v46_test_<domain>_<unique-suffix>` for temporary roles. That is a naming recommendation only; names and cleanup ownership require operator/reviewer approval before a collision query or mutation.

Runtime domains mentioned conceptually in Phase 2.14.4 include payment, notification and scheduled/team workflows. They are not exact role names and do not imply that all need separate logins. The final count/names must follow the per-operation manifest.

## 5. CLI identity and permissions

- `supabase projects list` uses the signed-in Supabase CLI account and project-list visibility. It is account-level and has no target; it is not a database connection.
- `supabase db query --remote=<ref> --read-only` uses Supabase CLI access to resolve the explicit project and a database query route/identity. The exact database role and permission set are project-dependent. It executes a read-only query only.
- `supabase migration list --remote=<ref>` reads local migration files and the target's migration history. It may use a route different from `db query`. It does not apply SQL and cannot establish migration execution identity.
- PostgreSQL `session_user` is the login for the query connection; `current_user` is the effective SQL identity. A `SECURITY DEFINER` function changes `current_user` while it runs. Neither a CLI account nor this query's DB identity proves the identity used later by migrations.
- Exact OAuth scope names are not specified by the inspected local records or CLI help; do not invent them. An authentication error or catalog permission error is an unknown result, not a failed privilege assertion.

## 6. Remaining uncertainty and safety limits

- Current target name/ref/region are not freshly verified. The operator must do Dashboard plus command 2 before SQL.
- Project listing output must contain exactly one matching reference. The Dashboard remains authoritative for region.
- The historical CLI environment label `production` must be understood if it appears again; stop on ambiguity despite explicit ref.
- Role catalog visibility and system-catalog permissions may vary. Empty results never imply denial/absence without successful query and visibility evidence.
- Direct `is_grantable` ACL entries do not prove the unknown migration operator can grant/transfer ownership; migration operator remains unknown.
- Empty migration history does not prove empty schema.
- Function metadata and RLS metadata do not validate function bodies/policy semantics.
- Pattern-based audit/outbox names do not prove absence of infrastructure under different names.
- This review does not test PostgreSQL syntax by execution; syntax was checked statically against PostgreSQL 17 catalog/function documentation.

## 7. Final decision and first command

**READY FOR OPERATOR APPROVAL** for the corrected read-only sequence above. Do not run the invalid Phase 4.5 `has_schema_privilege(..., 'CREATE WITH GRANT OPTION')` expression. No mutation is approved.

The **first command** to run from the repository root is the local CLI version check:

```powershell
npx --no-install supabase --version
```

It makes no remote request. Run the remaining local help checks in command 1. Before any remote command, independently verify the project in Dashboard. The **first remote/account-level command** is:

```powershell
npx --no-install supabase projects list
```

Use the project-list row to verify exactly one match for `bhnhhaurdnnalcozsviq`; confirm the name and check the region in Dashboard. If the row is missing, ambiguous, or inconsistent, stop before any database query. Then continue with the explicit-reference read-only commands above.

## Sources

- [Supabase CLI `db query`](https://supabase.com/docs/reference/cli/supabase-db-query) — `--remote` target resolution, target line, and `--read-only` behavior.
- [Supabase CLI `migration list`](https://supabase.com/docs/reference/cli/supabase-migration-list) — local/remote history listing and target syntax.
- [Supabase CLI `projects list`](https://supabase.com/docs/reference/cli/supabase-projects-list) — account-level listing of accessible projects.
- [PostgreSQL 17 role membership catalog](https://www.postgresql.org/docs/17/catalog-pg-auth-members.html) — membership direction and ADMIN/INHERIT/SET columns.
- [PostgreSQL 17 information functions](https://www.postgresql.org/docs/17/functions-info.html) — `pg_has_role`, privilege inquiry types, `acldefault`, and `aclexplode`.
- [PostgreSQL 17 `pg_policies`](https://www.postgresql.org/docs/17/view-pg-policies.html) — policy metadata columns.
