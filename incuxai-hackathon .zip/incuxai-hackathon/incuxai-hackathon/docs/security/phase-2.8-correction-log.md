# Phase 2.8 — PostgreSQL 17 Role Membership Corrections

**Scope:** corrections to the proposed owner-role model and disposable validation package. This is static design work only. No SQL was executed, no Supabase project was contacted, and no runtime compatibility is claimed.

**Phase 2.8.1 addendum:** PostgreSQL 16+ can store grantor-distinct membership rows for the same role/member pair. The automatic creator row is platform/bootstrap-granted, while the explicit self-grant is operator-granted. A GRANT by a given grantor updates that grantor's row; it does not alter a different grantor's bootstrap row. The validator now asserts the two grantors differ. The observed target's `postgres` membership in `supabase_privileged_role` is separately an unresolved operator-privilege review item; it does not itself prove any role privilege or make `postgres` the actual CLI migration operator.

## Primary decision: accept automatic ADMIN for the trusted operator

PostgreSQL 17 grants a non-superuser role creator with `CREATEROLE` an automatic membership in the role it creates. The automatic membership has `ADMIN TRUE`, `SET FALSE`, and `INHERIT FALSE`; because the bootstrap superuser grants it, the creator cannot remove or change that membership. The SQL design previously asserted effective `ADMIN FALSE`, which was incompatible with that documented behavior.

The corrected design accepts the automatic ADMIN membership only for the trusted migration operator who creates `incux_rpc_owner`. It then grants that same operator a second, explicit membership row with `SET TRUE`, `INHERIT FALSE`, and `ADMIN FALSE`. Thus:

- The trusted migration operator has effective ADMIN authority. This is a real ability to grant/revoke owner-role membership and is disclosed as elevated deployment authority. It is not described as non-delegable.
- The separate explicit SET path supplies the ability needed for ownership transfers and later migrations without inheriting owner privileges.
- `authenticator`, `anon`, `authenticated`, and `service_role` must have no direct or inherited membership, SET capability, or ADMIN capability in `incux_rpc_owner`. `authenticator` is included because PostgREST uses it as its connection role.
- The owner role remains `NOLOGIN`, `NOINHERIT`, `NOSUPERUSER`, `NOCREATEDB`, `NOCREATEROLE`, `NOREPLICATION`, and `NOBYPASSRLS`.
- The trusted deployment operator and its credentials remain outside application/runtime roles. Membership changes require restricted operational access, review, and audit.

### Alternatives considered

| Option | Assessment |
|---|---|
| Accept PG17 automatic ADMIN for the trusted operator | Selected conditionally. It matches PostgreSQL's behavior and allows the operator to create the role and separately receive `SET TRUE`. The operator's ADMIN delegation power is a documented risk; API roles are excluded and checked. Actual Supabase privileges still need validation. |
| Have a separately provisioned superuser create the role and grant non-admin SET membership | More restrictive in theory, but ordinary Supabase project users do not receive unrestricted superuser access. This is only viable if Supabase provides a supported provisioning path for the target. Do not assume one exists. |
| Remove the owner role and use `SECURITY INVOKER`/RLS or a server-side trusted boundary | Preferred fallback if the deployment operator must not have ADMIN authority or Supabase does not support the selected model. It requires separate design review of function bodies, grants, RLS, and API paths. |

The selected model limits ADMIN to the trusted operator by policy and assertions, not by PostgreSQL constraint: an ADMIN holder can delegate membership. A compromised or misused migration identity could grant the owner role to another role. The operator must therefore be treated as privileged deployment infrastructure, and every membership change must be reviewed.

## Corrections made

| Finding | Correction | Files / exact area |
|---|---|---|
| Phase 2.6 High: PG17 automatic ADMIN made the expected `ADMIN FALSE` state impossible for the creator | Clarified that the two rows coexist because the grantors differ (bootstrap/platform administrator vs. operator); same-grantor GRANT updates its existing membership record. Validator requires exactly the two grantor-distinct option shapes and leaves effective ADMIN true. | `scripts/validation/phase-2.6-role-validation.sql`: role creation and grantor-aware membership assertion; runbook and Phase 2.5 plan explain exact semantics. |
| Phase 2.6 Medium: API direct table privilege check covered only SELECT | Final SQL checks table-level privileges for SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER, and MAINTAIN, plus column-level SELECT/INSERT/UPDATE/REFERENCES for `authenticator`, `anon`, `authenticated`, and `service_role`. It asserts expected public view/RPC grants and no API access to private fixture view/RPC. | `scripts/validation/phase-2.6-role-validation.sql`: final ACL assertion; `docs/security/phase-2.6-validation-runbook.md`: automated and manual API checks. |
| Phase 2.6 Medium: ownership transfer exercised only `public` | The validation creates named fixtures in both `public` and `private`, checks pre-grant privileges for both, performs view and function ownership transfers in both, simulates later replacement in both, and asserts temporary CREATE is revoked from both. The private schema is created only when absent and only after preflight confirms database CREATE. | `scripts/validation/phase-2.6-role-validation.sql`: private schema preflight/creation, fixture DDL, transfer windows, subsequent migration, final assertions; runbook and H6 plan. |
| Phase 2.6 Low: project reference confirmations were editable and not tied to the supplied target | The script pins the expected ref to `bhnhhaurdnnalcozsviq` and requires a separate Dashboard-confirmed value to match. Runbook requires verifying both the local link record and Dashboard URL immediately before execution. PostgreSQL still cannot attest the connected Supabase project ref, so the human check remains mandatory. | `scripts/validation/phase-2.6-role-validation.sql`: project-ref guard; `docs/security/phase-2.6-validation-runbook.md`: manual preflight and safeguards. |
| H6/Phase 2.7 docs incorrectly described the ADMIN grant as non-delegable | Added superseding clarification: the automatic ADMIN path is accepted only for the trusted operator, while the explicit SET path is non-inheriting and non-admin. | `docs/database/phase-2-architecture.md`; `docs/security/phase-2-rls-matrix.md`; `docs/security/phase-2-security-review.md`; addenda in `phase-2.4-correction-log.md` and `phase-2.7-audit-report.md`. |

## Review of the 15 Phase 2.3 findings

This phase did not redesign the other 14 already-corrected findings. Their corrections were cross-checked against the Phase 2.4 correction log and current SQL/design locations. Their “resolved statically” status is inherited from the earlier correction work and is not runtime validation.

| ID | Current disposition | Current source location / note |
|---|---|---|
| H1 | Previously corrected; static source status retained | `public.team_post_payment_exception`; audit insert and transaction path. |
| H2 | Previously corrected; static source status retained | `public.community_moderate`; restore is limited to moderation-hidden content. |
| H3 | Previously corrected; static source status retained | `public.certificate_verify` and final function ACL; direct anonymous execution removed. |
| H4 | Previously corrected; static source status retained | Admin invitation, announcement, schedule, rubric, certificate-type, and notification RPC sections. |
| H5 | Previously corrected; static source status retained | `payment_webhook_events`, transaction state history, and `public.payment_record_verified_webhook`. |
| H6 | Static design corrected; actual project validation pending | Owner role contract, current-user membership assertions, `public`/`private` transfer fixtures, actual migration-operator checks. |
| M1 | Previously corrected; static source status retained | RLS preamble; policy definitions are noted as proposed below. |
| M2 | Previously corrected; static source status retained | Announcement audience and recipient-target RLS policies. |
| M3 | Previously corrected; static source status retained | Permission, authorized audit, and invitation read projections. |
| M4 | Previously corrected; static source status retained | Consent serialization and required consent version logic. |
| M5 | Previously corrected; static source status retained | RLS matrix and corresponding policy/view/RPC/ACL definitions. |
| M6 | Previously corrected; static source status retained | Registration/join withdrawal and moderation lifecycle RPCs. |
| M7 | Previously corrected; static source status retained | `public.payment_create_order` expiry and locking path. |
| L1 | Previously corrected; static source status retained | `public.certificate_verify`; Edge abuse controls remain deployment work. |
| L2 | Previously corrected; static source status retained | Privileged role/permission RPC reason validation. |

## Static corrections vs. runtime facts

| Category | Status |
|---|---|
| Static design corrections | Complete for the membership model, project-ref pin/manual confirmation, public/private fixtures, schema grant/revoke assertions, and API privilege assertions described above. |
| PostgreSQL behavior supported by official documentation | PostgreSQL 17 automatic creator ADMIN behavior/options; membership option semantics and catalog fields; ownership-transfer requirements for `SET ROLE` and schema `CREATE`; access inquiry functions. These are documented PostgreSQL semantics, not Supabase project results. |
| Requires actual disposable-project execution | Actual migration identity and `session_user`/`current_user`; CREATEROLE and schema grant options; role creation/membership rows; `SET ROLE`; `public` and `private` ownership transfers; temporary CREATE revocation; later migration using the real runner; PostgREST/RLS behavior; project cleanup. |

## Unresolved assumptions and limits

1. The supplied project name/ref are assumed to identify the intended disposable project. The SQL pins the expected ref, but the database connection cannot independently prove it. Dashboard and local link-record confirmation remain required.
2. The actual migration role is assumed to be the non-superuser CREATEROLE role that creates `incux_rpc_owner`. The SQL will verify role attributes and expected membership rows; no result is known yet.
3. The selected design assumes the trusted operator's ADMIN capability is acceptable under the team's deployment controls. If that assumption is rejected, use a separately provisioned supported role or redesign the function boundary.
4. The `private` schema may already exist. The script checks that the operator can grant CREATE there and uses only named fixture objects; it does not expose the schema through PostgREST. Dashboard exposure must still be checked manually.
5. A successful manual SQL session does not prove any additional behavior of `supabase db push`; a later migration through the actual runner is still required if it uses another connection identity or session setup.
6. The Phase 2 schema draft remains unexecuted. Static correction does not imply production readiness.

## Prohibited actions and current state

No SQL was executed; no Supabase connection was made; no migration was created/applied; no frontend/application files, production configuration, dependencies, or Git history were changed. H6 is not marked resolved. Proceed only to controlled disposable-project validation after the final audit decision below.
