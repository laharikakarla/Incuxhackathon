# AICUXORA Phase 4.7 — Read-Only Baseline Evidence Report

**Assessment date:** 2026-11-13  
**Target reported by operator:** `incuxai-hackathon-validation` / `bhnhhaurdnnalcozsviq` / `ap-south-1`  
**Reported PostgreSQL version:** 17.11  
**Report type:** Documentation-only consolidation. No Supabase connection, SQL execution, or database mutation was performed for this report.  
**Mutation status:** No mutation experiment has passed or been performed as part of this report.

## 1. Executive summary

The operator reports that read-only checks against the disposable validation project returned PostgreSQL 17.11, database `postgres`, and both `session_user` and `current_user` as `supabase_read_only_user`. This identifies the read-only diagnostic connection only; it does not identify the CLI migration login, migration SQL's effective role, migration-created object owner, or subsequent migration identity.

The repository includes [`section5-membership-output.csv`](../../section5-membership-output.csv), a membership-path result containing direct and transitive membership edges with grantors and PostgreSQL 17 ADMIN/INHERIT/SET flags. It does not contain a target reference, collection timestamp, or command transcript, so its provenance cannot be independently bound to this particular run from the file alone. The current task supplies the target and labels the results as collected from that target; this report records that as operator-provided context, not an independently verified connection.

Other reported results are supplied as summaries without complete query text/raw output. This report therefore preserves their scope limits and does not upgrade them into stronger claims. In particular, no rows in one catalog query do not prove that no objects exist outside its filters, schemas, or visibility.

## 2. Evidence sources and provenance

| Evidence | Source | Provenance limitation |
|---|---|---|
| Phase 4.5 command sheet | `aicuxora-phase-4.5-read-only-command-sheet.md` | Prepared commands only; the sheet states it was not executed. It also contained an invalid `has_schema_privilege(...,'CREATE WITH GRANT OPTION')` inquiry, later corrected in Phase 4.6. |
| Phase 4.6 review and corrected sequence | `aicuxora-phase-4.6-command-review.md` | Static review and commands only; it states no commands were executed. |
| Identity/version, schema, relation and no-row findings | Operator-provided summary in the Phase 4.7 request | No raw result rows, query timestamps, exit codes, exact SQL text for every query, or sanitized CLI target line were included here. |
| Membership graph | `section5-membership-output.csv` | Contains data rows and headers, but no embedded target ref, timestamp, CLI target line, or provenance metadata. Treated as supplied membership evidence, not independently freshly verified. |

No secret values are included. No credentials were read or requested.

## 3. Consolidated findings: what they prove and do not prove

| Reported result | What it supports | What it does not establish / limitation |
|---|---|---|
| CLI version `3.1.0` | The operator reports this version for the CLI used. This is consistent with the prior local repository report. | Does not prove the exact CLI binary/flags used for each query unless the command transcript is retained. Does not establish DB identity or migration identity. |
| Project `incuxai-hackathon-validation`, ref `bhnhhaurdnnalcozsviq`, region `ap-south-1` | The operator identifies this as the target for the supplied results. It is the only permitted validation target. | This report did not connect or independently verify the Dashboard/CLI resolution. The CSV has no target metadata. Production was not contacted by this report; raw target evidence from the operator run is not included. |
| PostgreSQL `17.11` | The operator reports this server version for the diagnostic session. | Does not prove migration-path behavior, role ownership feasibility, or that every query used the same server/connection route. |
| Database `postgres`; `session_user = supabase_read_only_user`; `current_user = supabase_read_only_user` | The supplied identity query reports the diagnostic database/session and effective query user as shown. | This is only the read-only query route. It does not establish CLI account identity, migration login, migration `current_user`, object owner, or subsequent migration identity. Do not infer that migrations run as `postgres` or `supabase_read_only_user`. |
| Role membership inventory/options | The CSV records direct/transitive paths rooted at `postgres`, including membership member, granted role, grantor, ADMIN/INHERIT/SET flags, path summaries and role attributes of the granted role. | It does not show every possible root principal; it is not a current full role inventory. File lacks target/timestamp metadata. The `postgres`-rooted graph does not establish whether newly proposed owner/runtime roles exist or whether API roles could join them. Missing roots/paths must not be read as a negative assertion. |
| Schema ownership and effective USAGE/CREATE privileges | Operator reports those checks were collected. | The request does not include exact schema rows, direct ACL entries, grantors, `is_grantable` values, or the principal used for each effective check. Effective CREATE is not CREATE WITH GRANT OPTION. The Phase 4.5 `has_schema_privilege(...,'CREATE WITH GRANT OPTION')` query is invalid; only Phase 4.6's corrected direct ACL/effective inquiry split should be used. These results do not establish future grantor/ownership-transfer authority. |
| Existing service-specific migration-history relations and columns | Operator reports that service-specific migration-history relations and columns were present. | Exact schema, relation names, column names/types, owners, rows and SQL query are not included. Do not equate these with `supabase_migrations.schema_migrations` without the output. Their presence does not prove the CLI migration history is complete or identify the migration operator. |
| No rows returned for public application tables | The operator reports an empty result from a public-application-table check. | The exact query/filter is not included. This can mean no rows matched that query, not necessarily that the entire public schema has no relations, that application data tables do not exist, or that other schemas are empty. A catalog inventory is not a query for application data rows. |
| No rows returned for public RLS policies | The operator reports that no rows were returned for a public policy query. | The raw query, exit status and catalog visibility are not supplied. If the Phase 4.6 `pg_policies` query was used, it lists visible policies; zero rows would indicate no visible matching policy rows only. It does not prove RLS is enabled/forced or that tables are safe. |
| No rows returned for public functions | The operator reports no rows for a public-function check. | Exact query and visibility are not supplied. If it was the Phase 4.6 function inventory, it checks `public` and `private` ordinary functions/procedures with expanded ACLs; this summary only states public. It does not prove there are no functions in other schemas, aggregates, extension schemas, or hidden catalog entries. |
| No matching audit/outbox/event relations in `public`/`private` | The operator reports no matching names in those schemas. | Name-pattern and schema filters are not supplied in raw form. No match does not prove absence under different names/schemas, external audit/logging infrastructure, triggers on unrelated tables, or other event processing. |
| `private` schema absent from inspected schema inventory | The inspected inventory did not show a schema exactly named `private`. | Does not prove no private/internal schema exists under another name, nor that a schema is absent from every database/project. Requires successful, sufficiently visible namespace query to make an exact absence claim. |

## 4. Membership evidence from `section5-membership-output.csv`

The CSV contains a depth-1 row where `postgres` is the **member** and each listed role is the **granted role**. Direction is important: this means the member may inherit or `SET ROLE` to the granted role according to the edge options; it does not mean the granted API role can access or assume `postgres`.

### Direct memberships for `postgres` recorded in the CSV

All listed edges show grantor `supabase_admin`; `postgres` has `ADMIN=true`, `INHERIT=true`, and `SET=true` for:

- `anon`
- `authenticated`
- `authenticator`
- `pg_create_subscription`
- `pg_monitor`
- `pg_read_all_data`
- `pg_signal_backend`
- `service_role`

The edge from `postgres` to `supabase_privileged_role` shows `ADMIN=false`, `INHERIT=true`, and `SET=true`.

This is not evidence that API roles are members of `postgres`. The CSV also shows transitive paths:

- `authenticator` (with its role-level `rolinherit=false`) is a member of `anon`, `authenticated`, and `service_role` with edge `INHERIT=false`, `SET=true`, `ADMIN=false`.
- `pg_monitor` is a member of `pg_read_all_settings`, `pg_read_all_stats`, and `pg_stat_scan_tables` with `INHERIT=true`, `SET=true`, `ADMIN=false`.

The CSV's path-level `effective_inherited_privileges`/`can_set_role` values are the values reported by that query. They do not demonstrate anything about roles omitted as roots or owner/runtime roles not present in that query result. In particular, no `incux_rpc_owner` row appears in these supplied paths, but that is not proof about future domain-specific owner roles. The reported API-role negative checks and a new role's membership must be independently queried after any owner exists; no owner creation is authorized or performed here.

### Security interpretation

The CSV indicates that `postgres` has broad ability to assume/manage memberships in several API/platform roles, including ADMIN OPTION on the listed direct API-role memberships. PostgreSQL membership direction does not reverse this authority. This is a reason to inspect the actual migration route and grantor semantics carefully; it is not proof that an API role can become `postgres`. It also means an experiment performed as `postgres` may have authority unlike a restricted migration operator. Do not use it as a proxy unless the actual migration route proves that identity.

## 5. Migration history and identity conclusions

- The reported read-only SQL identity is known only for its query route: `supabase_read_only_user` was both `session_user` and `current_user`.
- Supabase CLI authentication identity remains distinct and is not listed in the supplied results.
- Actual migration `session_user` and `current_user` remain **unknown**.
- Role that owns newly created migration objects remains **unknown**.
- Identity and permissions used by a later migration replacing a domain-owned function remain **unknown**.
- Service-specific migration-history relations/columns are reported, but their exact identity and relation to the CLI's `supabase_migrations.schema_migrations` tracking table are **unknown**.
- No empty migration comparison or missing conventional history relation would prove the schema is empty. Migration history is a record of migration versions, not a complete catalog inventory.

No migration identity probe or ownership mutation has passed.

## 6. Unresolved feasibility questions

1. What exact CLI deployment command and non-secret credential route will be used for migrations?
2. What PostgreSQL `session_user`, `current_user`, effective role, and object owner does that actual command produce?
3. Which service-specific migration-history relations are present, what columns/owners do they have, and how (if at all) do they correspond to `supabase_migrations.schema_migrations`?
4. Can the actual migration operator create a narrowly scoped NOLOGIN domain owner with the required negative attributes, without API/runtime membership paths?
5. Can the operator transfer a function to that owner with only reviewed privileges?
6. Is a later `CREATE OR REPLACE FUNCTION` by the migration operator denied as expected when it does not own the function or have owner-role `SET` rights?
7. Is there a narrowly scoped, temporary, independently revocable mechanism for subsequent replacement? Who grants it, who revokes it if deployment crashes, and how are ADMIN/INHERIT/SET options verified?
8. Can a subsequent migration replace the function, preserve owner/ACL/security attributes, and revoke all temporary privileges reliably?
9. Does transaction pooling change `session_user`, `current_user`, JWT context, or runtime identity assumptions?
10. Do any approved domain owners/runtime roles or public tables/policies exist in schemas not covered by the reported no-row checks?
11. How will trigger audit identify user/system/webhook actors without trusting caller parameters or custom GUCs?
12. What exact function-owner, system-runtime and Phase 4.3 fixture names are approved? They remain unspecified in the authoritative architecture.

## 7. Minimum next experiments

These are future, separately approved operations. None is authorized or passed by Phase 4.7.

### A. Complete and provenance-tag the read-only baseline

Obtain the sanitized command transcript/results for the current run, including timestamp, explicit project name/ref/region and CLI-resolved target line. Include the exact schema/privilege rows, migration-history relation/columns and public-object query filters. Do not include secrets. Re-run only missing read-only diagnostics if needed, using Phase 4.6's corrected sequence and explicit `--remote=bhnhhaurdnnalcozsviq --read-only` for SQL. Stop if target mismatch or catalog visibility is incomplete.

### B. One migration identity probe — requires explicit mutation approval

After baseline review, use the intended migration deployment command against only the disposable reference to apply a uniquely named, inert test migration/probe. Before approval, define the fixture name, migration-history effects, expected transaction behavior and cleanup. Capture separately: CLI authentication route, database `session_user`, in-migration `current_user`, created-object owner, and identity used on a second migration. The probe changes database state and may change migration history; it is not a read-only test.

### C. Ownership and replacement lifecycle — separate approval per operation

Only after the migration identity evidence is reviewed, test a disposable NOLOGIN owner role, required attributes, minimal schema privileges and ownership transfer. Verify API/runtime roles cannot assume it. Attempt replacement without temporary authority and record the expected denial. Then test a reviewed temporary privilege mechanism, replace, revoke immediately, independently verify role options/schema ACL/object owner/ACL, and run one subsequent migration. Names/grants and grantor must be approved in a concrete manifest first.

### D. Failure recovery — separate approval per injected failure

Inject isolated failures at role creation, ownership transfer, replacement, after temporary grant before revoke, and subsequent migration. For each, capture transaction/migration-history effects, surviving privileges/objects, detection query and precise recovery. If cleanup or history cannot be proven, stop and discard/recreate the disposable project only through a separately approved procedure; never use broad cleanup.

### E. Runtime, RLS and audit tests — deferred until manifests exist

The reported absence of public functions/policies/tables means these results cannot validate the proposed backend architecture. First approve exact runtime identity names/routes and test fixture schema. Later, test every runtime independently through the intended pooler; then use synthetic users/data to test JWT identity, RLS negative cases, trigger audit identity/atomicity, and API-role exclusion. No production data or real participant PII.

Payment/outbox tests remain deferred until the per-participant payment design and fee/provider/business decisions are specified. Use a mock provider only; do not contact a real payment provider.

## 8. Readiness conclusion

The reported baseline supports the conclusion that the diagnostic connection was read-only and reported `supabase_read_only_user` for both database identity fields. It does not establish migration identity or prove custom owner/runtime feasibility. Reported empty results are scoped to their queries and inspected schemas; they do not prove global object absence.

**Backend implementation remains NO-GO.** The minimum next action is to complete a provenance-tagged, sanitized read-only baseline and review it before requesting explicit approval for a single migration identity probe. No mutation test is represented as passed.
