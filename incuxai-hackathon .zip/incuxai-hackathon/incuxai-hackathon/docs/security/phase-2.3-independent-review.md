# Phase 2.3 — Independent Security and Architecture Review

**Review type:** static review of the complete Phase 2.2 documentation set, including the SQL draft. No SQL was executed, no Supabase service was contacted, and no runtime behavior is claimed.

## Decision

# NOT READY — CORRECTIONS REQUIRED

The design has strong foundations, including default revokes, RLS, explicit function ACLs, composite payment/evaluation relationships, serialized team operations, and consent-gated recruiter projections. However, there are confirmed high-priority defects in trusted functions and public verification, plus gaps between promised workflows and actual functions. These should be corrected before controlled database validation.

## Findings

### High

| ID | Finding | Affected location | Why it matters |
|---|---|---|---|
| H1 | **Post-payment roster exception RPC has a malformed audit insert.** The `INSERT` names six `audit_log` columns but its `VALUES` list has seven expressions: the conditional leader snapshot and action snapshot are both supplied, while `before_data` is omitted from the column list. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.team_post_payment_exception`, lines 1837–1840 | PostgreSQL will reject the insert when the function executes, causing the whole transaction—including the approved roster change—to roll back. The documented exception path is unusable until fixed. |
| H2 | **Moderator “restore” can publish content that was never hidden.** For `p_action='restore'`, both post and comment updates set `status='published'` for any matching ID, without requiring the prior state to be `hidden` or retaining the prior state. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.community_moderate`, lines 2740–2745 | A moderator can turn a draft or archived item into published content. This crosses the intended moderation boundary and can expose unpublished material. Restore must only reverse a moderation hide and preserve the prior visibility/state. |
| H3 | **Anonymous callers can invoke the certificate verifier directly and bypass the planned per-source Edge rate limit.** The final ACL grants `certificate_verify(text)` to `anon`; the function applies one global advisory lock and global 120/minute threshold rather than per-source limits. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.certificate_verify`, lines 2584–2606 and final grants at 2803 | Direct PostgREST RPC calls do not have to pass through the Edge Function. Any caller can consume the shared rate budget and force all calls through a single serialized lock, creating an avoidable denial-of-service path. Put rate limiting at a reachable trusted boundary and avoid a single global transaction lock on public traffic. |
| H4 | **Core administrative and communications workflows are described but have no trusted write functions.** The SQL has no invite/accept/revoke RPC for `admin_invitations`, no announcement create/edit/publish or target-management RPC, no schedule create/edit/publish RPC, no rubric/criteria administration or publication RPC, no certificate-type management RPC, and no notification enqueue RPC. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `admin_invitations` table (95–108), `announcements`/`announcement_targets` (763–798), `event_schedule` (824–840), `evaluation_rubrics`/`evaluation_criteria` (660–684), `certificate_types` (854–860), and public function inventory | Direct table writes are revoked and there are no corresponding execute grants, so the related admin/dashboard or delivery workflows cannot be implemented using the documented access model. The RLS matrix claims some of these operations exist. Add narrowly scoped, audited RPCs or explicitly defer the workflows and align the requirements/matrix. |
| H5 | **Provider transaction status is modeled as a single immutable `succeeded`/`failed` fact, and duplicate transaction IDs are discarded before status reconciliation.** | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `payment_transaction_state` (24–25), `payment_transactions` (353–380), `public.payment_record_verified_webhook` (2150–2217) | The design does not state which provider events are terminal or how a later authoritative status for the same gateway transaction is reconciled. A later success for an ID already stored as failed is classified as a duplicate and ignored. Define supported provider event sequencing and a safe append-only reconciliation model before relying on gateway callbacks. |
| H6 | **The non-login owner role and ownership-transfer model may require privileges not available to the chosen Supabase migration operator.** | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), Authorization contract (992–1004), final ownership block (2756–2769) | The entire view/definer-function model assumes that the project can create `incux_rpc_owner`, grant it table access, and transfer ownership of every function/view. This must be confirmed against the actual Supabase-managed PostgreSQL role model before implementation; no compatibility check was run. |

### Medium

| ID | Finding | Affected location | Why it matters |
|---|---|---|---|
| M1 | **The SQL contains a stale statement that no policies are included.** Actual RLS policies and grants follow later in the same file. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), lines 925–927 | It directly contradicts the implementation-ready proposal and can mislead future reviewers or engineers. Replace the old placeholder comment with a clear note that the policies are defined below and remain unexecuted. |
| M2 | **Announcement audience targeting is inconsistent with its policy.** The enum includes `registered_participants`, `paid_teams`, `judges`, `recruiters`, `moderators`, `admins`, and `targeted`, but `announcements_published_read` only permits `public` or a matching explicit user/team/role target. Also, `announcement_targets_recipient_read` does not permit a recipient to read a `target_role` row, so the RLS-filtered subquery cannot see role targets. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `announcement_audience` (38–39), policies (1221–1227) | Several configured audiences will not resolve to intended recipients. Define audience expansion and make the target policy consistent without exposing other audiences/targets. |
| M3 | **Administrative audit and permission self-service reads do not match the matrix.** The matrix says audit readers can inspect filtered audit records and target Admins can see their permission names; there is no audit view/RPC, and `my_role_summary` selects only role grants. `admin_permission_grants` has an RLS policy but no client SELECT grant/view. | [phase-2-rls-matrix.md](phase-2-rls-matrix.md), identity rows; [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `my_role_summary` (1358–1359), final view grants (1429–1435), audit policy/grants | This is a functionality and documentation mismatch for the admin portal. Either provide safe, permission-filtered projections and grants or state that audit/permission reads are operator-only. |
| M4 | **Consent “latest event” ordering uses an identity sequence without serializing concurrent grants/revocations.** `can_recruiter_view` chooses `max(id)`; `recruiter_set_consent` inserts without locking the participant/scope. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `recruiter_consent_events` (641–651), `private.can_recruiter_view` (1064–1085), `public.recruiter_set_consent` (2316–2329) | Sequence allocation order is not guaranteed to equal transaction commit order. Concurrent consent changes can leave the effective event different from the last committed user choice. Serialize changes per participant/scope and define deterministic current-version semantics. |
| M5 | **Some matrix claims are not implemented in SQL.** Examples include Admin invitation RPCs, direct audit reader access, catalog/category writes, and admin controls for announcements/schedule/rubrics; the matrix also implies public skill-list access although the catalog grant is authenticated-only. | [phase-2-rls-matrix.md](phase-2-rls-matrix.md), identity/community/judging/communications rows; [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), grants at 1240–1280 and final grants | Reviewers need the matrix to describe actual privileges exactly. Reconcile the matrix after the missing operations are either implemented in the design or deferred. |
| M6 | **Several lifecycle or support actions are incomplete or weakly auditable.** For example, `community_moderate('warn', ...)` records an action but does not change/report a warning state; `team_withdraw_join_request` has no explicit action/reason audit record; registration withdrawal has no trusted transition function. | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.community_moderate` (2722–2754), `public.team_withdraw_join_request` (1716–1725), `participant_registrations` lifecycle (129–145) | Some advertised status transitions lack a complete state model or action-level history. Define which transitions are supported and make actor, timestamp, prior/new state, and reason available where appropriate. |
| M7 | **An expired-but-not-yet-processed pending order is returned as usable by `payment_create_order`.** | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.payment_create_order` (2118–2147), `public.payment_expire_order` (2221–2236) | The retry path returns any `status='pending'` order without checking `expires_at`. Until the scheduled expiry worker runs, a leader can receive an already expired order and cannot create a fresh attempt. Make expiry idempotently enforceable in the order-creation transaction or define a guaranteed scheduler/expiration protocol. |

### Low

| ID | Finding | Affected location | Why it matters |
|---|---|---|---|
| L1 | **`certificate_verify` hard-codes a global 120 requests/minute threshold and serializes all calls with a constant advisory lock.** | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.certificate_verify`, lines 2584–2606 | The threshold and contention profile are operational choices, not product decisions. Even after moving per-source limits to a trusted edge, define threshold, abuse response, and monitoring based on expected traffic. |
| L2 | **Several role/permission RPCs accept optional or empty audit reasons.** | [phase-2-schema-draft.sql](../database/phase-2-schema-draft.sql), `public.admin_grant_role`, `admin_revoke_role`, `admin_grant_permission`, `admin_revoke_permission`, `admin_transfer_super_admin` | The audit design expects a reason for privileged changes, but some functions do not enforce a nonempty one. Enforce this consistently for accountable staff actions. |

## Review by requested area

### RLS and roles

**Good design:** the draft enables and forces RLS, revokes broad table privileges, uses a non-login `NOBYPASSRLS` function owner, derives the user identity from `auth.uid()`, and has an explicit final `EXECUTE` allow-list. Sensitive raw tables do not have ordinary client grants. Role grants and Admin permissions are not profile fields or client-writable JWT metadata.

**Cautions:** the stale no-policy comment (M1), permission/view mismatches (M3/M5), missing admin workflows (H4), and moderator publish path (H2) need correction. A full policy-by-policy runtime test remains mandatory; static inspection cannot prove RLS behavior.

### Function privileges and PostgreSQL/Supabase compatibility

The `SECURITY DEFINER` functions generally set a fixed `search_path`, use schema-qualified objects, and have execute privileges revoked before named grants. This is a sound pattern in principle. Confirm every function owner and grant against the actual target project.

**High deployment risk to validate (H6):** the proposal creates `incux_rpc_owner`, changes ownership of every `public` and `private` function to it, and makes it own views. Supabase-managed database roles and migration execution privileges vary by deployment. Confirm that the migration operator can create that role and transfer all function/view ownership, and that PostgREST can use the resulting view/function permissions. This review did not test those privileges.

### Payments and refunds

The schema correctly snapshots fee version/amount/currency, ties a successful order to an applied successful transaction through composite keys, restricts one pending-or-paid order per team, preserves paid transaction facts, makes webhook event IDs unique, and serializes refund reservations on the order. The late-capture approach preserves the money event without silently paying an expired order.

H1 and H5 block confidence in the exception and gateway lifecycle paths. Also verify provider event ordering, retry semantics, late-capture reconciliation ownership, and refund failure/retry behavior before implementation. `payment_finish_refund` transitions a `requested` row directly to a terminal gateway result; the `processing` state has no exposed transition function.

### Teams and roster locking

The one-active-team and one-active-leader partial unique indexes, deferred roster assertion, size-policy snapshot, team-row locks, and payment roster freeze are appropriate controls. Team creation accepts the leader as a roster member. H1 breaks the promised Super Admin post-payment exception. Confirm a seed/bootstrap procedure for the first policy version and verify lock ordering/race behavior with concurrent transactions before deployment.

### Recruiter privacy

Candidate reads require recruiter role, access grant, and latest scope consent; no shared workspace is assumed; payment, private team conversation, and evaluation data are excluded from candidate views. Consent version is stored in events. M4 remains: concurrent updates are not serialized, and the helper does not compare an event against a separately defined currently-required consent-text version. Define version cutover and revoke/renew behavior before real consent is collected.

### Judges and evaluation

Composite assignment/judge/rubric and evaluation/criterion/rubric keys, score maximum trigger, active duplicate-assignment index, conflict checks, and explicit release permission are strong proposals. Confirm the published rubric is immutable under all update paths and test that revoke/recusal immediately removes both project and score access. Rubric authoring/publication operations are absent (H4), so judges cannot yet receive an implementation-ready assignment workflow.

### Constraints, lifecycle, and audit

The schema has numerous useful checks, partial indexes, foreign keys, and lookup indexes. Status/time checks cover many primary transitions but not every advertised operation. M6 and L2 identify audit consistency gaps. The architecture/relationship/RLS documents are generally coherent but overstate some implemented operations (M3/M5).

## Static checks performed

- Read all seven requested Phase 2 documents, including the complete SQL draft, and cross-checked named functions, policies, grants, views, tables, and described workflows.
- Static inventory from the draft: **59** declared public tables; **59** `ENABLE ROW LEVEL SECURITY` statements; **61** explicit policies; **57** public functions named in the final function ACL block.
- Static foreign-key table-target check: no references to undeclared `public` tables; `auth.users` is the external Supabase Auth dependency.
- Checked for implementation mismatches and function body paths by source inspection. No SQL parser, database, Supabase CLI, migration runner, or runtime authorization test was run.

## Final decision

# NOT READY — CORRECTIONS REQUIRED

Correct H1–H5, reconcile M1–M6, then conduct a separate controlled PostgreSQL/Supabase validation review. The current artifacts are useful design inputs, but must not be treated as an executable or production-ready schema.
