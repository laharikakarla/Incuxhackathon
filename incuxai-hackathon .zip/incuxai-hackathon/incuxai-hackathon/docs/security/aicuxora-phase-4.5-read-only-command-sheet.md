# AICUXORA Phase 4.5 — Exact-Reference Read-Only Validation Command Sheet

**Purpose:** Prepare the first read-only validation only.  
**Status:** Commands are proposed and have **not** been executed. This document does not authorize execution.  
**Only permitted target:** `incuxai-hackathon-validation` / `bhnhhaurdnnalcozsviq` / `ap-south-1`.  
**Production:** Never target `incuxai-hackathon`.

## 1. Scope and evidence boundary

This command sheet was prepared from the Phase 2.14 and Phase 4.2–4.4 repository documents and the existing `section3-preflight.sql` through `section6-preflight.sql` diagnostics. CLI syntax is the syntax already recorded in repository reports for Supabase CLI 3.1.0:

- `npx --no-install supabase db query --remote=<project-ref> --read-only <SQL>`
- `npx --no-install supabase migration list --remote=<project-ref>`

The second command has no documented `--read-only` option in the inspected project records. The repository records it as a migration-history listing that did not apply migrations. Inspect its local help before use and stop if installed CLI behavior differs. Do not run `db push`, `db reset`, `migration repair`, SQL files, or any DDL.

No Supabase project was contacted for this sheet. The target name/reference/region above are task-authorized values, **not freshly verified remote facts**. Historical results such as PostgreSQL 17.11 and diagnostic identity `supabase_read_only_user` must be rechecked. No query identity establishes migration identity.

## 2. PowerShell preflight guard and target confirmation

### Local target-string guard

Run in PowerShell from the repository root. It makes no network request and does not read credentials:

```powershell
$ErrorActionPreference = 'Stop'
$target = 'bhnhhaurdnnalcozsviq'
if ($target -cne 'bhnhhaurdnnalcozsviq') {
    throw 'STOP: target reference is not the authorized disposable project.'
}
Write-Output 'Local target allowlist: PASS (bhnhhaurdnnalcozsviq)'
```

**Proves:** only that the local variable equals the allowlisted reference.  
**Does not prove:** that the remote project exists, its name/region, which project CLI resolves, or which database identity will connect.  
**Read-only:** yes; local only. **Permissions:** none. **Failure:** stop; do not run any remote command.

### Manual dashboard confirmation

Before every remote command, independently confirm in the Supabase Dashboard:

- Project name: `incuxai-hackathon-validation`
- Project reference: `bhnhhaurdnnalcozsviq`
- Region: `ap-south-1`

Do not use `supabase/config.toml` or implicit local project linking to select a target. Earlier reports record a CLI environment label `production` while the explicit reference resolved to the disposable project. If the current CLI output shows a production label, unexpected name/ref/region, or any ambiguity, stop and have the operator resolve it in Dashboard before continuing. Do not “fix” ambiguity by omitting `--remote`.

## 3. Common CLI checks

Run these locally in PowerShell from the repository root. They do not select or connect to a database. Telemetry variables suppress CLI telemetry only; no secret values are inspected.

```powershell
$env:SUPABASE_TELEMETRY_DISABLED = '1'
$env:SUPABASE_DISABLE_TELEMETRY = '1'
npx --no-install supabase --version
if ($LASTEXITCODE -ne 0) { throw 'Supabase CLI version command failed.' }
npx --no-install supabase db query --help
if ($LASTEXITCODE -ne 0) { throw 'Could not verify db query CLI options.' }
npx --no-install supabase migration list --help
if ($LASTEXITCODE -ne 0) { throw 'Could not verify migration list CLI options.' }
```

**Expected:** version and local help text; repository previously reports 3.1.0.  
**Proves:** installed CLI syntax/options only.  
**Does not prove:** remote target, authentication, database identity, or command behavior against the hosted project.  
**Read-only:** local CLI metadata/help. **Permissions:** none expected. **Failure:** stop; do not guess an alternative flag or remove `--read-only`/`--remote`.

## 4. Remote command wrapper pattern

Each SQL command below has its own literal project reference. Do not replace it with a linked target or a value from `config.toml`. After each native command, check `$LASTEXITCODE` immediately. A nonzero exit means the SQL did not complete successfully; do not treat empty/partial output as a passed check.

The repository documents that remote SQL uses `--read-only`. It also records that `db query` requires CLI authentication and a database query route/permission. The exact Supabase OAuth/database privilege scope required for each catalog remains project-dependent and is not established here. Do not put tokens, passwords, URLs, API keys or secrets in the command, SQL, transcript or report.

## 5. Commands in execution order

### 1. Verify remote project reference and current database identity

```powershell
$sql = @'
SELECT current_database() AS database_name,
       session_user AS session_user,
       current_user AS current_user,
       current_setting('server_version') AS server_version,
       current_setting('server_version_num') AS server_version_num;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Read-only identity query failed; stop.' }
```

**Expected:** CLI first resolves/displays `incuxai-hackathon-validation` and the exact reference; SQL returns database name, login `session_user`, effective `current_user`, and server version. Dashboard supplies region confirmation.  
**Proves:** this query route's target resolution and SQL identity/version, if query succeeds.  
**Does not prove:** migration execution identity, created-object owner, subsequent migration identity, hosted migration role, or that CLI authentication user equals PostgreSQL role.  
**Read-only:** yes (`SELECT`, `--read-only`). **Permissions/auth:** Supabase CLI authenticated access to the explicit project and a database role allowed to run the query. **Failure:** no result is not a pass; stop and diagnose auth/target. Reconfirm project name/ref from CLI output before trusting SQL output.

### 2. PostgreSQL version only (separate evidence row)

```powershell
$sql = "SELECT current_setting('server_version') AS server_version, current_setting('server_version_num') AS server_version_num;"
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL version query failed; stop.' }
```

**Expected:** one row showing current server version.  
**Proves:** version for this database session.  
**Does not prove:** compatibility of untested functions, managed role behavior, or migration identity. **Read-only:** yes. **Permissions/auth:** same as command 1. **Failure:** record as unknown, not as version match.

### 3. Database role inventory

```powershell
$sql = @'
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb,
       rolreplication, rolbypassrls, rolcanlogin, rolconnlimit
FROM pg_catalog.pg_roles
ORDER BY rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Role inventory query failed; stop.' }
```

**Expected:** visible role names and attributes, including API roles and platform roles if visible to the query identity.  
**Proves:** attributes returned by `pg_roles` for roles visible to this session.  
**Does not prove:** all privilege reachability, role secret/authentication material, ability to assume another role, role creator feasibility, or complete visibility if catalog access is restricted. It deliberately does not select password/verifier fields.  
**Read-only:** yes. **Permissions/auth:** authenticated database query; catalog visibility. **Failure/incomplete output:** preserve uncertainty; do not interpret missing rows as absent roles until visibility is established.

### 4. Direct role membership edges and option flags

```powershell
$sql = @'
SELECT member_role.rolname AS member_role,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       m.admin_option,
       m.inherit_option,
       m.set_option
FROM pg_catalog.pg_auth_members AS m
JOIN pg_catalog.pg_roles AS member_role ON member_role.oid = m.member
JOIN pg_catalog.pg_roles AS granted_role ON granted_role.oid = m.roleid
JOIN pg_catalog.pg_roles AS grantor_role ON grantor_role.oid = m.grantor
ORDER BY member_role.rolname, granted_role.rolname, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Direct membership query failed; stop.' }
```

**Expected:** one row per catalog membership edge, including grantor and PostgreSQL 17 ADMIN/INHERIT/SET options. Direction matters: `member_role` is granted membership in `granted_role`; it does not mean the reverse role can access the member.  
**Proves:** direct membership edges visible in `pg_auth_members`.  
**Does not prove:** transitive reachability, role attributes' effective use, whether all catalog rows are visible, or actual migration identity. Follow each edge from member to granted role to interpret reachability.  
**Read-only:** yes. **Permissions/auth:** catalog query access. **Failure/zero rows:** query failure means unknown; zero rows only means no direct memberships were returned, not proof that role inventory/visibility is complete.

### 5. Transitive and SET-reachable role paths for known principals

This query follows membership in the correct direction and prevents cycles. Principals include `postgres`, API roles, the historical read-only query role, and platform roles named in previous evidence. The role inventory above must be reviewed to distinguish an absent principal from a principal with no membership edges.

```powershell
$sql = @'
WITH RECURSIVE principals(rolname) AS (
  VALUES ('postgres'::name), ('anon'::name), ('authenticated'::name),
         ('authenticator'::name), ('service_role'::name),
         ('supabase_read_only_user'::name), ('supabase_privileged_role'::name),
         ('supabase_admin'::name), ('supabase_etl_admin'::name)
), roots AS (
  SELECT r.oid AS root_oid, r.rolname AS root_name, r.rolinherit AS root_inherit
  FROM principals p JOIN pg_catalog.pg_roles r ON r.rolname = p.rolname
), role_paths(
  root_oid, root_name, root_inherit, member_oid, granted_role_oid, grantor_oid,
  depth, oid_path, admin_option, inherit_option, set_option,
  all_inherit_options, all_set_options
) AS (
  SELECT roots.root_oid, roots.root_name, roots.root_inherit,
         m.member, m.roleid, m.grantor, 1,
         ARRAY[m.member, m.roleid]::oid[],
         m.admin_option, m.inherit_option, m.set_option,
         m.inherit_option, m.set_option
  FROM roots
  JOIN pg_catalog.pg_auth_members m ON m.member = roots.root_oid
  UNION ALL
  SELECT p.root_oid, p.root_name, p.root_inherit,
         m.member, m.roleid, m.grantor, p.depth + 1,
         p.oid_path || m.roleid,
         m.admin_option, m.inherit_option, m.set_option,
         p.all_inherit_options AND m.inherit_option,
         p.all_set_options AND m.set_option
  FROM role_paths p
  JOIN pg_catalog.pg_auth_members m ON m.member = p.granted_role_oid
  WHERE NOT m.roleid = ANY (p.oid_path)
)
SELECT p.root_name AS starting_principal,
       p.root_inherit AS starting_role_rolinherit,
       p.depth,
       member_role.rolname AS membership_member,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       p.admin_option, p.inherit_option, p.set_option,
       p.all_inherit_options, p.all_set_options,
       pg_has_role(p.root_oid, p.granted_role_oid, 'MEMBER') AS reachable_membership,
       pg_has_role(p.root_oid, p.granted_role_oid, 'USAGE') AS effective_inherited_privileges,
       pg_has_role(p.root_oid, p.granted_role_oid, 'SET') AS can_set_role,
       granted_role.rolsuper, granted_role.rolcreaterole,
       granted_role.rolcreatedb, granted_role.rolbypassrls
FROM role_paths p
JOIN pg_catalog.pg_roles member_role ON member_role.oid = p.member_oid
JOIN pg_catalog.pg_roles granted_role ON granted_role.oid = p.granted_role_oid
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = p.grantor_oid
ORDER BY p.root_name, p.depth, member_role.rolname, granted_role.rolname, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Membership path query failed; stop.' }
```

**Expected:** path rows for each reachable membership chain; every direct edge retains its own grantor/options and path-level all-edge INHERIT/SET flags.  
**Proves:** graph paths rooted at the listed existing principals and PostgreSQL's `pg_has_role` membership/USAGE/SET answers for returned targets.  
**Does not prove:** paths from roles omitted from the principal list, privileges available through object grants, or which identity migrations actually use. It does not calculate ADMIN reachability as an effective boolean; inspect ADMIN flags on each edge and role inventory. Add any newly discovered candidate migration/runtime principal in a reviewed query revision before relying on it.  
**Read-only:** yes. **Permissions/auth:** membership/catalog visibility and `pg_has_role` inquiry access. **Failure or missing roots:** compare against command 3; do not treat missing rows as denial. Do not mistake membership direction (role can assume granted role) for granted role accessing member.

### 6. Schema ownership, direct grant options, and effective privileges

```powershell
$sql = @'
SELECT n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       CASE WHEN x.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS grantee,
       grantor_role.rolname AS grantor,
       x.privilege_type,
       x.is_grantable
FROM pg_catalog.pg_namespace n
CROSS JOIN LATERAL aclexplode(COALESCE(n.nspacl, acldefault('n', n.nspowner))) x
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = x.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = x.grantor
WHERE n.nspname !~ '^pg_' AND n.nspname <> 'information_schema'
ORDER BY n.nspname, grantee, x.privilege_type, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Schema ACL query failed; stop.' }
```

```powershell
$sql = @'
SELECT d.datname AS database_name,
       pg_get_userbyid(d.datdba) AS database_owner,
       CASE WHEN x.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS grantee,
       grantor_role.rolname AS grantor,
       x.privilege_type,
       x.is_grantable
FROM pg_catalog.pg_database d
CROSS JOIN LATERAL aclexplode(COALESCE(d.datacl, acldefault('d', d.datdba))) x
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = x.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = x.grantor
WHERE d.datname = current_database()
ORDER BY grantee, x.privilege_type, grantor_role.rolname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Database ACL query failed; stop.' }
```

```powershell
$sql = @'
SELECT r.rolname AS checked_role,
       n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       has_schema_privilege(r.oid, n.oid, 'USAGE') AS effective_usage,
       has_schema_privilege(r.oid, n.oid, 'CREATE') AS effective_create,
       has_schema_privilege(r.oid, n.oid, 'CREATE WITH GRANT OPTION') AS effective_create_grant_option,
       has_database_privilege(r.oid, current_database(), 'CONNECT') AS effective_db_connect,
       has_database_privilege(r.oid, current_database(), 'CREATE') AS effective_db_create,
       has_database_privilege(r.oid, current_database(), 'TEMPORARY') AS effective_db_temp
FROM pg_catalog.pg_roles r
CROSS JOIN pg_catalog.pg_namespace n
WHERE r.rolname IN ('postgres','anon','authenticated','authenticator','service_role',
                    'supabase_read_only_user','supabase_privileged_role',
                    'supabase_admin','supabase_etl_admin')
  AND n.nspname IN ('public','private','auth','extensions','supabase_migrations')
ORDER BY r.rolname, n.nspname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Effective privilege query failed; stop.' }
```

**Expected:** schema and database owners, direct ACL grantees/grantors/grantable options, and effective privileges for existing listed principals.  
**Proves:** catalog ACL entries plus effective checks for the named roles only. The third query includes `postgres` as a historical candidate, **not** as a presumed migration operator.  
**Does not prove:** privileges of an unknown migration operator; actual grantor authority to transfer objects; role membership absent from the graph; whether Supabase permits a future grant/revoke; or that effective CREATE implies CREATE WITH GRANT OPTION. `is_grantable` is the direct ACL option; effective checks are distinct. Add a discovered migration identity only after it is actually observed.  
**Read-only:** yes. **Permissions/auth:** catalog access and PostgreSQL privilege inquiry functions. **Failure/missing role rows:** compare with role inventory; absent query rows are not a pass. If `aclexplode` or inquiry is denied/unsupported, stop and record unknown rather than replacing it with weaker assumptions.

### 7. Private schema existence and ownership

```powershell
$sql = @'
SELECT n.nspname AS schema_name,
       pg_get_userbyid(n.nspowner) AS schema_owner,
       n.nspacl IS NULL AS uses_default_acl
FROM pg_catalog.pg_namespace n
WHERE n.nspname = 'private';
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Private schema query failed; stop.' }
```

**Expected:** one row if `private` exists; zero rows if no matching namespace is visible.  
**Proves:** existence/owner/ACL-null state for schema `private`. **Does not prove:** that no private/internal schema exists under a different name, access behavior, or that no schema creation is possible.  
**Read-only:** yes. **Permissions/auth:** catalog visibility. **Failure/zero rows:** query failure is unknown; zero rows must be interpreted with successful catalog visibility and cross-checked against command 6.

### 8. Migration history relation and records

First inspect whether the conventional relation exists without selecting from a possibly absent relation:

```powershell
$sql = @'
SELECT n.nspname AS schema_name, c.relname, c.relkind,
       pg_get_userbyid(c.relowner) AS relation_owner
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'supabase_migrations'
  AND c.relname = 'schema_migrations';
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Migration history relation check failed; stop.' }
```

Then list CLI migration history using the repository-documented syntax:

```powershell
npx --no-install supabase migration list --remote=bhnhhaurdnnalcozsviq
if ($LASTEXITCODE -ne 0) { throw 'Migration history listing failed; do not infer history.' }
```

**Expected:** catalog row if conventional history relation exists; CLI displays local/remote migration versions if accessible. Local migrations directory is historically absent, but recheck locally.  
**Proves:** existence/owner of that specific relation; `migration list` reports migration-history comparison for this explicit project, if the command completes.  
**Does not prove:** that the database has no schema when the list is empty; migration history may be absent/incomplete while objects exist. Does not establish migration identity or prove the `migration list` identity equals `db push`.  
**Read-only:** catalog `SELECT` is read-only. The repository documents `migration list` as a listing operation that applies no migrations; no `--read-only` flag is documented for it. Inspect installed `--help` first and stop on changed semantics. **Permissions/auth:** CLI authentication and required project/database read access. **Failure:** record history as unknown, not empty; no `migration repair` or push.

### 9. Known legacy fixture/role-name collision checks

Only names already present in repository validation material are included. New Phase 4.3 role/function fixture names are not specified, so they cannot safely be invented here. Do not execute a later mutation until its exact reviewed names have a collision query added.

```powershell
$sql = @'
SELECT 'role: incux_rpc_owner' AS object_name,
       EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'incux_rpc_owner') AS already_exists
UNION ALL
SELECT 'table: public.phase_2_6_validation_table',
       to_regclass('public.phase_2_6_validation_table') IS NOT NULL
UNION ALL
SELECT 'view: public.phase_2_6_validation_view',
       to_regclass('public.phase_2_6_validation_view') IS NOT NULL
UNION ALL
SELECT 'function: public.phase_2_6_validation_rpc()',
       to_regprocedure('public.phase_2_6_validation_rpc()') IS NOT NULL
UNION ALL
SELECT 'view: private.phase_2_6_validation_view',
       to_regclass('private.phase_2_6_validation_view') IS NOT NULL
UNION ALL
SELECT 'function: private.phase_2_6_validation_rpc()',
       to_regprocedure('private.phase_2_6_validation_rpc()') IS NOT NULL;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Known collision query failed; stop.' }
```

**Expected:** six named objects with true/false collision values. A missing `private` schema yields false for its relation lookups but does not validate schema readiness.  
**Proves:** exact legacy role, table, view and zero-argument function names are or are not resolvable in the selected database.  
**Does not prove:** absence of overloads, names not in this list, ownership safety, or that these legacy Phase 2.6 names are appropriate for Phase 4.3 tests. Role names for new domain owners/runtimes remain unspecified.  
**Read-only:** yes. **Permissions/auth:** catalog lookup. **Failure:** no mutation; stop and review. Any collision is not to be cleaned up by this command sheet.

### 10. Function ownership, security attributes and EXECUTE ACLs

```powershell
$sql = @'
SELECT n.nspname AS function_schema,
       p.proname AS function_name,
       pg_get_function_identity_arguments(p.oid) AS identity_arguments,
       pg_get_function_result(p.oid) AS result_type,
       pg_get_userbyid(p.proowner) AS function_owner,
       p.prosecdef AS security_definer,
       p.provolatile AS volatility,
       p.proconfig AS function_settings,
       CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE grantee_role.rolname END AS execute_grantee,
       grantor_role.rolname AS acl_grantor,
       a.privilege_type,
       a.is_grantable
FROM pg_catalog.pg_proc p
JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) a
LEFT JOIN pg_catalog.pg_roles grantee_role ON grantee_role.oid = a.grantee
JOIN pg_catalog.pg_roles grantor_role ON grantor_role.oid = a.grantor
WHERE n.nspname IN ('public','private')
  AND p.prokind IN ('f','p')
ORDER BY n.nspname, p.proname, pg_get_function_identity_arguments(p.oid), execute_grantee;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Function ownership/ACL query failed; stop.' }
```

**Expected:** existing functions/procedures, signatures/results, owner, SECURITY DEFINER flag, settings such as `search_path`, and effective ACL entries (including PUBLIC).  
**Proves:** catalog properties of visible `public`/`private` routines. For PostgreSQL ACLs, absence of an explicit ACL uses the default, which this query expands.  
**Does not prove:** function body safety, transitive nested calls, dynamic SQL safety, trigger attachment, actual caller authorization, or source-code correspondence. This is an inventory, not an approval of current functions.  
**Read-only:** yes. **Permissions/auth:** catalog and ACL visibility; `aclexplode` support. **Failure/incomplete output:** treat as unknown; do not conclude no PUBLIC EXECUTE from missing rows unless the query succeeded and default ACL handling is understood.

### 11. RLS policy inventory

```powershell
$sql = @'
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_catalog.pg_policies
WHERE schemaname NOT IN ('pg_catalog','information_schema')
ORDER BY schemaname, tablename, policyname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'RLS policy query failed; stop.' }
```

**Expected:** policy rows for tables with policies, including roles/commands and USING/WITH CHECK expressions. Zero rows can mean no policies or restricted/incomplete visibility; correlate with table RLS flags.  
**Proves:** policy definitions visible through `pg_policies`.  
**Does not prove:** RLS is enabled/forced on every table, policy behavior for a real JWT, absence of bypass roles, grants, view semantics, or that an empty result means RLS security.  
**Read-only:** yes. **Permissions/auth:** catalog visibility. **Failure:** unknown; do not infer protection.

The following companion query reports table RLS flags independently:

```powershell
$sql = @'
SELECT n.nspname AS table_schema,
       c.relname AS table_name,
       pg_get_userbyid(c.relowner) AS table_owner,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind IN ('r','p')
  AND n.nspname NOT IN ('pg_catalog','information_schema')
ORDER BY n.nspname, c.relname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'RLS flag query failed; stop.' }
```

**Expected/proves:** visible ordinary/partitioned table owners and `relrowsecurity`/`relforcerowsecurity` flags. **Does not prove:** policy correctness or that a privileged role cannot bypass RLS. **Read-only:** yes. **Permissions/auth:** catalog visibility. **Failure:** unknown.

### 12. Audit and outbox infrastructure inventory

```powershell
$sql = @'
SELECT n.nspname AS object_schema,
       c.relname AS object_name,
       c.relkind AS relation_kind,
       pg_get_userbyid(c.relowner) AS object_owner,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname NOT IN ('pg_catalog','information_schema')
  AND (lower(c.relname) LIKE '%audit%'
       OR lower(c.relname) LIKE '%outbox%'
       OR lower(c.relname) LIKE '%inbox%'
       OR lower(c.relname) LIKE '%webhook%')
ORDER BY n.nspname, c.relname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Audit/outbox relation query failed; stop.' }
```

```powershell
$sql = @'
SELECT trigger_schema.nspname AS table_schema,
       table_rel.relname AS table_name,
       trigger_def.tgname AS trigger_name,
       trigger_def.tgenabled AS trigger_enabled_state,
       function_schema.nspname AS function_schema,
       trigger_func.proname AS trigger_function,
       pg_get_userbyid(trigger_func.proowner) AS trigger_function_owner,
       trigger_func.prosecdef AS trigger_security_definer,
       pg_get_triggerdef(trigger_def.oid, true) AS trigger_definition
FROM pg_catalog.pg_trigger trigger_def
JOIN pg_catalog.pg_class table_rel ON table_rel.oid = trigger_def.tgrelid
JOIN pg_catalog.pg_namespace trigger_schema ON trigger_schema.oid = table_rel.relnamespace
JOIN pg_catalog.pg_proc trigger_func ON trigger_func.oid = trigger_def.tgfoid
JOIN pg_catalog.pg_namespace function_schema ON function_schema.oid = trigger_func.pronamespace
WHERE NOT trigger_def.tgisinternal
  AND (lower(table_rel.relname) LIKE '%audit%'
       OR lower(table_rel.relname) LIKE '%payment%'
       OR lower(table_rel.relname) LIKE '%outbox%'
       OR lower(table_rel.relname) LIKE '%inbox%'
       OR lower(trigger_def.tgname) LIKE '%audit%'
       OR lower(trigger_func.proname) LIKE '%audit%'
       OR lower(trigger_func.proname) LIKE '%outbox%')
ORDER BY trigger_schema.nspname, table_rel.relname, trigger_def.tgname;
'@
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Audit/outbox trigger query failed; stop.' }
```

**Expected:** relations whose names indicate audit/outbox/inbox/webhook, and matching noninternal triggers with enabled state and trigger-function owner/security.  
**Proves:** name-matching catalog objects and trigger definitions visible to this query.  
**Does not prove:** an object with a different name does not exist, trigger logic is correct, audit is append-only, actor identity is authentic, trigger is actually invoked in application flows, or outbox processing is durable/idempotent. Query table columns separately only after exact objects are identified; do not select audit/payment row contents.  
**Read-only:** yes. **Permissions/auth:** catalog visibility. **Failure/empty results:** query failure is unknown; empty result is only “no matching names visible,” not proof of no audit/outbox system.

## 6. Migration history interpretation

Use both command 8 catalog existence check and `migration list`. An empty local/remote comparison means no differing migration files were reported; it **does not** prove the application schema is empty or current. Schema objects may predate migration tracking, be manually created, be hidden by permissions, or reside outside the inspected schemas. Do not run `db push`, `migration repair`, DDL, or a migration probe as a response to an empty list.

## 7. Output recording and failure handling

- Save the exact nonsecret command text, UTC/local timestamp, operator, CLI version, approved target name/ref/region, sanitized output, exit code and review notes.
- Never capture environment-variable values, token files, process command lines containing secrets, connection strings, passwords, API keys or database URLs. The queries do not request credential columns.
- Preserve query errors. A timeout, permission error, missing role, empty output, missing relation, or unsupported catalog function is **unknown/unverified**, not a successful negative result.
- Verify that each `db query` output echoes the exact disposable project name/ref before accepting its SQL result. If the CLI prints a production label, stop for manual resolution even when the explicit ref appears correct.
- Do not execute any existing `.sql` file wholesale. Copy only the reviewed read-only statement for the single approved diagnostic.

## 8. Required permissions/authentication

The inspected repository documents Supabase CLI 3.1.0 and the command forms above, but does not define exact required OAuth scopes for these queries. Expected prerequisites are:

- locally authenticated Supabase CLI access to the explicit disposable project for `db query` and `migration list`;
- a remote database query route/identity permitted to read the relevant system catalogs and run the listed inquiry functions;
- additional project/database access for `migration list`, whose actual route/identity must not be assumed to equal `db query`.

If authentication is unavailable, do not inspect or print secret values to diagnose it. Ask the project operator to restore the approved CLI authentication path, then rerun only the reviewed read-only command. A successful login alone does not establish PostgreSQL migration identity.

## 9. Operator review checklist

Before running any command:

- [ ] Confirm this command sheet is approved for remote read-only diagnostics; no migration/DDL approval is implied.
- [ ] Confirm Dashboard name `incuxai-hackathon-validation`, ref `bhnhhaurdnnalcozsviq`, region `ap-south-1`.
- [ ] Confirm each database command contains the literal `--remote=bhnhhaurdnnalcozsviq` and `--read-only` where supported.
- [ ] Confirm no command uses local link defaults, production ref, `db push`, `db reset`, `migration repair`, or a SQL script file.
- [ ] Confirm CLI version/help matches repository-documented syntax before remote access.
- [ ] Confirm the CLI-resolved target output matches the approved name/ref; stop on any `production` label ambiguity.
- [ ] Check nonzero exit codes immediately and treat missing/empty/incomplete catalog output as unknown until visibility is established.
- [ ] Keep outputs sanitized and never print secrets.
- [ ] Do not infer migration identity, object owner, privilege success, schema emptiness, or RLS safety from these read-only checks.
- [ ] Stop after the read-only baseline. Request separate approval before any identity probe, role creation, grant, revoke, function ownership change, migration, fixture creation or cleanup.

**Final status:** command sheet prepared only. No commands were executed, no project was contacted, and no disposable target was freshly verified.
