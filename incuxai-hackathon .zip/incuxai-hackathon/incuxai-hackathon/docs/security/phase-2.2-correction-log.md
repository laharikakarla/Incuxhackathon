# Phase 2.2 correction log

**Scope:** documentation-only correction of the five Phase 2 design files. The SQL is marked **NOT EXECUTED**. No Supabase connection, SQL execution, migration creation, frontend change, dependency change, commit, or push was performed.

## Audit issues addressed

| Audit issue | Severity | Correction and location |
|---|---|---|
| RLS enabled without usable access policies, grants, safe function bodies, or default-deny rules | Critical | Added named RLS policies for all 59 tables, `FORCE ROW LEVEL SECURITY`, revokes/default privileges, limited column grants, safe views, fixed-search-path helper/RPC functions, owner role `NOBYPASSRLS`, and explicit execute ACL allow-lists in [schema draft](../database/phase-2-schema-draft.sql), authorization sections. Matrix documents the intended boundary in [RLS matrix](phase-2-rls-matrix.md). |
| User-editable role/permission data or direct writes could affect privileged status | Critical | Protected role/permission tables; trusted audited grant/revoke functions; prevent self-grant/self-revoke; service-only Super Admin transfer. Registration, payment, team payment, evaluation, and certificate state transitions use restricted RPCs. Schema authorization and role-management functions. |
| Payment amount/order/transaction/refund/receipt relationships were not reliably bound | Critical | Added composite keys/FKs for fee snapshot, transaction/order/snapshot, successful applied transaction, refund/order/transaction, and receipt/success transaction. Added duplicate constraints, webhook event digests/attempt history, immutable paid facts, and transaction-backed success. Schema payment DDL and payment RPC section; architecture payment section; relationships payment map. |
| Refunds could overspend under concurrency | High | `payment_request_refund` locks the order/transaction and reserves requested, processing, and succeeded refunds against that capture; service result transition is restricted and monotonic. Schema refund RPC/guards. |
| Duplicate or late provider captures could incorrectly pay an order | High | Gateway event/transaction uniqueness plus unapplied late/duplicate capture retention; only a verified successful transaction selected as applied can pay the order. Webhook processing function and payment architecture. |
| Fee changes could rewrite pending/existing order amounts | High | Immutable fee versions, old/new amount and actor/reason/time, effective-time ordering, cancellation history; order retains amount/currency/version and expires in 24 hours. Schema fee/order constraints and architecture. |
| Team membership race conditions, multiple active teams, leader/size ambiguity | High | Partial unique indexes, policy-version FK, leader counted in roster, deferred exact-one-leader/size assertion, team-row locks and one-transaction trusted operations. Schema team DDL/RPCs; relationship map. |
| Invitations, join requests, removal, leader changes, dissolution and roster lock were not consistently trusted | High | Added atomic functions for create/join/request/invitation accept/respond/revoke/withdraw/expire, removal, transfer, dissolution, roster lock, and payment exception; registered-user invitation default. Schema team RPCs and matrix. |
| Payment initiation/expiry and roster state could diverge | High | Order creation locks roster; cancel/fail/expire unlocks; success remains locked; post-payment changes require Super Admin audited exception. Architecture and schema functions. |
| Judge could submit for a non-assigned judge/rubric or access another evaluation | High | Composite assignment/evaluation/rubric/criterion keys; active duplicate assignment index; score bound trigger; current unconflicted assignment checks; submitted lock and explicit release permission. Evaluation schema, RLS policies, and RPC ACLs. |
| Recruiter access lacked consent and explicit revocation boundaries | High | Active role + recruiter access grant + latest consent scope/version checks; append-only consent events; account-private notes/shortlists; no shared workspaces; candidate projection excludes finance, team discussion, and judging. Schema, architecture, matrix. |
| Moderators/recruiters could cross into private discussions or evaluations | High | Separate team discussion tables and current-member checks; no moderator discussion policy; recruiter permissions scoped to candidate projections; judge score access assignment-bound. RLS matrix and SQL policy section. |
| Community parent comments/reports could point to unrelated content | Medium | Same-post parent/comment checks and cycle prevention; moderation action must match the locked report target. Schema triggers/RPC. |
| Certificate verification could expose identity or enable enumeration | Medium | Server-generated unpredictable codes; restricted record access; safe verifier returns validity/type/consented name only; name consent revocation; verification log and DB/global plus Edge per-source rate-limit design. Schema and architecture. |
| Lifecycle state/time fields and transitions lacked consistency/audit | High | Added checks/transition guards and audited functions across registration, invitation/request, payment, refund, submission, moderation, evaluation, certificates, and deadline versions. Schema audit triggers/functions. |
| Missing lookup/FK indexes and unclear index purpose | Medium | Added FK/reference and operational indexes for team lookup, ownership, transactions/refunds/webhooks, recruiter consent, assignment/evaluation, notification, and audit access. Schema index section; architecture performance section. |
| Missing product choices were implicit or invented | Medium | Split adopted defaults from unresolved choices; no fee, team limits, event dates, eligibility, consent text, judge rules, certificate criteria, or retention periods were invented. Security review. |

## Additional documentation alignment

- [Architecture](../database/phase-2-architecture.md) now states the single-event scope, corrected team/payment/recruiter/judge model, default order lifetime, trusted operations, and unresolved decisions.
- [Relationships](../database/phase-2-relationships.md) now reflects actual policy-version, payment snapshot, assigned-rubric, consent, discussion, and certificate relations.
- [RLS matrix](phase-2-rls-matrix.md) distinguishes raw-table access from safe views/RPCs and states the row/column privilege boundary.
- [Security review](phase-2-security-review.md) separates defaults from product-owner decisions.

## Assumptions introduced

1. A 24-hour order expiry is the default; it is configurable and must be confirmed before implementation.
2. Invitations initially target an already registered Auth user by ID; email-only invitation is deferred.
3. A team uses the size policy version active at creation; policy versions are preserved and do not silently rewrite existing rosters.
4. Shared recruiter workspaces are excluded; notes/shortlists belong to a single recruiter account.
5. Duplicate/late successful gateway captures are retained as unapplied transactions for refund/reconciliation rather than silently applying or discarding them.
6. Certificate verification has a proposed global database ceiling of 120 calls/minute plus per-source Edge rate limiting. This is a provisional operational threshold, not a product-approved value.
7. The draft uses Razorpay as a future provider label for schema planning only; no gateway integration or secrets are present.

## Unresolved issues and limits

- Product decisions listed in [the updated security review](phase-2-security-review.md#unresolved-decisions) remain open.
- SQL syntax, trigger semantics, role ownership, view behavior, RLS behavior, PostgREST exposure, and function privileges have not been validated against a running PostgreSQL/Supabase version.
- Storage bucket policies, Edge Function signature verification, key rotation, provider reconciliation, rate limiting, and operational monitoring remain design requirements; no service configuration was made.
- Adversarial access tests and concurrency tests remain necessary before implementation review. Static checks do not establish production readiness.
