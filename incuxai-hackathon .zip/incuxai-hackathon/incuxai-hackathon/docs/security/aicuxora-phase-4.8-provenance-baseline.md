# AICUXORA Phase 4.8 — Provenance-Verified Read-Only Baseline

**Prepared:** 2026-11-13 (workspace date; not a database capture timestamp)  
**Scope:** Static review of repository evidence only. No Supabase connection, SQL execution, migration, or database mutation was performed.  
**Permitted target for future diagnostics:** `incuxai-hackathon-validation` / `bhnhhaurdnnalcozsviq` / `ap-south-1`. This target was not freshly verified during this review.

## 1. Executive summary

The Phase 4.7 report consolidates operator-reported read-only results. The repository contains one raw result file, `section5-membership-output.csv`, but that file has no embedded project reference, collection timestamp, command transcript, or query-runner identity. The corresponding `section5-preflight.sql` is present and has matching membership fields, but there is no captured execution transcript proving that this exact query generated the CSV.

The other `section3-preflight.sql`, `section4-preflight.sql`, and `section6-preflight.sql` files are query templates, not output evidence. The Phase 4.7 identity, schema, migration-history, no-row, function, policy, and audit/outbox results are recorded as operator summaries without their raw query outputs. Prior Phase 4.5/4.6 documents explicitly prepared and reviewed commands without running them. The historical Phase 2.14 report includes earlier evidence and failed-authentication history, but does not establish provenance for the Phase 4.7 collection.

Accordingly, there are **no newly verified live database facts in this report**. The CSV is a locally inspectable artifact whose contents are visible, but the project and time to which it belongs cannot be proven from the artifact alone. Migration identity remains unknown. The baseline is not fully provenance-verified; backend implementation and migration execution remain **NO-GO**.

## 2. Evidence inventory and provenance

File timestamps shown by the local filesystem are not treated as database capture times: copying, syncing, or editing can change them. No timestamp has been inferred from file metadata.

| Evidence item | Exact query/command represented | Target reference | Capture timestamp | Database identity | Original evidence form | What it supports | Limitations |
|---|---|---|---|---|---|---|---|
| `section5-membership-output.csv` | It appears to correspond to the recursive membership query in `section5-preflight.sql`. The query selects role membership edges, grantor, `admin_option`, `inherit_option`, `set_option`, path summaries, and role attributes. | Not embedded. Phase 4.7 request/report associates the supplied results with `bhnhhaurdnnalcozsviq`; that is operator-provided context, not CSV provenance. | Not present. | Not present in CSV. The query source filters from `postgres`; no transcript records `session_user` or `current_user` at execution. | CSV artifact, 15 data rows plus header. | Its stored rows report the memberships and options shown in Section 3 below. | Cannot prove target, capture time, collector, exact executed SQL, successful completion, catalog visibility, or that it belongs to the Phase 4.7 run. `postgres`-rooted paths are not the entire role inventory. |
| `section5-preflight.sql` | Exact SQL is the file itself; it starts with `WITH RECURSIVE role_paths ...` and filters `login_role.rolname = 'postgres'`. | None; SQL source only. | Not applicable; local file metadata is not execution time. | None. | SQL query template. | Shows how the CSV could have been produced and which membership fields it intends to inspect. | A prepared query is not proof of execution. Its root is only `postgres`; it does not establish paths for every other principal. |
| `section3-preflight.sql` | Prepared identity/version and `postgres` schema/database privilege query. It selects database/session/current identity, server version, operator attributes, owner and privilege inquiries. | None; SQL source only. | Not applicable. | None. | SQL query template. | Intended diagnostic fields. | Not execution evidence. It includes the obsolete invalid `has_schema_privilege(..., 'CREATE WITH GRANT OPTION')` expression; do not reuse this file as-is. Use the reviewed corrected Phase 4.6 query instead. |
| `section4-preflight.sql` | Prepared `EXISTS` checks for legacy `incux_rpc_owner` and six Phase 2.6 fixture names. | None; SQL source only. | Not applicable. | None. | SQL query template. | Exact legacy names it checks. | Not execution evidence and not the approved name manifest for Phase 4.3 fixtures or proposed domain/runtime roles. |
| `section6-preflight.sql` | Prepared role attribute and API-role-to-`incux_rpc_owner` membership checks. | None; SQL source only. | Not applicable. | None. | SQL query template. | Intended checks for API role attributes and membership in the legacy owner role. | Not execution evidence; the owner role may not exist; no check of future domain owners; not a complete membership graph. |
| Phase 4.7 report | Summarized CLI version, target, PostgreSQL/database identity, schemas, migration-history relations, empty-result queries, function/policy inventory and audit/outbox inventory. Exact SQL is not reproduced for each summary. | Says `bhnhhaurdnnalcozsviq`; also names the disposable project and region. | Assessment date 2026-11-13 is the report date only, not a capture time for every query. | Reports read-only query `session_user=current_user=supabase_read_only_user`; raw identity output is not attached. | Narrative summary. | Records what the operator reported and explicitly preserves several limitations. | Cannot be independently tied to a particular CLI invocation, target output, timestamp, exit code, raw result, or query identity beyond the summary. |
| Phase 4.5 command sheet | Proposed read-only commands. | Hardcoded disposable ref in proposed commands. | None. | None. | Prepared document. | Documents an intended diagnostic sequence. | It explicitly says commands were not executed; one grant-option query was invalid and superseded by Phase 4.6. |
| Phase 4.6 command review | Corrected command sequence, including `npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only ...`. | Explicit disposable reference in proposed commands. | None. | None. | Static review and command templates. | Corrects SQL/interpretation and gives an operator sequence. | It explicitly says no command was run and no project contacted. It is not result evidence. |
| Phase 2.14 read-only preflight and later planning/review docs | Historical local-authentication attempts, earlier operator-provided evidence, command plans, and migration-identity uncertainty. | Historical reports mention the disposable ref. | Individual query capture times are not established by the material reviewed here. | Earlier read-only identity is reported, not migration identity. | Reports/plans. | Provides historical context and prior limitations. | Must not be substituted for current raw evidence or treated as proof of migration execution identity. |

The Phase 4.7 report's phrase “operator reports” is retained as the evidence source for its summarized findings. The source files prove only that query text exists locally; they do not prove the queries were run.

## 3. Membership CSV: directly inspectable contents

The CSV has 15 rows. For rows at depth 1, `postgres` is the **member** and the listed `granted_role` is the role to which membership is granted. This direction must not be reversed. The file reports all these direct edges as granted by `supabase_admin`:

| Granted role | ADMIN | INHERIT | SET |
|---|---:|---:|---:|
| `anon` | true | true | true |
| `authenticated` | true | true | true |
| `authenticator` | true | true | true |
| `pg_create_subscription` | true | true | true |
| `pg_monitor` | true | true | true |
| `pg_read_all_data` | true | true | true |
| `pg_signal_backend` | true | true | true |
| `service_role` | true | true | true |
| `supabase_privileged_role` | false | true | true |

The CSV also reports these depth-2 edges:

- `authenticator` is a member of `anon`, `authenticated`, and `service_role`; each edge has `ADMIN=false`, `INHERIT=false`, `SET=true`.
- `pg_monitor` is a member of `pg_read_all_settings`, `pg_read_all_stats`, and `pg_stat_scan_tables`; each edge has `ADMIN=false`, `INHERIT=true`, `SET=true`.

These statements describe the CSV contents, not freshly verified project state. They do not mean that API roles can assume `postgres`; the shown direction is the opposite. Since the query begins only from `postgres`, absence of other principals from this CSV is not evidence that they lack other membership paths.

## 4. Provenance completeness matrix

| Topic | Phase 4.7 reported result | Raw evidence in repository | Provenance status | Safe conclusion now |
|---|---|---|---|---|
| Target project/reference/region | Disposable project, `bhnhhaurdnnalcozsviq`, `ap-south-1` | Narrative report only; no sanitized CLI target line or Dashboard evidence attached | Incomplete | Target is operator-reported; not freshly verified here. |
| CLI version | `3.1.0` | Narrative report only | Incomplete | Operator-reported CLI version; does not identify a database role. |
| PostgreSQL/database identity | PostgreSQL `17.11`, database `postgres`, `session_user=current_user=supabase_read_only_user` | Narrative report only; no raw query output | Incomplete | Read-only query identity is reported, not independently verified by this review. |
| Full role inventory | Role/membership observations described | Only a `postgres`-rooted membership CSV; no complete `pg_roles` output | Missing/incomplete | Cannot claim complete role inventory or catalog visibility. |
| Full membership graph | Direct/transitive rows from root `postgres` | CSV, but no execution provenance; no complete all-principal graph | Incomplete | CSV rows can be described; full current graph cannot be established. |
| Schema ownership/privileges | Summary says checks were collected | No raw schema ACL/effective privilege output | Missing raw evidence | No exact owner, grantor, grant option, or effective-permission finding can be independently checked. |
| Migration-history relations/columns | Service-specific history relations and columns reportedly found | No relation/column output or exact names in supplied result artifact | Missing raw evidence | Exact relation names, schema, columns, owner, and relationship to CLI history are unknown. |
| Application relations/data | No public application-table rows reportedly returned | No raw query/output | Missing raw evidence | Query/filter and meaning of “no rows” cannot be verified; do not infer schema emptiness. |
| Function ownership/security/ACL | No public functions reportedly returned | No raw query/output | Missing raw evidence | No verified function inventory; scope and visibility unknown. |
| RLS policies/table flags | No public policies reportedly returned | No raw query/output | Missing raw evidence | No verified policy or RLS-enabled/forced inventory. Zero policy rows would not prove safety. |
| Audit/outbox/event infrastructure | No matching relation names in public/private reportedly returned | No raw query/output | Missing raw evidence | Name/schema filter and catalog visibility unknown; no global absence claim. |
| `private` schema | Absent from inspected schema inventory | No raw namespace inventory | Missing raw evidence | Only operator-reported absence from the inspected query scope. |
| Migration identity/object owner | Explicitly unknown | No migration-path probe output (and none was authorized) | Unknown | Must remain unknown until observed through the actual deployment path. |

## 5. Verified, reported, and unverified findings

### Directly verified by static inspection of local artifacts

- The repository contains the Phase 4.5, 4.6, and 4.7 reports named above and the four `section*-preflight.sql` query files.
- The repository contains a CSV with 15 rows and the membership values transcribed in Section 3.
- The Phase 4.6 review says its commands were not executed and corrects the Phase 4.5 invalid grant-option inquiry. It distinguishes the query route from migration identity.
- The Phase 4.7 report itself labels most raw query results as operator summaries and describes the CSV provenance limitation.

### Reported but not independently provenance-verified

- CLI 3.1.0; target name/reference/region; PostgreSQL 17.11; `database=postgres`; read-only `session_user` and `current_user` as `supabase_read_only_user`.
- Service-specific migration-history relations/columns reportedly exist.
- No rows for public application tables, public RLS policies, public functions, or matching audit/outbox/event names in public/private; `private` reportedly absent from the inspected inventory.
- The operator says no mutation was run in the Phase 4.7 collection.

### Unverified / must not be inferred

- That the CSV was produced by the local query file or by a query against the currently authorized disposable project.
- Complete role inventory, complete membership graph, effective migration-operator capabilities, schema CREATE grantability, and exact schema ownership/ACLs.
- Exact migration-history relation names/columns and their relation to Supabase CLI's migration tracking.
- Complete routine, policy, RLS-flag, audit, outbox, and trigger inventories across all relevant schemas.
- Actual migration `session_user`, `current_user`, effective role, newly created object owner, or identity used in subsequent migrations.
- Feasibility of creating/owning domain functions, safely replacing them later, or temporarily granting/revoking migration privileges.

## 6. Why migration identities must be established separately

These identities answer different questions and cannot be substituted for each other:

1. **CLI login identity** identifies the Supabase account or token used to request an operation. It is not necessarily a PostgreSQL role.
2. **Database `session_user`** is the database login identity for a particular connection.
3. **Database `current_user`** is the effective SQL identity at that point; role changes and `SECURITY DEFINER` execution can make it differ from `session_user`.
4. **Migration operator** means the identity and privileges actually used by the selected deployment workflow to execute migration statements. It must be observed through that workflow, not inferred from CLI authentication or a separate `db query` command.
5. **Object owner** is recorded on each created object and may differ from both connection identities if ownership is transferred or a role is assumed.

The prior `supabase_read_only_user` result describes only the diagnostic query route. A future identity probe must separately capture the CLI route, the migration connection's `session_user/current_user`, the owner of an inert object created by that migration, and the identities used for a subsequent migration. That probe changes database state and migration history and requires its own explicit approval.

## 7. Exact read-only commands needed to close evidence gaps

The following are **prepared only; not run by this review**. Run from the repository root in PowerShell, only after the operator independently confirms the Dashboard project name, reference, and region. Never rely on `supabase/config.toml` or local link state. Stop on target mismatch, query error, incomplete catalog output, or a nonzero exit code. Keep sanitized raw output with UTC capture time and exit code; do not include secrets.

### 7.1 Confirm CLI visibility of the exact disposable reference

```powershell
$expectedRef = 'bhnhhaurdnnalcozsviq'
$projects = npx --no-install supabase projects list
if ($LASTEXITCODE -ne 0) { throw 'Project listing failed; stop.' }
$targetRows = @($projects | Select-String -SimpleMatch $expectedRef)
if ($targetRows.Count -ne 1) { throw 'Expected exactly one disposable project row; verify manually and stop.' }
$targetRows | ForEach-Object { $_.Line }
```

This is account-level metadata, not a database query. It does not prove region unless shown in output, and it does not prove migration identity. Confirm the region in the Dashboard before proceeding.

### 7.2 Common explicit-target read-only invocation

For each SQL block below, set `$sql` to that exact here-string, then invoke:

```powershell
npx --no-install supabase db query --remote=bhnhhaurdnnalcozsviq --read-only $sql
if ($LASTEXITCODE -ne 0) { throw 'Read-only diagnostic failed; stop and record as unknown.' }
```

Confirm the CLI-resolved target in output for each invocation. The explicit reference must remain literal. This command form is taken from the reviewed Phase 4.6 sheet; verify local CLI help if the installed CLI differs. Do not execute a whole `.sql` file.

### 7.3 Database identity and PostgreSQL version

```powershell
$sql = @'
SELECT current_database() AS database_name,
       session_user AS session_user,
       current_user AS current_user,
       current_setting('server_version') AS server_version,
       current_setting('server_version_num') AS server_version_num;
'@
```

Expected: one row for this diagnostic connection only. Retain raw output and timestamp. It does not establish migration identity.

### 7.4 Complete visible role attributes and direct membership edges

Run both queries; neither selects password/credential fields:

```powershell
$sql = @'
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb,
       rolreplication, rolbypassrls, rolcanlogin, rolconnlimit
FROM pg_catalog.pg_roles
ORDER BY rolname;
'@
```

```powershell
$sql = @'
SELECT member_role.rolname AS member_role,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       m.admin_option, m.inherit_option, m.set_option
FROM pg_catalog.pg_auth_members AS m
JOIN pg_catalog.pg_roles AS member_role ON member_role.oid = m.member
JOIN pg_catalog.pg_roles AS granted_role ON granted_role.oid = m.roleid
JOIN pg_catalog.pg_roles AS grantor_role ON grantor_role.oid = m.grantor
ORDER BY member_role.rolname, granted_role.rolname, grantor_role.rolname;
'@
```

The direct-edge query provides the graph edges; interpret `member_role` as receiving membership in `granted_role`. To establish transitive reachability, retain the full direct-edge result and analyze paths from each relevant login (migration operator, API roles, proposed runtime roles, and owner roles). A catalog omission or permission error means incomplete evidence, not absence.

### 7.5 Schema/database ownership and ACLs

```powershell
$sql = @'
SELECT 'database' AS object_type, d.datname AS object_name,
       pg_get_userbyid(d.datdba) AS object_owner,
       CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE gr.rolname END AS grantee,
       grantor.rolname AS grantor, a.privilege_type, a.is_grantable
FROM pg_catalog.pg_database AS d
CROSS JOIN LATERAL aclexplode(COALESCE(d.datacl, acldefault('d', d.datdba))) AS a
LEFT JOIN pg_catalog.pg_roles AS gr ON gr.oid = a.grantee
JOIN pg_catalog.pg_roles AS grantor ON grantor.oid = a.grantor
WHERE d.datname = current_database()
UNION ALL
SELECT 'schema', n.nspname, pg_get_userbyid(n.nspowner),
       CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE gr.rolname END,
       grantor.rolname, a.privilege_type, a.is_grantable
FROM pg_catalog.pg_namespace AS n
CROSS JOIN LATERAL aclexplode(COALESCE(n.nspacl, acldefault('n', n.nspowner))) AS a
LEFT JOIN pg_catalog.pg_roles AS gr ON gr.oid = a.grantee
JOIN pg_catalog.pg_roles AS grantor ON grantor.oid = a.grantor
WHERE left(n.nspname, 3) <> 'pg_'
  AND n.nspname <> 'information_schema'
ORDER BY object_type, object_name, grantee, privilege_type;
'@
```

Also record effective checks for each candidate operator by substituting only a reviewed role name (never a secret):

```powershell
$sql = @'
SELECT current_database() AS database_name,
       has_database_privilege('postgres', current_database(), 'CREATE') AS postgres_database_create,
       has_schema_privilege('postgres', 'public', 'CREATE') AS postgres_public_create,
       has_schema_privilege('postgres', 'public', 'USAGE') AS postgres_public_usage,
       to_regnamespace('private') IS NOT NULL AS private_schema_exists,
       CASE WHEN to_regnamespace('private') IS NULL THEN NULL
            ELSE has_schema_privilege('postgres', 'private', 'CREATE') END AS postgres_private_create;
'@
```

Replace `postgres` only after the intended operator role is known. `has_*_privilege` tests effective privilege, not grant option; direct ACL `is_grantable` is separately shown above. These read-only queries do not prove that the migration route actually uses the named operator or that it can transfer ownership.

### 7.6 Migration-history relations and columns

```powershell
$sql = @'
SELECT n.nspname AS relation_schema, c.relname AS relation_name,
       c.relkind AS relation_kind, pg_get_userbyid(c.relowner) AS relation_owner,
       a.attnum AS column_position, a.attname AS column_name,
       pg_catalog.format_type(a.atttypid, a.atttypmod) AS data_type
FROM pg_catalog.pg_class AS c
JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
LEFT JOIN pg_catalog.pg_attribute AS a
       ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
WHERE lower(c.relname) LIKE '%migration%'
   OR lower(n.nspname) LIKE '%migration%'
ORDER BY n.nspname, c.relname, a.attnum;
'@
```

This is a name-filtered catalog inventory. It can find candidate relations and columns visible to the query, not prove that every migration-history mechanism uses a matching name. Compare with the explicit-target `npx --no-install supabase migration list --remote=bhnhhaurdnnalcozsviq` command from Phase 4.6 after verifying its local help. That CLI command lists history; it has no documented `--read-only` option in the reviewed sheet, so treat it as a separate read-only listing command and do not run `db push`, `migration repair`, or any migration.

### 7.7 Routines, ownership and security attributes

```powershell
$sql = @'
SELECT n.nspname AS routine_schema, p.proname AS routine_name,
       pg_get_function_identity_arguments(p.oid) AS identity_arguments,
       pg_get_function_result(p.oid) AS result_type,
       pg_get_userbyid(p.proowner) AS routine_owner,
       p.prosecdef AS security_definer, p.proconfig AS routine_settings,
       CASE WHEN x.grantee = 0 THEN 'PUBLIC' ELSE r.rolname END AS execute_grantee,
       g.rolname AS acl_grantor, x.privilege_type, x.is_grantable
FROM pg_catalog.pg_proc AS p
JOIN pg_catalog.pg_namespace AS n ON n.oid = p.pronamespace
CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) AS x
LEFT JOIN pg_catalog.pg_roles AS r ON r.oid = x.grantee
JOIN pg_catalog.pg_roles AS g ON g.oid = x.grantor
WHERE left(n.nspname, 3) <> 'pg_'
  AND n.nspname <> 'information_schema'
  AND p.prokind IN ('f','p')
ORDER BY n.nspname, p.proname, identity_arguments, execute_grantee;
'@
```

This reports visible routine metadata and expanded EXECUTE ACLs, including default ACLs. It does not review function bodies or transitive calls. Empty results are scoped to catalog visibility and the stated routine kinds/schemas.

### 7.8 RLS policies and table flags

```powershell
$sql = @'
SELECT schemaname, tablename, policyname, permissive, roles, cmd,
       (qual IS NOT NULL) AS has_using_expression,
       (with_check IS NOT NULL) AS has_check_expression
FROM pg_catalog.pg_policies
ORDER BY schemaname, tablename, policyname;
'@
```

```powershell
$sql = @'
SELECT n.nspname AS table_schema, c.relname AS table_name,
       pg_get_userbyid(c.relowner) AS table_owner,
       c.relrowsecurity AS rls_enabled, c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class AS c
JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
WHERE c.relkind IN ('r','p')
  AND left(n.nspname, 3) <> 'pg_'
  AND n.nspname <> 'information_schema'
ORDER BY n.nspname, c.relname;
'@
```

The first query reports visible policies without exporting their expression text; the second reports RLS flags. Neither validates policy behavior, bypass paths, or user/JWT enforcement. Zero policy rows must be compared with the table inventory and RLS flags and must not be treated as proof of security.

### 7.9 Audit/outbox candidates and trigger inventory

```powershell
$sql = @'
SELECT n.nspname AS object_schema, c.relname AS object_name,
       c.relkind AS relation_kind, pg_get_userbyid(c.relowner) AS object_owner,
       c.relrowsecurity AS rls_enabled, c.relforcerowsecurity AS force_rls
FROM pg_catalog.pg_class AS c
JOIN pg_catalog.pg_namespace AS n ON n.oid = c.relnamespace
WHERE left(n.nspname, 3) <> 'pg_'
  AND n.nspname <> 'information_schema'
  AND (lower(c.relname) LIKE '%audit%' OR lower(c.relname) LIKE '%outbox%'
       OR lower(c.relname) LIKE '%inbox%' OR lower(c.relname) LIKE '%webhook%'
       OR lower(c.relname) LIKE '%event%')
ORDER BY n.nspname, c.relname;
'@
```

```powershell
$sql = @'
SELECT tn.nspname AS table_schema, t.relname AS table_name,
       tr.tgname AS trigger_name, tr.tgenabled AS enabled_state,
       fn.nspname AS function_schema, p.proname AS trigger_function,
       pg_get_userbyid(p.proowner) AS function_owner,
       p.prosecdef AS security_definer
FROM pg_catalog.pg_trigger AS tr
JOIN pg_catalog.pg_class AS t ON t.oid = tr.tgrelid
JOIN pg_catalog.pg_namespace AS tn ON tn.oid = t.relnamespace
JOIN pg_catalog.pg_proc AS p ON p.oid = tr.tgfoid
JOIN pg_catalog.pg_namespace AS fn ON fn.oid = p.pronamespace
WHERE NOT tr.tgisinternal
  AND left(tn.nspname, 3) <> 'pg_'
  AND tn.nspname <> 'information_schema'
ORDER BY tn.nspname, t.relname, tr.tgname;
'@
```

The relation query uses candidate-name matching; the trigger query inventories all visible non-internal triggers in non-system schemas. Neither proves audit integrity or completeness of external logging. Do not select audit/payment row contents.

### 7.10 Collision checks

The current source files only define legacy Phase 2.6 fixture names (`incux_rpc_owner`, `phase_2_6_validation_table`, `phase_2_6_validation_view`, `phase_2_6_validation_rpc()` in `public` and `private`). Phase 4.3's exact fixture and runtime role names remain unspecified. Before any future mutation, an approved manifest must enumerate exact names and a read-only collision query must check those names. Do not treat these legacy names as approved Phase 4.3 fixtures.

## 8. Evidence capture requirements for any future read-only rerun

For every individual command, preserve:

- Exact command text and exact SQL text.
- UTC capture timestamp and local time zone.
- Explicit project name, project reference, and Dashboard-confirmed region.
- Sanitized CLI target line and CLI version.
- Sanitized raw result, process exit code, and any errors.
- Database `session_user`, `current_user`, database name, and server version from the same query route when available.
- Evidence filename and form (text transcript, screenshot, CSV).
- A note of filters, schemas, role roots, and visibility limitations.

Do not capture environment-variable values, tokens, passwords, keys, connection strings, or credential-bearing process arguments. Preserve original raw evidence read-only and make a separate sanitized copy if output requires redaction. Do not merge results from different runs without retaining each run's provenance.

## 9. First migration identity feasibility experiment

**Recommendation:** first complete and review the provenance-tagged read-only baseline above. After that, request explicit approval for one narrowly scoped migration-path identity probe in the disposable project only.

The approved probe proposal must name the exact deployment command and credential route without revealing credential values; exact unique fixture name; expected transaction behavior; expected migration-history change; cleanup/recovery; and stop conditions. The probe should create one inert, uniquely named database object through the actual intended migration workflow, then capture separately:

1. CLI authentication route (without exposing token values).
2. Migration connection `session_user` and `current_user` from within the migration execution path.
3. Owner of the created object.
4. Identity and owner behavior in a subsequent migration.
5. Resulting migration-history record and safe cleanup plan.

This is a database mutation and may change migration history. It is **not authorized** by this report. A CLI dry run, `projects list`, separate `db query`, or `migration list` cannot substitute for observing the actual migration path.

## 10. Final assessment

- **Evidence quality:** incomplete; one membership CSV is inspectable but lacks execution provenance, while the other baseline findings are narrative summaries.
- **Fresh live verification:** none performed here.
- **Migration identity:** unknown.
- **Mutation experiment status:** none authorized or passed.
- **Backend implementation:** **NO-GO** until provenance gaps and migration identity/ownership lifecycle feasibility are resolved through separately approved disposable-project steps.

