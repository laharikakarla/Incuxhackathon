# AICUXORA Phase 4.4 — Disposable Validation Readiness

**Review mode:** Static repository review only. No Supabase connection, SQL, migration, secret access or database operation occurred.  
**Permitted validation target:** `incuxai-hackathon-validation` / `bhnhhaurdnnalcozsviq` / `ap-south-1`.  
**Production target:** `incuxai-hackathon` is forbidden.  
**Readiness verdict:** **NOT READY for database-changing validation.** A staged validation plan exists, but the exact fixture/role manifests, actual migration identity, current target baseline and recovery details are not yet established. No operation is authorized by this assessment.

## 1. Executive summary

Phase 4.3 correctly separates read-only checks, migration identity probing, owner-role experiments, runtime identity, RLS/audit tests, team concurrency, and future payment tests. It also requires per-stage approval. This review finds the plan is a good test outline, but not yet an executable package: many test object names and runtime identities are intentionally unresolved; the identity-probe migration-history effects and cleanup path are not exact; failure injection does not specify a transaction/recovery result for each point; and the last read-only project evidence is historical rather than freshly confirmed.

The specific project name, reference and region in this document come from the user-provided target restriction. They are **not freshly verified** here. Previous reports record a CLI environment label of “production” alongside an explicit disposable reference. Before any remote access, the operator must independently confirm the Dashboard project name, reference and region and resolve the environment-label ambiguity. Never use implicit local linking: the local Supabase project identifier has historically differed from the disposable project.

## 2. Documents reviewed and baseline limits

- `aicuxora-phase-4.2-independent-security-review.md`
- `aicuxora-phase-4.3-conflict-resolution.md`
- `aicuxora-phase-4.3-disposable-validation-plan.md`
- `phase-2.14.4-authoritative-security-architecture.md`
- `phase-2.14.4-decision-register.md`
- `phase-2.14.4-implementation-conflict-inventory.md`
- Related Phase 2 architecture, relationship, schema, RLS and security review documents.

Architecture decisions remain design intent, not hosted-project proof. Original Phase 2.12–2.13.1 source specifications are missing from this checkout; the Phase 2.14.4 function/view/helper matrices are proposed reconstructions. D-015 and D-023 retain superseded team-payment/free-registration language; Phase 4.1 is the current product decision. Phase 4.3 correctly says the existing SQL draft must not be applied as-is.

Prior reports include user-supplied/historical observations such as PostgreSQL 17.11, a read-only query role, and role/schema results. They do not establish today's catalog state or actual migration identity. This report makes no live-state claim.

## 3. Target verification and command safety

### Required pre-command procedure

Before each future remote command (not performed here):

1. Open the Supabase Dashboard independently and verify all three values against the approved target: project name `incuxai-hackathon-validation`, reference `bhnhhaurdnnalcozsviq`, region `ap-south-1`.
2. Recheck the active CLI project listing/link metadata without displaying tokens or connection values. Do not trust `supabase/config.toml` as the remote target; its local project identifier has differed from this disposable project.
3. Construct a command that explicitly supplies only `bhnhhaurdnnalcozsviq` using the documented CLI target flag for that command. Never use a linked-project default, implicit project selection, or a command with an unresolved target argument.
4. Inspect the complete command line before execution. Stop if the project ref is missing, differs by even one character, names production, or resolves to any target other than the three verified values. Do not proceed based solely on a local label or a dry run.
5. For SQL diagnostics, require the CLI's read-only option where supported and inspect the statement as read-only before sending it. Do not pipe a file or script into the CLI at the baseline stage.
6. Capture sanitized command text and output (with no tokens, passwords, connection strings, API keys or secret values), timestamp, operator and target identifiers. Retain errors as evidence; do not retry by removing the explicit target.
7. Immediately after any mutation stage, re-check project identity before follow-up/cleanup and compare catalog/history against its captured baseline.

### Preventing and detecting a production target

- The exact disposable reference must be allowlisted in every remote command. A future wrapper may reject any ref other than the allowlisted value, but such a wrapper is not present/validated in this review.
- Dashboard name/ref/region confirmation is a required second independent check. CLI target resolution must agree.
- Treat any production name, production project ref, unexpected region, unexpected CLI resolution, or ambiguity between local config and remote project as a hard stop. Do not “correct” the target automatically.
- The earlier preflight report noted a `production` environment label while the explicit target resolved to the disposable project. The operator must understand and document that label before mutation; do not assume it is harmless or proof of production access.
- If a result shows the wrong target, stop immediately, do not issue cleanup against that target, preserve sanitized command/output evidence, and notify the project operator. Accidental target handling requires incident review; no compensating mutation is authorized by this plan.

Static documentation cannot provide a technical guarantee that CLI credentials or local tooling cannot reach production. Target pinning plus independent Dashboard confirmation reduces risk but does not replace operator review.

## 4. Identity map: known and unknown

| Identity | Current status | Evidence needed |
|---|---|---|
| Supabase CLI authentication principal | Unknown for the intended migration deployment route | Inspect the non-secret authentication method locally; identify the CLI user/project access route without exposing token material. |
| Diagnostic SQL connection login | Historical user-supplied result was `supabase_read_only_user`; not freshly verified | New explicitly targeted read-only query of `session_user` and `current_user`. This identity is only for that diagnostic route. |
| Actual migration connection `session_user` | **Unknown** | Observe through the exact intended deployment command while a separately approved migration probe runs. |
| Migration SQL `current_user` / effective role | **Unknown** | Capture from inside the same migration execution context; distinguish any role switch from session login. |
| Owner of migration-created object | **Unknown** | Inspect catalog after the identity probe and compare to `current_user`/session identity. Never infer it. |
| Identity used by subsequent migration replacing owner-owned function | **Unknown** | Execute a second separately approved test migration after transfer and record session/current/object owner and grant path. |
| Domain NOLOGIN owner(s) | Architecture concept only; exact role manifest unresolved | Approved manifest plus disposable CREATE ROLE, attributes, memberships and ownership tests. |
| System/payment runtime logins | Architecture concept only; exact identities and routes unresolved | Approved runtime manifest, individual credential route and pooler tests. |
| User actor | Target design is verified JWT subject via `auth.uid()`; hosted propagation untested | Observe through PostgREST/Edge-forwarded JWT/definer/trigger paths and adversarially test forged IDs/GUCs. |

Do not treat CLI login, the historical read-only query role, `session_user`, `current_user`, and object owner as interchangeable.

## 5. Validation manifest review

The Phase 4.3 plan's stages are reviewed below. “Needs completion” means the existing proposal must be made exact before it is safe to execute.

| Phase 4.3 stage | Type | Manifest assessment | Current disposition |
|---|---|---|---|
| 0. Target and baseline | Read-only remote checks | Objective, identity dimensions, expected target and stop conditions are stated. Exact read-only statements/CLI invocations and current Dashboard evidence are not attached to the Phase 4.3 plan. Cleanup is none; recovery is stop/reconcile. | **Can be prepared first.** Must pin the reference and resolve CLI environment-label ambiguity. Explicit remote-read-only approval still required by the prior plan. |
| 1. Migration identity probe | Reversible-looking but changes DB; may alter migration history | Objective and identities to distinguish are stated, but fixture name, migration content, exact route/credential source, whether migration history is inserted, transactional behavior and exact cleanup are missing. A probe migration may not be safely undone by deleting its object alone. | **Not ready.** Define unique fixture and history/recovery policy; explicit approval required. |
| 2. NOLOGIN role creation/isolation | Reversible role/grant mutation | Attributes, roles to adversarially test, and safe cleanup principles exist. Exact role names, creator/grantor, role-option assertions, dependent-object checks, grantor capable of revocation, and per-statement rollback are unresolved. | **Not ready.** Requires reviewed role manifest and explicit approval for each create/grant/revoke/drop. |
| 3. Schema authority/ownership transfer | Reversible object/grant mutation | Distinguishes effective CREATE from grantable CREATE and expects owner/ACL checks. Exact schema/object/function names and required grants are missing; transfer/cleanup may be blocked by owner privileges. | **Not ready.** Exact disposable fixture and grant/revoke sequence needed; approval required. |
| 4. Subsequent replace/JIT privilege | Privilege and function mutation; residual-grant risk | Tests direct denial, temporary grant, replace and revocation, but does not identify the grantor, privilege mechanism, exact duration/watchdog, interruption control, allowed scope or expected catalog diff. | **Not ready.** Any temporary grant is separately approved and must have a revoker independent of the migration process. |
| 5. Migration failure injection | Potentially destructive migration/history mutation | Failure points are listed, but for each point transactional/nontransactional effects, expected persistent objects, history repair policy and discard threshold need an explicit row. | **Not ready.** Failure scenarios must be isolated and approved one at a time; do not manually rewrite migration history without a reviewed recovery procedure. |
| 6. Runtime login/pooler | Credential and role mutation; requires infrastructure | Per-role goals are clear but exact system roles, custom login route, credential storage, pooler host/mode and revoke method are absent. A successful role cannot stand in for others. | **Not ready.** Requires named runtime manifest, approved secret-handling route and infrastructure/operator approval. No secret values may appear in evidence. |
| 7. Auth/account lifecycle | User/auth data mutation | Synthetic user A/B tests are defined, but exact disposable Auth project configuration, callback route, synthetic identities, deletion behavior and email delivery setup are unresolved. | **Not ready.** Requires disposable Auth setup and synthetic-only users; explicit approval. No real participant data. |
| 8. RLS/function/view tests | Data and possibly policy/function mutation | Attack outcomes are good, but test objects, policy/function manifests and data isolation boundaries are not ready. Should not test legacy SQL as if accepted architecture. | **Not ready.** Requires reviewed new test fixture/ACL/RLS manifest; never edit production or existing draft. |
| 9. Audit identity/atomicity | Business/audit row mutation, role/function/trigger tests | Forgery and rollback goals are specified. Exact event table/trigger function/writer identities and expected actor mapping are unresolved; audit retention/cleanup may be append-only by design. | **Not ready.** Use isolated synthetic event types and preserve evidence; cleanup must not bypass audit protections or erase canonical evidence. Explicit approval. |
| 10. Team concurrency | Concurrent DB mutations and synthetic PII-like records | Invariants and participant identities are identified conceptually, but fixtures, parallelism, isolation level, expected serialization/retry results, cleanup and test ownership are absent. Payment-lock behavior is deliberately deferred. | **Not ready.** Require synthetic participants and exact concurrency harness; explicit approval. |
| 11. Payment/outbox | Blocked mutation; additional external/mock infrastructure | Explicitly blocked pending individual-payment design and product decisions. Payment worker identity and event/order structure are absent. | **Do not schedule yet.** Requires a separate payment design and approval. Mock provider only; no live provider or credential. |

## 6. Experiment classification

### Read-only baseline checks

- Current target confirmation in Dashboard and local CLI metadata.
- CLI version and non-secret intended deployment command/configuration review.
- Explicitly targeted read-only queries for PostgreSQL/database identity, role attributes/membership options and grantors, schema/database privileges, exact fixture collisions, and migration history.
- Repository inspection for migration files and scripts.

These checks are read-only but still contact the disposable service. They require an explicit target, authorization for remote reads, sanitized evidence, and stop conditions. The Phase 4.4 task did not run them.

### Reversible mutation experiments (only if recovery is proven)

- Create uniquely named test function-owner roles and grant minimal test privileges.
- Create/transfer/replace/drop a uniquely named test function.
- Add and revoke bounded temporary schema or role privileges.
- Create synthetic Auth users, profiles, registration rows, teams, invitations, and payment test fixtures after their specs are approved.
- Run synthetic RLS, trigger, audit and concurrency operations.

These may be reversible in theory but can persist if the operator/session fails. Every step requires separate explicit approval, exact manifests and post-state checks.

### Potentially destructive or difficult-to-reverse experiments

- Applying any migration, because it changes migration history and may partially apply objects.
- Failure injection after temporary grants or ownership transfer.
- Any role drop/revoke where dependencies or grantors are not known.
- Tests against append-only audit/financial records if the design intentionally prohibits deletion.
- Project reset/recreation after ambiguous failure.

These require dedicated approval, backup/baseline and recovery plan. Never use broad cleanup or manually edit migration history as an improvised fix.

### Experiments requiring additional credentials or infrastructure

- Login tests for each custom system runtime and payment worker; requires provisioned credentials and an approved secure delivery/rotation/revocation channel.
- Pooler tests require the exact intended endpoint/mode and connection configuration; do not print connection strings.
- Auth verification/recovery may require configured test email delivery or a disposable mailbox.
- Edge-to-database JWT propagation requires a disposable Edge deployment and test secrets; no credentials are to be included in repository output.
- Payment/webhook/outbox tests require a mock provider or isolated test harness, worker runtime and domain identity. No real payment provider should be contacted.

## 7. Mutation-specific approval matrix

Approval is per row; no approval carries forward to another operation. The list below is a gate definition, not an execution request.

| Gate | Exact proposed operation | Expected effect | Required approver decision |
|---|---|---|---|
| A | Execute read-only target/version/identity/privilege/collision/history diagnostics with explicit disposable ref | No catalog or migration changes; records current baseline | Approve the remote read-only session and its exact statements/command. Stop on any target mismatch. |
| B | Run one uniquely named migration identity probe | Creates one test object and may add a migration-history entry; exposes actual migration session/current/owner identities | Approve exact migration file/content, command/route, fixture name, expected history change, and cleanup/recreate choice. |
| C | Create each named NOLOGIN owner test role with specified attributes | Adds a database role and membership/privilege catalog state | Approve role name, creator, exact attributes and no-API-membership assertions. |
| D | Grant temporary schema/role privilege needed for transfer or replacement | Expands operator authority for a bounded period | Approve exact privilege, grantor, recipient, object/schema scope, duration/watchdog and independent revocation command. No broad CREATEROLE or permanent owner membership. |
| E | Create test function and transfer owner | Adds function and changes owner/ACL | Approve exact schema/name/signature/body, intended owner, ACL, and cleanup order. |
| F | Attempt direct replacement, then replacement under temporary privilege | First expected denial; second expected success only within approved scope; updates function body | Approve both attempts and expected result. Stop if first succeeds unexpectedly or second changes owner/ACL. |
| G | Run subsequent migration and individual failure injection | May change object state and migration history, possibly leave partial effects | Separate approval for each failure location and migration; require documented transactional behavior and reset criteria. |
| H | Provision and test each custom runtime login/pooler connection | Adds role/credential and tests network access; possible access grants | Approve one runtime identity at a time, route, secret delivery/rotation, exact function allowlist and cleanup/revocation. |
| I | Create disposable Auth test users and synthetic business records | Adds auth/profile/team/test data, triggers audit events and possibly sends test email | Approve test identities, email route, allowed records and cleanup; confirm no real participant data. |
| J | Change test RLS/function/view/trigger grants or policies if required | Alters authorization and may expose test data | Requires approved exact diff and independent review before change; no blanket grants or use of existing draft as fixture. |
| K | Run parallel team lifecycle tests | Concurrent state mutation, invites, memberships and audit events | Approve exact fixture size, operations, concurrency count, expected serial outcomes and cleanup. |
| L | Provision mock payment worker and run participant-level payment/outbox tests | Creates fake payment/order/refund/outbox/audit state; no real money if correctly isolated | Not available until payment design approved; separate approval must prohibit live gateway endpoint/credentials. |
| M | Reset/recreate disposable project after unrecoverable partial state | Destructive removal of all project state | Requires separate explicit approval after evidence is preserved and exact project name/ref/region re-confirmed. |

## 8. Cleanup and recovery standard

- Before a mutation, save the sanitized baseline, exact object manifest, owner/grantor, migration history, and cleanup plan.
- Use unique Phase 4.4 fixture names; do not reuse Phase 2.6 or prior validation names without checking collisions.
- Prefer transaction rollback for isolated tests only where the operation is truly transactional; do not assume CLI migration runner or role DDL is atomic as one unit.
- After each grant, transfer or migration, capture independent post-state. Revoke temporary privileges immediately through a grantor/route that is independent of the migration process, then verify membership options, schema/database rights, owners and ACLs.
- Drop only a named object proven to have been created by this test, after checking its owner and dependencies. Never drop a schema, role, migration history row, or shared object broadly.
- If cleanup fails, migration history diverges, target identity changes, or any privilege persists unexpectedly: stop, do not retry or broaden grants, preserve evidence, and use an explicitly approved operator recovery or disposable-project recreation.
- Do not remove append-only audit/financial evidence just to make a test look clean. Define how synthetic events are retained or isolated before those tests.

## 9. Remaining blockers

1. **Fresh target baseline absent:** current project name/reference/region are specified by the user, but not freshly verified in this review. Previous CLI environment-label ambiguity must be resolved.
2. **Migration identity unknown:** CLI principal, database `session_user`, `current_user`, object owner, and subsequent migration identity remain separate unknowns.
3. **Migration operator route incomplete:** exact deployment command/credential route and resulting role privileges must be established without exposing secrets.
4. **Fixture and role manifests incomplete:** test function, owner roles, runtime names, schema objects, and expected catalog deltas are not assigned exact names.
5. **Ownership lifecycle unresolved:** exact temporary mechanism/grantor, revocation watchdog, subsequent replacement and failure recovery are not proven.
6. **Runtime infrastructure absent/unverified:** custom logins, pooler route, Edge JWT forwarding and independent payment runtime have not been tested.
7. **RLS/audit exact manifests missing:** policies, function ACLs, view column projections, nested definer graph and non-forgeable audit actor binding remain unresolved.
8. **Payment design not ready:** Phase 4.1 per-participant model conflicts with old team-level SQL; fee, provider, timing, refund/chargeback and payment-gating rules remain open. Payment tests must wait.
9. **Historical provenance gap:** original Phase 2.12/2.13.1 matrices are missing; reconstructed 79/30/18 inventories require explicit ratification before they can be validation fixtures.

## 10. Recommended first read-only validation step

Prepare a short command sheet for **Gate A only**. Immediately before use, the operator should manually verify in Dashboard that the selected project is `incuxai-hackathon-validation`, reference `bhnhhaurdnnalcozsviq`, region `ap-south-1`; inspect the CLI's resolved target; and stop if any field or environment label is ambiguous. Then, only with explicit approval for remote reads, run the exact-reference read-only database identity/version query and migration-history listing, followed by the role/membership and privilege/collision diagnostics. Use read-only mode for remote SQL queries where supported. Capture sanitized outputs and compare with the prior evidence without treating historical results as current.

Do **not** run a migration identity probe, Phase 2.6 script, DDL, role statement, grant, revoke or cleanup as part of that first step.

## 11. Final readiness verdict

**NO-GO for database-changing validation at this time.** This review did not verify the target or run any test. The plan still needs an exact fixture/role manifest, current read-only baseline, migration-route identity, independently revocable temporary privilege design, and per-test migration-history/recovery details. No mutation is authorized.

The first next action is the Gate A read-only command sheet and, after explicit operator approval, a freshly verified disposable-only baseline. Reassess mutation readiness only after that evidence and the test manifests are independently reviewed. Backend implementation remains NO-GO until the payment model is reconciled in the authoritative specification and the identity, owner replacement, RLS, audit and runtime blockers are resolved.
