# Phase 2.14.3 — Architecture Documentation Recovery & Migration Workflow Review

**Review type:** Independent static review only.  
**Database access:** None. No SQL executed; neither Supabase project contacted.  
**Decision:** **NO-GO — architecture documentation recovery and migration feasibility evidence are required before any database-changing validation.**

## 1. Executive summary

The Phase 2.14.2 migration workflow is a useful proposal and correctly refuses to treat CLI login, a dry run, or documentation as proof of the PostgreSQL migration identity. It recommends a serialized Supabase CLI deployment after disposable validation and preserves the Phase 2.12 direction in its introductory summary.

It does **not yet define an executable least-privilege ownership lifecycle**. The proposed separate grantor, temporary membership, temporary schema `CREATE`, migration execution, and revocation are steps in a design, not an integrated workflow. It remains unknown who can grant/revoke the access, whether the CLI migration connection can use it, whether grants/replacements/revocations share a transaction, and what happens when that sequence partially fails. The report therefore correctly remains NO-GO.

There is a second blocker: the canonical Phase 2.12 and Phase 2.13 architecture/classification documents are missing from the local checkout and Git history. The old local schema, RLS matrix, and security review still describe the prior single `incux_rpc_owner`, broad owner access, `service_role` RPCs, and views without `security_invoker`. They cannot be treated as an implementation of the subsequently accepted hybrid architecture.

The checked-in-equivalent source of truth is therefore fragmented across prior conversation instructions, untracked local design drafts, and partial validation reports. Missing documents do not mean their decisions were abandoned. Recover the accepted decisions verbatim into a versioned specification, reconcile the old SQL/RLS artifacts against it, and obtain independent review before requesting the Phase 2.15 probe.

## 2. Scope and evidence examined

### Local database documents

- `docs/database/phase-2-architecture.md`
- `docs/database/phase-2-relationships.md`
- `docs/database/phase-2-schema-draft.sql`

### Local security documents

- `docs/security/phase-2-rls-matrix.md`
- `docs/security/phase-2-security-review.md`
- `docs/security/phase-2.2-audit-report.md`
- `docs/security/phase-2.2-correction-log.md`
- `docs/security/phase-2.3-independent-review.md`
- `docs/security/phase-2.4-correction-log.md`
- `docs/security/phase-2.5-h6-validation-plan.md`
- `docs/security/phase-2.6-validation-runbook.md`
- `docs/security/phase-2.7-audit-report.md`
- `docs/security/phase-2.8-audit-report.md`
- `docs/security/phase-2.8-correction-log.md`
- `docs/security/phase-2.8.1-membership-review.md`
- `docs/security/phase-2.14-read-only-preflight.md` (includes the Phase 2.14.1 retry addendum)
- `docs/security/phase-2.14.2-migration-workflow-design.md`

The current folder contains no separate Phase 2.1 audit, Phase 2.9 review, Phase 2.10/2.11/2.12 architecture specification, Phase 2.13 independent review, or Phase 2.13.1 validation-plan file. Function inventory/classification reports are also absent. The current schema draft statically contains 79 `public` function definitions, 18 `private` function definitions, and 30 views. These definitions are source material, not a replacement for the approved function/view/helper classification matrices.

### Git history and tracked status

- Current branch observed: `main`.
- `git ls-files -- docs/database docs/security` returned no tracked document paths.
- `git log --all -- docs/database docs/security` returned no document history.
- The Phase 2 design documents are present locally but are untracked in this workspace. No earlier committed copies can be recovered from the inspected repository history.
- This review created only this report. It did not stage, commit, or push anything.

### Evidence limits

The approved Phase 2.12 and Phase 2.13 decisions below are taken from the user’s instructions and prior conversation context. They cannot be line-by-line reconciled to missing files or Git objects. No Supabase capability was runtime-tested in this task.

## 3. Independent review of Phase 2.14.2

### What the design gets right

- Keeps CLI platform authentication, database connection identity, `session_user`, `current_user`, object owner, and later-migration identity separate.
- Rejects a dry run, `migration list`, or read-only query identity as proof of migration execution identity.
- Prefers versioned Supabase CLI migrations over Dashboard-only/manual deployment and recommends an explicit remote reference.
- Treats migration history as separate from actual object state; cautions against using history repair as a SQL rollback.
- Requires verification of function ownership, exact ACLs, schema grants, memberships, and API/runtime exclusion after a replacement.
- Preserves a NO-GO until disposable-project evidence exists and correctly excludes production from validation.
- Documents partial-failure risks and prohibits broad cleanup.

Supabase documents `db push` as the supported migration-file workflow and `supabase_migrations.schema_migrations` as its history mechanism. PostgreSQL documents function ownership and role-membership prerequisites. These sources establish product/PostgreSQL behavior, not feasibility for this hosted project. [Supabase database migration deployment](https://supabase.com/docs/guides/deployment/database-migrations), [PostgreSQL 17 `ALTER FUNCTION`](https://www.postgresql.org/docs/17/sql-alterfunction.html), [PostgreSQL 17 `CREATE FUNCTION`](https://www.postgresql.org/docs/17/sql-createfunction.html)

### Gaps, unsupported assumptions, and missing tests

| Severity | Finding | Why the design is not yet operational | Required follow-up |
|---|---|---|---|
| **Critical** | Temporary domain-owner access lacks a concrete grant/revoke control plane. | The workflow says a separately authorized grantor grants membership and schema `CREATE`, while the CLI migration session uses them. It does not define how the grantor authenticates, how grants are bound to exactly one migration/job/domain, how the migration process receives the grants, or who revokes them if the job disappears. This may create a standing privilege window or require persistent admin authority. | Specify the grantor identity and exact approved orchestration, failure-safe revocation, expiry/alerting, and independent verification. If the managed project cannot provide this without lasting broad privileges, redesign. |
| **Critical** | No proof that the actual migration session can replace a domain-owned function. | PostgreSQL requires ownership/effective owner authority to replace a function. Schema `CREATE` alone is not proof. The design correctly calls for an expected-denial test and temporary authorization test, but neither has run. | In the disposable project, through the exact CLI migration route, demonstrate denial without temporary owner authority, successful narrow authorized replacement, removal of that authority, and denial afterward. Repeat with a second migration. |
| **High** | Transaction boundaries and grants are not shown to be atomic through Supabase CLI 3.1.0. | The design says to validate transactionality but does not establish whether role membership grants, schema grants, function replacement, revocation, and migration-history writes occur in one transaction or multiple connections. External grantor steps cannot be presumed part of the CLI migration transaction. | Inject failures before/after every grant and replacement boundary using a disposable project; capture catalogs and migration history. Test cleanup if the CLI job/process is terminated. |
| **High** | Initial ownership route is not fully specified. | “Create then transfer” and “temporarily assume owner then create” are alternatives, with no selection. Both depend on hosted operator privilege, schema privilege, and role-membership behavior. | Select one route after testing actual operator identity and PostgreSQL prerequisites. Include negative role-attribute/membership assertions and exact object owner/ACL checks. |
| **High** | Temporary schema `CREATE` may be broader than the specific function migration needs. | Granting `CREATE` on shared `public` or `private` permits object creation in the whole schema during the window. The proposal does not specify whether this grant goes to the operator or owner, exact window, exposure during failure, or whether existing functions can be replaced without it. | Test the minimum privilege per operation and schema; include unauthorized object-creation negative checks. Do not grant it permanently. Consider narrower schema partitioning only as a documented design change if required. |
| **High** | CI improves repeatability, not database least privilege. | The CI job still holds CLI authorization and a database credential; the workflow does not explain how a short-lived database grant is orchestrated without giving CI a permanent role-admin capability. | Threat-model CI compromise, lock/separate environments, use protected approvals and time-bounded secrets, and validate that CI can perform only reviewed migration work. |
| **Medium** | The deployment sequence is internally ambiguous. | Section 7 says apply a migration batch only after identity and temporary-privilege behavior pass, then captures identity from a dedicated approved probe afterward. The probe must precede the first ordinary migration batch. | Reorder: preflight → approved identity probe → review evidence → owner lifecycle probe → approval → ordinary migrations. |
| **Medium** | Migration-history assertions need a stronger distinction between empty history and empty database. | An empty local/remote migration comparison does not prove the remote schema has no objects or drift. The history table records migration application, not full schema equivalence. | Preflight both migration history and catalog state; document how pre-existing objects are reconciled before the first migration. Do not use `migration repair` to mask drift. |
| **Medium** | The `2.14.2` report does not reconcile its latest supplied facts into `phase-2.14-read-only-preflight.md`. | The workflow document says newer supplied results supersede the prior CLI-authentication failure, but the preflight report remains stale. Reviewers see contradictory evidence unless the sources are linked and dated. | Add a later read-only result addendum in the preflight report in a separately authorized documentation task; preserve the earlier failure as historical. |
| **Medium** | CLI command/credential handling is partly generic. | The repo has no migration command, no migration directory, and no tested secure credential route. `--remote=<ref>` pins the project, but it does not establish database role identity or prevent misuse of a connection URL/password. | Confirm exact CLI 3.1.0 command behavior, environment variable/prompt route, target output, and secret redaction in the disposable deployment job. Never put secret values in args, logs, or migration files. |
| **Low** | Cleanup choice is not operationally fixed for each failure. | The proposal allows exact cleanup or project discard, but project deletion is approval-gated and no per-test cleanup owner is named. | Before the test, assign an operator and choose fresh-project disposal as the default for ambiguous or partially failed runs. |

### Assessment by required concern

- **Migration execution identity:** correctly identified as unknown; no direct evidence yet.
- **Ownership transfer:** PostgreSQL prerequisites are described, but hosted operator authorization is unknown.
- **Later replacements:** correct concern and candidate membership idea, but no proven workflow or second-migration evidence.
- **Temporary privilege:** least-privilege goal is sound; grantor and revocation mechanics are not defined enough to guarantee temporary access.
- **Least privilege:** CLI/CI route is repeatable but still uses a database credential whose role and authority are unknown. It does not yet prove migrations execute with minimal privileges.
- **Migration history:** general strategy is sound; empty comparison must not be confused with an empty/drift-free database.
- **Transactions and partial failures:** risks are recognized, but failure-injection evidence and an actual transaction boundary are absent.
- **Repeatability and recovery:** recommended in principle; second-migration and failure recovery tests are still required.

## 4. Missing-document inventory

| Document or artifact | Local state | What exists instead | Recovery status |
|---|---|---|---|
| Phase 2.1 baseline decision record | No standalone report | Phase 2 architecture, relationship map, SQL draft, RLS matrix, and security review | Reconstruct the original baseline separately from later accepted architecture. |
| Phase 2.9 independent security review | No file | Its contents are summarized/referenced by later conversation and correction phases; no repository copy | Exact findings/source cannot be independently checked from this checkout. Recover from the originating conversation/export if available. |
| Phase 2.10 trusted identity/database execution matrix | No file | User’s requested deliverables in conversation | Full 79-operation matrix and role/credential matrix are not locally recoverable. |
| Phase 2.11 adversarial review | No file | User’s review requirements and subsequent accepted direction in conversation | Exact findings and resolution statuses are missing. |
| Phase 2.12 final security architecture | No file | User’s accepted architecture direction and Phase 2.14.2 summary | Accepted decision list is partially recoverable from conversation; complete technical spec and exact matrices are not. |
| 79-function inventory/classification | No report file | `phase-2-schema-draft.sql` has 79 public function definitions; RLS matrix references some RPCs | Names/bodies exist in draft; accepted per-function execution classification and permissions do not. |
| 30-view security matrix | No report file | SQL draft has 30 public view definitions; RLS matrix describes some view use | Per-view `security_invoker`/replacement decision and grants are missing. |
| 18-helper/trigger inventory | No report file | SQL draft has 18 private function definitions, including helper/trigger functions | Ownership, caller, recursion, nested privilege, and trigger execution analysis is missing as a consolidated matrix. |
| Phase 2.13 independent review | No file | User’s review objective and final NO-GO context in conversation | Exact adversarial findings/recommendations cannot be verified locally. |
| Phase 2.13.1 validation plan | No file | Earlier assistant plan in conversation | Steps can be summarized from conversation, but no controlled source or reviewed version is present. |
| Phase 2.14.1 result report | No separate file | Addendum embedded in `phase-2.14-read-only-preflight.md` | Exists locally as an addendum; preserve its failed-auth history and append newer results rather than overwrite. |
| Phase 2.14.2 workflow design | Present, untracked | `phase-2.14.2-migration-workflow-design.md` | Reviewed here; keep NO-GO and close listed gaps before migration execution. |

The repository does not provide Git recovery for these missing documents: the docs paths are untracked, and the inspected Git history contains no commits for them. The approved decisions should be recovered from the conversation records or owner-provided source exports, then written as new traceable documents—not guessed from old SQL.

## 5. Architecture decision recovery matrix

“Current approved decision” below means the latest decision explicitly accepted in the conversation. It is not a claim that the local SQL implements it.

| Decision area | Original evidence/source | Current approved decision | Local status / uncertainty | Required follow-up | Independent review? |
|---|---|---|---|---|---|
| Single-event product and platform boundary | Phase 2.1/2.2 architecture request; `phase-2-architecture.md` §§1–2 | One IncuX AI hackathon platform, not multi-event SaaS; React/TypeScript frontend and Supabase/PostgreSQL backend | Preserved in local architecture. No conflict identified. | Retain as scope header in recovered canonical spec. | Yes, scope sign-off once. |
| User identity and user-originated operations | Phase 2.12 accepted architecture request; prior Phase 2.10/2.11 prompts | User identity comes from verified signed JWT and `auth.uid()`; never trust browser-supplied actor ID or editable profile/JWT metadata for privileged identity | Older architecture/helpers use `auth.uid()` in some functions, but function-by-function status is absent and cannot establish all paths. | Recover all 79 operation actor/identity decisions; mark user, system, and webhook contexts explicitly. | **Yes**, security review required. |
| RLS and invoker-first access | Phase 2.12 accepted direction; current RLS matrix and Phase 2.2 corrections | Prefer RLS and `SECURITY INVOKER` where sufficient; use definer only for narrowly scoped operations that need it | Current RLS matrix/SQL is from older design; many definer functions and views are not marked `security_invoker`. | Reconcile each table, view, helper, and function; retain constraints/invariants from old draft where compatible. | **Yes**, policy and definer review. |
| Function ownership | Phase 2.12 architecture; Phase 2.14.2 §4 | Narrow, domain-specific `NOLOGIN` owners; no universal owner; no RLS bypass; no ownership of sensitive tables/schemas | SQL draft still creates `incux_rpc_owner` and gives it broad all-table privileges plus an internal policy on every table. | Reconstruct per-domain owner manifest and migrate away from old model only after approved spec and disposable proof. | **Yes**, independent privilege review. |
| System identities | Phase 2.12 architecture request | Separate custom `LOGIN` roles per justified system workload; no routine `service_role` application transactions | Local SQL relies on `auth.role()='service_role'` for service RPCs and explicitly grants service-role execution. No complete workload identity matrix exists. | Recover the approved system-domain identities, login routes, and least-privilege function grants. | **Yes**, threat model and runtime review. |
| Payment runtime isolation | Phase 2.12 architecture decision | Payment/webhook/refund runtime independently controlled; no project-wide Edge secret isolation assumption | Old architecture describes Edge Functions and service-only database RPCs; no independent runtime deployment or credential design in local spec. | Preserve payment runtime isolation; specify provider verification and database transaction boundary without treating a boolean/user ID as proof. | **Yes**, payment/security review. |
| System/webhook actor model | Phase 2.12 and Phase 2.13.1 requested design | Explicit actor types `user`, `system`, `webhook`; authenticate each type; parameters alone are not proof | No complete local actor schema or trust mapping. Old SQL checks `auth.role()='service_role'`, and selected service operations accept user IDs. | Recover actor source, authenticated identity, correlation, and audit mapping per operation; test under PostgREST, runtime login, definer, and trigger. | **Yes**, high-impact security review. |
| Audit architecture | Phase 2.12 accepted decision | Trigger-owned, append-only audit events; atomic with business transaction; prevent API fabrication; separate business history from operational logs | Old SQL has append-only protections but 71 direct `INSERT INTO public.audit_log` sites in routines, rather than one trigger-owned writer architecture. The approved trigger-writer details are missing. | Recover canonical events, triggers/writer ownership, atomicity, score-edit history, discussion metadata-only requirements, retention, and external immutable retention option. | **Yes**, audit threat-model review. |
| Transactional outbox | Phase 2.12/2.13.1 architecture and validation requirements | External side effects are initiated from durable transactional outbox/inbox boundaries; idempotent workers; no provider calls while DB locks are held | Current SQL draft has no `outbox` identifier/section and no documented atomic outbox implementation. | Recover required outbox events, lease/retry/idempotency state machine, worker identities, and crash recovery. | **Yes**, concurrency/reliability review. |
| 79 public operations | Phase 2.10/2.12 deliverable requests and subsequent “preserve” instruction | Preserve a per-operation classification—not blanket Edge-only—covering identity, execution mode, tables/columns, grants, audit, locks, atomicity | SQL has 79 public function definitions, but no approved classification matrix file; current grant model is stale. Exact classifications cannot be reconstructed from SQL alone. | Recover prior function matrix from conversation/export; reconcile all 79 names/signatures against current SQL; list renamed/removed/merged functions explicitly. | **Yes**, independent row-by-row review. |
| 30 views | Phase 2.12 deliverable request and current user instruction | Preserve per-view invoker vs replacement projection, allowed roles, grants, RLS, and excluded sensitive fields | SQL has 30 views, all created with `security_barrier=true`; static search found no `security_invoker`. The accepted 30-view matrix is missing. | Recover the matrix and independently classify all 30; do not assume `security_barrier` enforces caller RLS. | **Yes**, independent data-boundary review. |
| 18 private helpers/trigger functions | Phase 2.12 deliverable request and current user instruction | Preserve review of helper/trigger ownership, caller, privileges, recursion, search path, and nested definer behavior | SQL has 18 private function definitions; no consolidated accepted classification/owner matrix is local. | Recover helper/trigger list, compare signatures and trigger bindings, and specify owner/grants/RLS interaction for each. | **Yes**, independent code/security review. |
| Migration operator and ownership lifecycle | Phase 2.5–2.8.1 reports; Phase 2.12 direction; Phase 2.14 preflight and 2.14.2 | Migration identity remains unknown; no probe has run; no permanent broad privileges; disposable validation only | Prior user-supplied facts: CLI 3.1.0, PostgreSQL 17.11, diagnostic query role `supabase_read_only_user`, empty migration comparison. These do not reveal migration identity. | Keep NO-GO. Define and approve a probe that observes identities/ownership through exact deployment route and tests subsequent replacement and failure cleanup. | **Yes**, independent database security review. |
| Migration route/history | Phase 2.14/2.14.2 | Prefer reviewed serialized Supabase CLI migrations only after validation; explicit target; migration files immutable once applied | No migration directory or command in package/README. Phase 2.14.2 route is a recommendation, not a confirmed deployment. The prior report’s auth failure and later user-supplied empty comparison must remain chronologically traceable. | Specify CLI version/route, credential sources by name only, history baseline, transaction boundaries, single deployer and recovery. | **Yes**, operational review. |
| Validation boundary | Phase 2.13.1 and Phase 2.14 user instructions | Only `incuxai-hackathon-validation` (`bhnhhaurdnnalcozsviq`); never production; all mutation tests separately approval-gated | Locally preserved in Phase 2.14 and 2.14.2; no migration probe executed. | Every future hosted command must pin the ref and verify resolved project name/ref before applying. | **Yes**, pre-execution check by operator/reviewer. |

## 6. Security consistency review

### Compatible decisions in the migration proposal

- It does not claim a verified migration identity.
- It keeps the proposed domain-owner approach NOLOGIN and rejects a universal owner role.
- It proposes temporary, domain-scoped access rather than permanent broad privileges.
- It calls for checking role memberships, function ACLs, schema grants, RLS, and later migration behavior.
- It supports reviewed, serialized migration files and avoids Dashboard-driven routine changes.
- It preserves RLS/invoker preference and the independent payment runtime in its architecture summary.

### Contradictions in the surrounding local design artifacts

These are contradictions between the accepted Phase 2.12 direction and older local drafts. This review does **not** modify or reinterpret those drafts.

| Severity | Local artifact and evidence | Conflict with accepted direction |
|---|---|---|
| **Critical** | `docs/database/phase-2-schema-draft.sql`, authorization/ownership block around `incux_rpc_owner`; broad `SELECT, INSERT, UPDATE, DELETE ON ALL TABLES`, all sequence access, plus `internal_rpc_owner` policy generated for every table | The universal, cross-domain owner violates narrow domain-specific function owners and creates broad table access. It must not be treated as the Phase 2.12 implementation. |
| **High** | SQL draft payment/webhook/service sections; `phase-2-security-review.md` §§3, 6; RLS matrix rows for service-only functions | Draft functions use `auth.role()='service_role'` checks and service-role execution grants for sensitive operations. Phase 2.12 excludes routine service_role application transactions and selects an independent payment/webhook runtime. |
| **High** | SQL draft defines 30 public views with `security_barrier=true`; no `security_invoker` option was found | `security_barrier` is not equivalent to invoker security. Approved architecture requires `security_invoker` wherever RLS and column grants are safe, or a narrower replacement projection. The accepted per-view classification is missing. |
| **High** | SQL draft contains 71 direct audit table insertion sites in routines; audit table has append-only controls | Append-only table protections do not make the writer trigger-owned. The accepted architecture requires a trusted trigger-owned audit writer and atomic events; old direct RPC inserts are not equivalent. |
| **High** | No outbox term or explicit transactional outbox structure found in the SQL draft | A transactional outbox and worker idempotency are part of the accepted architecture requirements; current draft does not document that model. |
| **High** | Phase 2.14.2 §7 puts ordinary migration application before the dedicated approved probe in its numbered flow, while §8 requires the probe first | The sequencing is ambiguous: the identity and temporary-privilege lifecycle must be proven before ordinary implementation migrations. Reorder the workflow during consolidation. |
| **Medium** | Phase 2.14.2 recommends a separate grantor and CI/job but does not define how it securely coordinates grants with the CLI migration session | This leaves a gap between “temporary by design” and actually temporary, revocable privileges. A permanent CI-held ADMIN or owner membership would contradict least privilege. |
| **Medium** | Current `phase-2-14-read-only-preflight.md` records an access-token failure; 2.14.2 says newer user-supplied results supersede it | The chronology is preserved in the report, but the later read-only evidence has not been appended to that report. The source of current facts should be explicit before a probe request. |

The older design has useful preserved invariants—team concurrency, payment snapshots/refund serialization, recruiter consent, assigned judging, moderation references, and certificate privacy. Those invariants should be carried into the recovered matrices, not discarded because their execution model is being replaced.

## 7. Proposed structure for restoring architecture specifications

This is a documentation proposal only. Do not create these files until separately approved. Keep existing Phase 2 files unchanged until the recovered baseline is reviewed.

### Canonical architecture and matrices

1. `docs/database/phase-2.12-final-security-architecture.md`
   - Scope and threat boundaries.
   - RLS/invoker-first policy.
   - Domain owner principles.
   - User, system, webhook actor definitions.
   - Payment runtime isolation and provider boundary.
   - Audit/outbox/concurrency rules.
   - Supabase assumptions versus validated facts.
   - Explicit decision ledger and version/source references.
2. `docs/database/phase-2.12-function-execution-matrix.md`
   - Exactly 79 public operations, one row per canonical signature.
   - Actor type/auth source; direct API, invoker, definer, Edge orchestration, runtime identity.
   - Owner role; allowed EXECUTE roles; tables/columns; RLS; audit event; transaction and locks; outbox; error/retry behavior.
   - Compatibility aliases and removed/merged operations with rationale.
3. `docs/database/phase-2.12-view-access-matrix.md`
   - Exactly 30 views or replacement projections.
   - Invoker/definer choice; allowed roles; base-column grants; applicable RLS; sensitive exclusions; API exposure.
4. `docs/security/phase-2.12-runtime-identity-and-actor-model.md`
   - Role/credential matrix for domain function owners and each system workload.
   - User/system/webhook actor authentication and audit mapping.
   - Explicit ban on browser-supplied actor IDs as authentication evidence.
   - Credential boundaries and residual service-role risks.
5. `docs/security/phase-2.12-audit-outbox-concurrency-spec.md`
   - Canonical audit event list and writer ownership.
   - Atomicity, append-only enforcement, score edit history, discussion metadata audit.
   - Transactional outbox/inbox and idempotency lifecycle.
   - Locks, uniqueness and concurrency invariants mapped to operations.
6. `docs/security/phase-2.12-private-helper-trigger-matrix.md`
   - Exactly 18 private helpers/trigger functions, including trigger binding, owner, invoker/definer, search path, RLS policy dependence, recursion risk, nested calls and grants.

### Review/validation history

7. `docs/security/phase-2.13-independent-review.md`
   - Recovered adversarial findings with IDs/severity, exact artifact/section, disposition, evidence and remaining blockers.
8. `docs/security/phase-2.13.1-validation-plan.md`
   - Dependency-ordered disposable tests, identities/routes, positive/negative checks, approval gates, evidence and cleanup.
9. Keep `docs/security/phase-2.14-read-only-preflight.md` as the chronological preflight record and append subsequent read-only findings with dates and command outputs sanitized.
10. Keep `docs/security/phase-2.14.2-migration-workflow-design.md` as workflow proposal; revise only after this review’s gaps have decisions and independent sign-off.
11. Add `docs/security/phase-2-decision-index.md` linking approved decisions to their source request, canonical document, review, status, and validation evidence. Mark conversation-only material distinctly from file evidence.

Each restored matrix should carry a stable identifier and revision date. Reviewers should be able to diff every row against the existing SQL draft without inferring which old function or view it represents.

## 8. Unresolved migration workflow questions

1. What exact CLI 3.1.0 command and runtime will be the deployment path: local operator shell or controlled CI?
2. Which separate platform and database credentials does that path require, how are they delivered without command-line/log exposure, and what target-scoped permissions do they carry?
3. What are the actual migration `session_user`, `current_user`, and newly created function owner through that exact path?
4. Which trusted principal can create domain owner roles and grant/revoke membership? Can it give only `SET`, no `INHERIT`, no `ADMIN` to the migration identity for a limited window?
5. How can a grantor safely wrap that window around a `db push` session without leaving authority after CLI crash, cancellation, or partial migration?
6. Does PostgreSQL/Supabase require schema `CREATE` for `CREATE OR REPLACE` of an existing function versus only for new functions/ownership transfer in this exact workflow? What is the minimum scope and recipient of that privilege?
7. Are grants, replacement DDL, revocation, and migration-history writes atomic under the exact CLI invocation? What catalog/history state remains after each injected failure?
8. How is a pre-existing but untracked remote schema reconciled when local and remote migration lists appear empty?
9. How will each domain owner and every API/runtime role be proven unable to assume another domain owner, directly or transitively?
10. What is the approved recovery process if temporary owner membership or schema `CREATE` survives a failure and the migration operator is not the grantor?
11. Which exact five system runtime identities are approved, and do their grants/credentials remain isolated in actual deployment infrastructure?
12. Which payment runtime is independently operated, and how are transactional outbox delivery, provider idempotency, and reconciliation secured?

## 9. Recommended next steps

1. **Preserve NO-GO.** No SQL drafting for deployment and no identity probe request yet.
2. **Recover authoritative sources.** Export the Phase 2.12/2.13/2.13.1 conversation artifacts or have the owner approve reconstruction from the accepted instructions. Mark any unrecoverable detail unresolved rather than guessing.
3. **Restore the decision matrices.** Reconcile all 79 operations, 30 views, and 18 private/helper/trigger functions to the existing SQL by exact signature/name. Preserve prior payment, team, recruiter, judge, moderation, certificate, audit, and webhook invariants.
4. **Resolve contradictions.** Produce an explicit mapping from old universal-owner/service-role/direct-audit/invoker-view SQL to the accepted target design. Do not edit old artifacts until the recovered architecture is approved.
5. **Repair the workflow design on paper.** Define the grantor, temporary role/schema privilege sequence, transaction and revocation behavior, and safe failure recovery. If no exact hosted-compatible design avoids permanent broad authority, document that as a technical blocker and revisit the deployment model.
6. **Independent security review.** Have a reviewer verify every function/view/trigger row, privilege edge, actor source, audit/outbox event, and migration sequence against the canonical architecture.
7. **Only after that review, prepare an approval-gated disposable probe package.** No production access; exact disposable ref on every remote command; read-only preflight first; migration-path identity and subsequent replacement are separate authorized mutations.
8. **Update Phase 2.14 evidence chronologically.** Reconcile the latest user-supplied migration-list/version/diagnostic-role findings with the stale auth-failure report without deleting the earlier result.

## 10. Final decision

**NO-GO — do not request approval for the Phase 2.15 migration identity probe or begin migration implementation.**

The current workflow route is documented but not proven feasible. The migration operator identity is unknown; the temporary domain-owner privilege mechanism has no demonstrated grant/revoke control plane or failure-safe transaction boundary; and the approved Phase 2.12/2.13 matrices are not recoverable from the local Git history. Recover and independently review the canonical architecture first, reconcile stale SQL/RLS artifacts, and prove a least-privilege ownership lifecycle exclusively in the disposable project before changing this decision.
