# Phase 2.14.5 — Independent Adversarial Security Architecture Audit

**Review type:** Static adversarial review of the three Phase 2.14.4 documents, current SQL draft, and surviving Phase 2.3–2.14.3 records.  
**Decision:** **NO-GO — corrections and evidence required before detailed SQL drafting or database-changing validation.**  
No database connection, SQL execution, migration, credential access, or project mutation occurred.

## Executive verdict

Phase 2.14.4 correctly preserves NO-GO and rejects the universal owner/service-role model. This review does not approve the replacement design. The architecture is a direction, not an enforceable security contract.

A row labeled “U; D team” does not establish who may execute it, what identity is visible inside SECURITY DEFINER, which exact columns/tables the owner may access, what RLS predicate applies to that owner, or how nested definer/trigger calls are bounded. System runtime and migration paths remain unproved. Trigger-owned audit provides atomicity, not actor authenticity or protection from privileged database administrators.

### Severity summary

| Severity | Count | Main issues |
|---|---:|---|
| Critical | 4 | Caller identity binding; audit actor authenticity; definer/RLS privilege boundary; migration replacement lifecycle |
| High | 8 | Function ACLs; payment trust; views; recruiter scope; audit tampering; outbox; certificate limiting; incomplete API compatibility |
| Medium | 7 | Concurrency/state transitions; consent revocation semantics; judge/submission lifecycle; retention; aggregates; poolers |
| Low | 3 | Role naming; alias evidence; provenance labels |

Counts refer to report findings; matrix row references do not add findings.

## Evidence boundary

**Verified by static inspection:** local SQL declares 79 public functions, 30 public views and 18 private functions; all public RPC definitions use SECURITY DEFINER; all views use security_barrier and none use security_invoker; the draft includes legacy incux_rpc_owner broad grants, explicit service_role grants, many direct audit inserts, numerous SELECT*/rowtype/RETURNING* forms and row_security=off settings. Earlier reports document corrections/findings for payment, team exceptions, moderation, certificate verification, recruiter consent and H6. These are facts about draft text only.

**Proposed, not verified:** Phase 2.14.4 function/view/helper dispositions, trigger-owned audit, domain owners, runtime logins, independent payment runtime, outbox, and invoker-view conversions. Exact role names/grants/RLS/ACLs, hosted connection route, trigger identity and migration lifecycle have not been validated. Original Phase 2.12/2.13/2.13.1 specifications are missing from this checkout and Git history; no historical detail is invented.

## Critical findings

### C-01 — SECURITY DEFINER does not prove caller identity

**Affected:** architecture §§2–3; all D/S/W function rows. Inside a definer function current_user is the owner, not the invoker. session_user may identify a login, but a pooler/shared login is not an authenticated participant. auth.uid() is usable only when a verified JWT context is actually supplied. The design does not specify a non-forgeable caller identity path for every Edge, PostgREST, custom LOGIN and webhook case.

**Correction:** specify exact route and observable identity for each caller class, including behavior in definer bodies/triggers and pooled connections. User Edge flows must forward a verified JWT to the DB boundary; a service credential plus browser actor ID is insufficient. Workload identities must map to a fixed authenticated system principal. If that cannot be established, move the operation behind a separate authenticated service boundary. Fail closed on absent/conflicting identity.

### C-02 — Audit actor is not yet trustworthy

**Affected:** architecture “Identity and audit”; helper 13; all mutations. Trigger-owned audit is atomic, but trigger identity can be the definer owner; direct LOGIN workers may have no JWT claims. A caller-controlled custom GUC is forgeable. The document does not define how invalid or missing actor context is handled or how user-provided reasons/metadata are validated.

**Correction:** define authoritative actor source for JWT, each worker, and webhook, with negative tests for forged GUCs, parameters and reused sessions. No user actor ID parameter is proof. If there is no verified JWT, record only a fixed workload actor derived from authenticated DB identity. Use event allowlists and fail closed rather than inventing a user actor.

### C-03 — Domain owner + FORCE RLS is not a complete privilege model

**Affected:** architecture role table and all D rows/helpers. Exact owners, function membership, table/column grants, schema USAGE/CREATE, policy predicates, nested EXECUTE, search_path and trigger attachments are absent. A permissive owner-specific policy can make a definer a cross-user oracle. A compromised definer has all privileges reachable through its owner and nested definers. FORCE RLS does not neutralize superuser/BYPASSRLS or table owner behavior.

**Correction:** provide exact owner/function/call graph and grants; no owner table/schema ownership or memberships; no API/runtime SET ROLE path; minimal fixed search_path, qualified objects and no untrusted CREATE; narrow policies with recursion analysis; separate user-context and system-context functions. Test each owner as an adversarial principal.

### C-04 — Migration lifecycle remains unproven

**Affected:** architecture §7; Phase 2.14.2 §§3–8; decision register D-025/D-026. The grantor, temporary membership/SET ROLE and schema CREATE path, later replacement of owner functions, cleanup after interruption and transaction/migration-history behavior are unresolved. Initial ownership transfer does not prove subsequent replacement authority.

**Correction:** preserve NO-GO. In a separately approved disposable test, prove expected denial, temporary least privilege, replacement, revocation, post-checks, subsequent migration, and failure recovery at each boundary. If no safe JIT path exists, redesign first.

## High findings

- **H-01 Function access manifest missing:** Phase 2.14.4 explicitly leaves exact columns, nested calls and ACLs for later derivation. It is not yet possible to grant least privilege. Add exact signature, caller, EXECUTE roles, authz predicate, identity source, owner, columns read/written, sequence needs, RLS, call graph, audit, locks, idempotency and compatibility consumer for all 79.
- **H-02 User/system call paths ambiguous:** payment_create_order says Edge retains a JWT but does not show how the DB verifies it after orchestration. Several operations mix user and system actors. Direct invoker proposals lack concrete policies. Split mixed operations; user identity must come from auth.uid or a verified JWT forwarded to the DB.
- **H-03 Payment trust binding incomplete:** provider signature is verified in an independent runtime, but DB cannot infer that from an event digest or boolean. Exact payment runtime auth, credential scope, raw-body handling, replay/out-of-order logic, compromised credential response and refund completion proof are unspecified. payment_finish_refund(..., bool) is unsafe if the boolean is trusted.
- **H-04 View matrix lacks implementation detail:** no exact output-to-source map, owner, underlying privileges, role grants or RLS per view. security_invoker alone is not sufficient and may fail closed or expose rows depending on underlying grants/policies. Replace sensitive cross-domain projections where needed.
- **H-05 Recruiter consent/workspace boundary incomplete:** current live consent and role/grant are described, but concurrent revocation semantics, cached/in-flight reads, shared workspace rules, exported data and retention are not. Carry forward Phase 2.4 consent scope/version/current-required-version behavior explicitly.
- **H-06 Audit tamper boundary incomplete:** database triggers can be disabled/altered by sufficiently privileged DDL. External immutable retention is deferred, although migration/admin compromise is in scope. Event duplication, PII/whole-row JSON, user-controlled reason retention and coverage are open.
- **H-07 Outbox is prose, not a recoverable design:** no schema, uniqueness, lease/fencing, retry/backoff, dead letter, idempotency mapping, ordering, reconciliation or retention. Define and test crash-before-call, crash-after-provider-success-before-ack, duplicate and out-of-order events.
- **H-08 Certificate verifier limits are not actionable:** no chosen limiter, keys, thresholds, response equivalence, distributed storage, alerting or abuse handling. No public direct table/function grant; use unpredictable codes and minimal uniform responses with per-source plus global limiting.

## Medium and Low findings

### Medium

- **M-01 Team concurrency:** global lock ordering, competing invitations, membership uniqueness, last-leader behavior, deferred constraint timing, payment lock interaction and retry semantics are unspecified. Test join/accept/remove/transfer/payment races.
- **M-02 Payment transitions:** cancellation actors are mixed; refund request/approval/execution separation, failed/retry transitions and the boolean completion parameter are unresolved. Lock and conditionally update the successful order while enforcing cumulative refund caps.
- **M-03 Judging:** lock order across assign/conflict/revoke/save/submit/release, in-flight revoke semantics, rubric version pinning and score visibility snapshots are missing.
- **M-04 Submission/community lifecycle:** explicit source-state → target-state rules and acting-user/timestamp/reason audit mapping are absent. Preserve Phase 2.4 no draft-to-published moderation path.
- **M-05 Retention:** recruiter notes, consent history, webhook digests, audit, score edits, outbox and verifier records need purpose-specific retention/minimization.
- **M-06 Aggregates:** community_reaction_counts can expose small-group/private activity; define grouping, suppression floor, timing and private-post exclusion.
- **M-07 Runtime/pooler:** custom logins, PostgREST mapping, transaction pooling, separate credentials, SET ROLE denial and per-domain isolation are unvalidated.

### Low

- **L-01 Names are conceptual:** domain owner/runtime/private schema names are not an exact naming/grant registry.
- **L-02 Alias evidence missing:** team_respond_invitation is only “likely” a wrapper. Do not merge/drop functions until call sites and external consumers are checked.
- **L-03 Provenance risk:** earlier documents still contain detailed legacy grants; future users may follow them. Mark superseded docs in a later approved documentation phase and label supplied vs inspected evidence.

## Function-level review — all 79 operations

Each row evaluates the proposed Phase 2.14.4 disposition. All inherit H-01/C-01/C-03 until exact ACL, authz, identity, owner, column set and call graph exist.

| # | Function | Adversarial verdict / missing control |
|---:|---|---|
| 1 | team_create | D team; leader from auth.uid; validate invite/skill targets; serialize capacity and one-team constraints. |
| 2 | team_join | D; self identity, team lock, reject payment/roster lock, idempotency and unique membership. |
| 3 | team_request_join | I only with self-bound RLS and cross-row uniqueness; likely D if one-active-team cannot be constrained. |
| 4 | team_decide_join_request | D; recheck leader and request/team binding under lock. |
| 5 | team_invite_member | D; verify inviter authority, target eligibility, capacity and competing membership/invite. |
| 6 | team_accept_invitation | D; invitee must equal auth.uid; lock invite+team and revalidate expiry/capacity/roster. |
| 7 | team_respond_invitation | Separate API until proven alias; wrapper must not bypass or double-audit accept/reject. |
| 8 | team_revoke_invitation | D; authorized inviter/leader, pending-only, lock order and reason validation. |
| 9 | team_withdraw_join_request | I only if request owner is auth.uid and pending transition is row-safe. |
| 10 | team_expire_pending_workflows | S only; named runtime/ACL, bounded claims, idempotent expiry and retry absent. |
| 11 | team_remove_member | D; target ID not actor; leader/admin permission, last leader, paid roster exception and audit. |
| 12 | team_transfer_leader | D; actor is current leader/admin; target active member; serialize exactly-one-leader invariant. |
| 13 | team_dissolve | D; authorize leader/admin and preserve paid financial, submission and certificate records. |
| 14 | team_lock_roster | D; caller cannot freely toggle boolean; derive payment state and require audited override. |
| 15 | team_post_payment_exception | D high impact; Super Admin, explicit rows/reason, immutable financial facts and audit; do not assume old fix applies. |
| 16 | team_policy_set | D; immutable effective policy versions; prevent invalidating teams pinned to prior version. |
| 17 | admin_grant_role | D identity; delegation and last Super Admin under serialization; actor from JWT. |
| 18 | admin_revoke_role | D identity; prevent self/last-admin lockout and define immediate revocation. |
| 19 | admin_grant_permission | D; permission scope allowlist, delegation/expiry and required reason. |
| 20 | admin_revoke_permission | D; serialize privilege changes and identify grant source/delegator. |
| 21 | admin_grant_recruiter_access | D recruiter; verify role and purpose; access grant never replaces participant consent. |
| 22 | admin_revoke_recruiter_access | D; define in-flight/cached read semantics and audit. |
| 23 | admin_set_recruiter_consent_version | D; immutable version/effective cutover; reconcile required-version table from Phase 2.4. |
| 24 | admin_transfer_super_admin | D; ignore p_operator_user_id as proof; use auth.uid, serialize role set and verify target. |
| 25 | payment_set_gateway_order | S payment; provider reference uniqueness, order linkage and retries; authenticate exact runtime. |
| 26 | payment_set_fee | U payment-config admin; immutable INR version, reason/actor/time; concurrent order snapshots. |
| 27 | payment_cancel_fee_version | U admin; cannot rewrite existing snapshots; define retirement/cancellation and order race. |
| 28 | payment_create_order | U JWT + E/D; team leader from auth.uid, preserve verified JWT to DB, snapshot fee and lock roster/outbox. |
| 29 | payment_record_verified_webhook | W only; raw-body signature verified externally; authenticated payment runtime; DB checks event/order/amount/currency/state/idempotency. |
| 30 | payment_expire_order | S payment/team; exact worker scope, lock order/team, safe unlock, idempotent retry. |
| 31 | payment_cancel_order | Split user and system/provider cancellation if actors differ; no paid fact mutation. |
| 32 | payment_request_refund | U authorized approver; lock paid transaction/order; cumulative cap; requester/approver separation. |
| 33 | payment_finish_refund | W/S; do not trust bool; provider result/event authenticated, same-order linkage and legal transitions. |
| 34 | payment_issue_receipt | S; successful paid order only, unique retry, minimal PII and fixed worker. |
| 35 | recruiter_set_consent | U participant; subject=auth.uid; immutable scope/version; serialize revocation. |
| 36 | recruiter_add_shortlist | U recruiter; current role+grant+consent at write and read; target ID is not authority. |
| 37 | recruiter_save_note | Same plus private author scope, retention, deletion and metadata-only audit. |
| 38 | community_create_post | U/I only for own draft; publish state cannot be caller-selected without publish permission. |
| 39 | community_create_comment | U; author auth.uid; same-post parent, audience/team policy and abuse limit. |
| 40 | community_report_content | U; reporter auth.uid; valid type/ID binding and duplicate/report abuse rules. |
| 41 | team_post_discussion_message | U current member; membership check at read/write; no moderator/recruiter access; metadata audit. |
| 42 | judge_assign_submission | U eval admin; target judge/submission, active role, conflict, duplicate and reassignment race. |
| 43 | judge_declare_conflict | U assigned judge; bind assignment/submission, immutable conflict history and immediate access restriction. |
| 44 | judge_resolve_conflict | U eval admin; actor not silently self-clearing; current assignment/role and reason. |
| 45 | judge_save_score | U assigned judge; own assignment/rubric, lock vs submit/revoke, append-only score history. |
| 46 | judge_submit_evaluation | U judge; lock and validate completeness/rubric; one-way lifecycle and idempotency. |
| 47 | submission_save_version | U team member; derive actor, validate current membership/deadline; version uniqueness under race. |
| 48 | submission_finalize | U authorized member/leader; same-team relation, deadline and single finalization atomically. |
| 49 | event_set_submission_deadline | U event admin; identify event/config version; audit and finalize race semantics. |
| 50 | evaluation_release | U authorized release admin; exact event/scope; atomic release and no premature projection. |
| 51 | certificate_verify | P endpoint only; no direct table/general RPC; uniform response, entropy and limits required. |
| 52 | certificate_issue | U cert admin; eligibility, unique unpredictable code, retry idempotency and consent policy. |
| 53 | certificate_grant_name_consent | U participant; auth.uid subject, scope/version/history; immediate view update. |
| 54 | certificate_revoke | U cert admin; valid state, reason/history and public response/cache behavior. |
| 55 | certificate_revoke_name_consent | U participant; auth.uid subject; history and remove public name without revoking certificate. |
| 56 | registration_decide | U registration admin; no self-approval, valid transition, reason and serialized update. |
| 57 | registration_submit | U/I or D; own registration via auth.uid; eligibility and duplicate submission rules. |
| 58 | registration_withdraw | U; own row; legal withdrawal state, reason, paid/team interaction and audit. |
| 59 | community_moderate | U moderator; report-target binding and allowed state transitions; draft never becomes published. |
| 60 | admin_invitation_create | U authorized admin; token digest only, recipient/role scope, expiry and one-use. |
| 61 | admin_invitation_revoke | U admin; pending-only, reason and acceptance race lock. |
| 62 | admin_invitation_accept | U invitee; p_user_id must equal auth.uid; bind token, invitation and role scope. |
| 63 | admin_announcement_create | U admin draft only; cannot insert published state/audience bypass. |
| 64 | admin_announcement_update | U author/admin; split draft edit from published correction with permission/audit. |
| 65 | admin_announcement_target | U admin; validate target/audience and prevent unauthorized expansion after publish. |
| 66 | admin_announcement_publish | U authorized publisher; draft-only transition, audience/date validation and audit. |
| 67 | admin_schedule_create | U draft only; interval/timezone/event validation and no publish-on-create. |
| 68 | admin_schedule_publish | U publisher; draft-only, timestamp/version and audit. |
| 69 | admin_schedule_update | Split draft edit/published correction; valid interval and reason. |
| 70 | admin_rubric_create | U eval admin; draft version scope, duplicate behavior and audit. |
| 71 | admin_rubric_add_criterion | U eval admin; bounds/order uniqueness, draft-only and edit lock. |
| 72 | admin_rubric_publish | U eval admin; atomic validation and immutable rubric version pinned to assignments. |
| 73 | admin_certificate_type_set | U cert admin; version configuration; issued certs unaffected and audit. |
| 74 | service_enqueue_notification | S notification; fixed runtime, recipient/template allowlist, idempotency and payload minimization. |
| 75 | admin_community_category_set | U community admin; allowed category/state and reclassification audit. |
| 76 | team_skill_requirement_set | U leader/admin; membership authority; forbid post-lock edits except approved exception. |
| 77 | admin_skill_set | U catalog admin; normalized uniqueness; referenced skills cannot be silently invalidated. |
| 78 | admin_technology_set | U catalog admin; normalized uniqueness and safe visibility. |
| 79 | admin_interest_area_set | U catalog admin; normalized uniqueness and recruiter-consent implications. |

No alias is confirmed. Keep every signature until repository call sites and external clients are audited.

## View-level review — all 30

None is approved until output-to-source columns, owner, underlying grants and RLS are enumerated. All should use security_invoker only where caller grants/RLS enforce the same boundary; otherwise replace with a narrow projection/endpoint.

| # | View | Required boundary / concern |
|---:|---|---|
| 1 | my_profile | Self RLS; phone/address/education private; explicit output columns. |
| 2 | my_registration | Self only; decision reason/status sensitivity. |
| 3 | public_team_directory | Public approved fields only; exclude private/dissolved teams and contacts. |
| 4 | my_team_roster | Current member only; display names, no contact details. |
| 5 | my_teams | Current member only; do not expose admin/payment fields. |
| 6 | current_team_size_policy | Active approved policy only; no draft/future admin data. |
| 7 | current_team_fee | Active INR amount/version; exclude internal change reason. |
| 8 | my_payment_summary | Own team/leader; no gateway payload, provider token or other team. |
| 9 | recruiter_candidate_directory | Replace/narrow; current grant+scope+consent in same read. |
| 10 | recruiter_candidate_skills | Candidate skills are personal data; same live consent. |
| 11 | recruiter_candidate_links | URLs may expose contact/profile; consent scope must include links. |
| 12 | released_evaluation_projection | Released only; omit judge identity, private notes and unreleased scores. |
| 13 | my_submission_versions | Current team member; repo/demo links may be private/secrets. |
| 14 | public_released_projects | Released only; suppress unreleased/private metadata. |
| 15 | public_community_feed | Published audience only; exclude hidden/team-private posts. |
| 16 | public_announcements | Published and audience-matched; do not reveal other recipients. |
| 17 | public_schedule | Published only; exclude drafts/admin metadata. |
| 18 | my_role_summary | Own roles from protected grants, not editable profile/JWT metadata. |
| 19 | my_admin_permissions | Authorized own scope only; privileged metadata. |
| 20 | authorized_audit_log | Replace with narrow authorized projection; never grant raw audit broadly. |
| 21 | my_admin_invitations | No token/hash/secret; prevent enumeration. |
| 22 | recruiter_candidate_interests | Same live consent/grant; interest profile sensitive. |
| 23 | my_recruiter_notes | Author/explicit reviewer only; consent and retention rules. |
| 24 | my_candidate_shortlists | Private per recruiter until workspace membership is designed. |
| 25 | my_judge_assignments | Active assigned judge only; hide revoked/conflict assignments. |
| 26 | my_judge_score_sheet | Own draft only; no peers/final totals before release. |
| 27 | my_certificates | Own record; never expose verification code. |
| 28 | my_notifications | Recipient only; payload minimization. |
| 29 | my_team_discussion_messages | Current member only; no recruiter/moderator by default. |
| 30 | community_reaction_counts | Suppress small/private groups; define group key and timing. |

Strong replacement candidates: views 9–11, 20, 22–24, 26, and 29; also assess 12/14. Views 8, 13, 18/19 and 27 require strict column allowlists.

## Helper/trigger review — all 18

| # | Helper/trigger | Adversarial check |
|---:|---|---|
| 1 | private.has_role | RLS recursion on role grants; protected lookup, no editable metadata. |
| 2 | private.has_permission | Recursion/delegation; cannot authorize its own grants. |
| 3 | private.is_team_member | Membership policy recursion; narrow helper SELECT and no public EXECUTE. |
| 4 | private.is_team_leader | Same plus active leader freshness. |
| 5 | private.can_judge_submission | Assignment, active role, conflict and event; hide peer evaluations. |
| 6 | private.can_recruiter_view | Current role/grant/scope/consent version every read. |
| 7 | private.assert_team_roster | Internal only; validated actor/team, locks and applicable policy version. |
| 8 | private.team_roster_constraint_trigger | Deferred/concurrent roster checks; direct DML and trigger bypass tests. |
| 9 | private.check_score_bound | Nonnegative/max; criterion belongs to rubric; rubric edit race. |
| 10 | private.guard_published_rubric | Block all mutation paths, cascades and definer writes after publish. |
| 11 | private.check_comment_parent | Same-post parent FK/trigger; concurrent parent changes. |
| 12 | private.check_moderation_target | Report target/type binding and legal source state. |
| 13 | private.log_state_transition | Actor authenticity, metadata allowlist, duplicate/PII control, trigger-only INSERT. |
| 14 | private.guard_payment_order_update | Snapshot immutability and valid transitions; exception does not rewrite facts. |
| 15 | private.reject_financial_fact_mutation | Trigger can be changed by DDL owner; test privileges and external tamper threat. |
| 16 | private.guard_transaction_update | Event/order/amount/currency and transition; duplicate/out-of-order handling. |
| 17 | private.guard_refund_transition | Lock same order/transaction and cumulative cap; no success-boolean trust. |
| 18 | private.touch_updated_at | Keep invoker/trigger-only and free of security-sensitive side effects. |

For every helper, specify owner, EXECUTE callers, table/column reads, attached triggers, fixed search_path and nested calls. Triggers do not prevent table owners, migration operators or superusers from changing data/DDL.

## Cross-domain attack scenarios

| Attack | Expected defense | Specified sufficiently? |
|---|---|---|
| Participant impersonates another via user ID | auth.uid and target authorization | Principle yes; per-body/ACL proof no. Several functions accept user IDs. |
| Concurrent double-team join / sole leader removal | Unique constraints, ordered locks, roster trigger | Invariant stated; complete lock graph/tests absent. |
| Admin self-grant / last Super Admin removal | Protected grant functions, delegation, serialization | General rule only; exact predicates and race guard absent. |
| Recruiter reads after consent revoke | Live scope consent + access grant | Desired; in-flight/cached/workspace semantics absent. |
| Judge reads unassigned project | Active assignment+role+no conflict | Desired; exact helper/ACL/revocation race absent. |
| Client forges paid status | No user EXECUTE; authenticated payment runtime and DB checks | Runtime credential and exact ACL unproved; refund bool risk remains. |
| Duplicate/out-of-order webhook | Unique event IDs + idempotent state machine | Requirements stated; inbox/outbox and ordering details absent. |
| Concurrent refunds exceed paid amount | Lock payment/order and reserve remaining amount | Requirement stated; state graph and retry path absent. |
| Certificate code enumeration | High entropy, uniform output and distributed limits | Generic rate-limit prose only. |
| Forged audit actor/event | No caller audit DML, DB-derived actor | GUC rejected; reliable trigger actor mapping not supplied. |
| Payment runtime compromised | Isolated credential, payment-only functions, rotate/revoke | Runtime boundary intended; grants/incident response absent. |
| Migration operator self-escalates/leaves grant | JIT separate grantor, revoke and catalog check | Candidate only; actual operator/grantor unknown. |
| Moderator restores draft as published | Allowed transition denies draft→published | Phase 2.4 says fixed, but current callable path/ACL must be verified. |
| View leaks through owner | security_invoker + underlying RLS/grants or narrow endpoint | Goal stated; ownership/grants/output absent. |
| Search path object substitution | Minimal fixed path, qualified names, no untrusted CREATE | Recommendation only; not per-function proven. |

## Migration feasibility and traceability

- The actual migration DB identity, session_user, current_user, object owner and later-migration identity remain unknown. Read-only identity is not migration evidence.
- Domain owner creation, ownership transfer, JIT grantor/SET ROLE, schema CREATE, later replacement and revocation after failure have not been tested.
- Phase 2.14.2 recommends serialized CLI migrations only as a candidate. Phase 2.14.4 correctly keeps it proposed; a dry run is not identity evidence.
- Phase 2.6/2.8 role-validation script targets the superseded incux_rpc_owner design; do not reuse as proof.
- Phase 2.4 says recruiter consent changes serialize and current required versions invalidate stale consent; Phase 2.14.4 should carry those exact rules forward.
- Phase 2.4 moderation correction and certificate direct-access removal are intended invariants, not proof that current ACL/body paths satisfy them.
- D-020/D-021 preserve counts; count preservation does not prove compatibility. team_respond_invitation remains only a suspected alias.
- Old SQL/RLS docs still contain legacy grants. Later approved documentation work must label them superseded before implementation.
- Earlier preflight facts must be labeled user-supplied or independently inspected; this review performed no re-query.
- No missing historical specification is reconstructed as fact.

## Required corrections before drafting

1. Resolve C-01 through C-04 with exact identity, owner/RLS, audit actor, and migration control-plane designs.
2. Complete 79-function authz/ACL/column/call-graph/lock/audit/alias matrix.
3. Complete 30-view output/owner/grant/RLS matrix; replace sensitive views where needed.
4. Complete 18-helper/trigger owner, attachment, ACL, search_path and recursion matrix.
5. Specify outbox/inbox state, leasing, fencing, idempotency, replay and recovery.
6. Reconcile Phase 2.4 consent version, moderation publish and certificate routing commitments.
7. Resolve business values separately; invent none.
8. Keep Phase 2.6 validation package historical unless independently redesigned for the accepted architecture.
9. After correction, request independent review; only then request separate approval for disposable-only mutations.

## Final readiness decision

**NO-GO — corrections required.** The high-level direction is defensible, but detailed identity binding, least-privilege grants, owner/RLS boundaries, audit trust, view output security, runtime isolation and repeatable migration lifecycle are not yet sufficiently specified or validated. Do not draft implementation SQL, execute probes, or migrate.

