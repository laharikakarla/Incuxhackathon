# AICUXORA Phase 4.1 — Registration Decision

**Status:** Product decision recorded; backend design and implementation remain blocked by the Phase 2.12–2.14 security and migration findings.  
**Scope:** Static documentation. No Supabase connection, SQL execution, migration, or application change was performed.

## 1. Confirmed decisions

1. Students may create accounts before payment is activated.
2. Email verification is required.
3. Students may complete their profiles independently of payment.
4. Each student submits an individual AICUXORA event registration.
5. Teams contain 2–5 members.
6. Payment will be introduced in a later phase.
7. Payment will be charged per participant, never once per team on behalf of all team members.
8. The registration fee is not yet confirmed.
9. The payment provider is not yet selected.
10. The event venue is not yet confirmed.

This replaces the previous product ambiguity between free initial registration and paid registration. It also conflicts with the older database proposal's assumed per-team payment model. The old proposal must be reconciled before database implementation; it must not be silently treated as current.

## 2. Required separation of concepts

The product and future backend must keep these concepts independent:

| Concept | Meaning | Identity/state source | Must not imply |
|---|---|---|---|
| Authentication identity | The verified principal that signs in. | Supabase Auth subject and verified JWT; user identity in database operations comes from `auth.uid()`. | Profile completion, event registration, team membership, or payment. |
| Student profile | Student's editable event/profile information. | Profile is linked to the authenticated principal; owner authorization is enforced server-side. | Email verification, registration acceptance, or payment. |
| Event registration | One student's application/entry to AICUXORA 2027. | An individual registration lifecycle with server-enforced transitions. | Payment success or team membership. |
| Team membership | A student's relationship to a team, subject to the 2–5 member rule. | Current membership and role are checked transactionally. | Another member's registration or payment state. |
| Individual participant payment | That participant's own fee obligation and payment history, activated in a later phase. | Verified provider transaction/webhook and trusted database state tied to the correct participant and event registration. | Payment by a team leader or another participant. |

No caller-supplied user ID is proof of identity. No frontend flag, registration submit action, team leader status, or teammate payment can set an individual's payment status.

## 3. Updated student journey

1. **Create account:** student signs up without being charged. Account creation does not depend on payment availability.
2. **Verify email:** student completes the Auth provider's verified email flow. The UI must wait for authenticated provider state rather than displaying a successful verification state based only on local form submission.
3. **Complete profile:** student adds profile information at any point after account creation; payment is not required.
4. **Submit individual event registration:** student submits their own AICUXORA registration. The backend must validate the authenticated actor and registration eligibility and record the registration lifecycle separately from profile and payment.
5. **Join or create a team:** team membership is a separate operation. Team size must remain within 2–5 members, including the leader. Team operations enforce current membership and capacity atomically.
6. **Payment activation in a later phase:** when the fee and provider are approved, each participant completes their own payment flow. Existing accounts, profiles, registrations, and teams do not become paid automatically.
7. **Payment result:** only trusted server-side processing of a verified provider event may record success. A participant's displayed payment state comes from that participant's own validated payment record.

The exact order between registration and team formation beyond the confirmed independence is not prescribed here; registration is individual and cannot be represented as a team-level payment or registration.

## 4. Registration and payment lifecycle requirements

### Authentication and profile

- Registration/account creation is available before payment is activated.
- Email verification is mandatory for the verified participant journey.
- Profile completion and edits do not require payment.
- Account, profile, registration, and payment state are distinct. Do not overload a single `status` field to represent them all.

### Event registration

The design must support an individual submission and distinguish at minimum:

- no event registration submitted;
- submitted/received;
- any review/approval decision, if the product confirms review is required;
- withdrawn or otherwise closed, if supported by policy.

Exact labels and allowed transitions are a later schema-design decision. A submitted registration must not set payment to successful, paid, or settled. The product owner has not confirmed whether registrations require manual approval or how eligibility is determined.

### Individual participant payment (future phase)

When activated, the future model must:

- tie every obligation/order, provider transaction, refund and receipt to the individual participant and the correct event/registration context;
- snapshot the fee version, amount and currency when an order is created; later fee changes must not rewrite existing orders;
- use the participant's own payable state and never infer it from their team leader or another member;
- require verified provider signatures, event-id idempotency, amount/currency/order matching and transactionally safe state transitions;
- tolerate duplicate, delayed, retried and out-of-order webhook deliveries without duplicate success;
- retain immutable financial history and record refunds as separate audited events, with serialized checks preventing cumulative refunds above the successfully paid amount;
- issue receipts only after validated success and prevent ordinary users from directly writing payment status;
- use the independently controlled payment/webhook runtime direction accepted in Phase 2.12–2.14, subject to the outstanding runtime and database authorization validation;
- avoid holding database locks while making external provider calls; use a transactional outbox/inbox or another approved retry-safe boundary;
- define expiry, failure, cancellation, partial refund, full refund, reconciliation and retention behavior before implementation.

These are requirements, not new table or function definitions. The older schema draft uses team-level fee/payment assumptions and must be reworked through the approved architecture process rather than extended ad hoc.

## 5. Team rules and payment independence

- The confirmed team size is 2–5 members, with the leader counted as a member.
- Each student's registration remains individual regardless of team membership.
- Payment status is individual. Team membership does not combine charges, and a leader cannot pay or mark other members paid unless a future, explicit product and authorization decision allows a supported delegated checkout without merging payment ownership.
- A team's roster or eligibility must not be locked merely because a member has an individual pending payment unless a separately approved rule defines that interaction.
- If payment activation later changes participation eligibility, the database must evaluate each participant's own payment/registration state. It must not use the old per-team payment shortcut.

## 6. Remaining open decisions

- Registration fee amount and currency.
- Payment provider and supported payment methods.
- Whether payment is required before participation, team formation, submission, or only another milestone.
- Whether a registration is accepted immediately or reviewed, and whether eligibility rules apply.
- Whether team formation is allowed before registration submission or payment activation.
- Individual order expiry, retries, cancellation, refunds, partial refunds, chargebacks and exception policy.
- Whether an authorized payer may pay for another participant; default design assumption is no, and no shared payment state.
- Venue and final event logistics.
- Data retention, privacy wording and applicable consent requirements.
- Resolution of migration identity, domain-owner lifecycle, exact grants/RLS, audit actor authenticity and runtime connection behavior documented in Phase 2.14.4/2.14.5.

Do not invent values for these decisions in the UI or database design.

## 7. Security architecture continuity

This decision does not replace or weaken accepted security architecture:

- User identity derives from a verified signed JWT and `auth.uid()`.
- Prefer SECURITY INVOKER and RLS; use only narrowly scoped domain-specific SECURITY DEFINER transaction functions where justified.
- Do not use a universal function owner, routine broad `service_role` application access, editable profile/JWT role claims, caller-supplied actor IDs, or ordinary custom session settings as identity proof.
- System and webhook actors require separate authenticated execution paths and trusted actor classification.
- Sensitive lifecycle transitions and audit events are enforced by the backend and atomic transactions.
- Payment/webhook/refund processing remains isolated in an independently controlled runtime, pending disposable-project validation.
- The Phase 2.14.4/2.14.5 migration, ownership, grant, audit and runtime blockers remain unresolved. Phase 2.12–2.13 original source documents were not present in the local repository; preserve the traceability caveat recorded in the later documents.

## 8. Effect on Phase 4 readiness

The product-level registration decision is now clear enough to guide requirements: accounts, verification, profiles and individual event registration precede payment, with future per-participant payment. The prior Phase 4 product-conflict finding is resolved and has been replaced with a migration/design reconciliation item: the SQL draft still assumes initial free/per-team payment behavior.

**The NO-GO status has not changed.** This document does not approve backend implementation, SQL drafting, migrations, or database validation. The next design step is to reconcile registration and per-participant payment requirements into the authoritative security architecture, resolve the remaining business decisions, and close the existing Phase 2.14.5 blockers before requesting separately approved disposable-project validation.
