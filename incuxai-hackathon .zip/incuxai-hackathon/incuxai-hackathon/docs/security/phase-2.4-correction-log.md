# Phase 2.4 — Security Corrections and Static Self-Audit

**Scope:** Documentation and proposed SQL only. The SQL below is a design draft and was not executed. No Supabase project was contacted and no runtime claims are made.

## Correction log

### High findings

| Finding | Correction | Affected files and sections |
|---|---|---|
| H1 — malformed post-payment exception audit insert | Corrected the audit column/value arity and record before/after snapshots for the leader transfer or roster change. The RPC still requires a Super Admin, a nonempty reason, and row locking. | `docs/database/phase-2-schema-draft.sql`: `public.team_post_payment_exception`; `docs/database/phase-2-relationships.md`: post-payment roster exception; `docs/security/phase-2-rls-matrix.md`: team exception RPC. |
| H2 — moderator restore could publish drafts | `community_moderate` now hides only published content and restores only content currently hidden by moderation. It records the moderation action and requires a reason; drafts and archived content cannot be published by restore. | `docs/database/phase-2-schema-draft.sql`: `public.community_moderate`; `docs/database/phase-2-rls-matrix.md`: community moderation; `docs/security/phase-2-security-review.md`: moderation boundary. |
| H3 — public verifier bypassed edge limits | Removed direct `anon`/`authenticated` access and the global advisory lock. The verifier requires service role and is granted only to `service_role`; public checks must pass through a server-side Edge Function that enforces abuse controls. | `docs/database/phase-2-schema-draft.sql`: `public.certificate_verify` and final function ACL; `docs/database/phase-2-architecture.md`: certificate verification; `docs/security/phase-2-rls-matrix.md`: certificate verification; `docs/security/phase-2-security-review.md`: certificate boundary. |
| H4 — missing admin and communications workflows | Added narrowly scoped, permission-checked RPC proposals for admin invitation lifecycle, announcements and targeting, schedule management/publication, rubric authoring/publication, certificate type configuration, and service notification enqueue. Added explicit execution ACLs; invitation acceptance and notification enqueue are service-only. | `docs/database/phase-2-schema-draft.sql`: admin/communications RPC section and final ACL; `docs/security/phase-2-rls-matrix.md`: identity, communications, judging, and certificates; `docs/database/phase-2-architecture.md`: trusted admin workflows. |
| H5 — provider status reconciliation absent | Added webhook event status history and an idempotent reconciliation path for a verified failed-to-succeeded update of the same transaction. Immutable transaction identity and snapshots remain guarded; order application requires the order still be eligible, while late captures remain recorded but unapplied. | `docs/database/phase-2-schema-draft.sql`: `payment_webhook_events`, transaction immutability guard, `public.payment_record_verified_webhook`; `docs/database/phase-2-architecture.md`: webhook lifecycle; `docs/database/phase-2-relationships.md`: payment lifecycle. |
| H6 — Supabase owner-role compatibility unverified | Documented as a mandatory pre-migration compatibility gate: confirm the selected Supabase migration operator can create `incux_rpc_owner`, grant required privileges, and transfer ownership. The design explicitly forbids silently substituting a `BYPASSRLS` owner. This is not verifiable from static documents and remains unresolved pending controlled target-project validation. | `docs/database/phase-2-schema-draft.sql`: authorization/ownership contract and final ownership block; `docs/database/phase-2-architecture.md`: deployment prerequisite; this log: unresolved findings. |

### Medium findings

| Finding | Correction | Affected files and sections |
|---|---|---|
| M1 — stale comment claimed no policies existed | Replaced the placeholder with a note that policies and grants are proposed later in the draft and have not been executed. | `docs/database/phase-2-schema-draft.sql`: RLS policy preamble. |
| M2 — announcement audiences did not resolve to recipients | Expanded published audience checks and added recipient-specific role target visibility while preserving per-recipient target boundaries. | `docs/database/phase-2-schema-draft.sql`: announcement policies; `docs/security/phase-2-rls-matrix.md`: announcements; `docs/database/phase-2-relationships.md`: announcement targeting. |
| M3 — audit and Admin permission reads mismatched the matrix | Added safe, filtered views for the caller's permission grants, authorized audit metadata, and own invitations. The views omit sensitive target payloads and invitation email digests; direct raw audit access remains restricted. | `docs/database/phase-2-schema-draft.sql`: safe views and grants; `docs/security/phase-2-rls-matrix.md`: identity/audit rows; `docs/database/phase-2-architecture.md`: administrative projections. |
| M4 — recruiter consent ordering and version cutover | Serialized consent updates per participant and scope, and added a current required-version table. Recruiter visibility now requires the latest consent event to be affirmative and match the current required version; version changes are permission-checked and audited. | `docs/database/phase-2-schema-draft.sql`: `recruiter_consent_requirements`, `private.can_recruiter_view`, `public.recruiter_set_consent`, consent version RPC; `docs/database/phase-2-architecture.md`: consent versioning; `docs/database/phase-2-relationships.md`: consent lifecycle; `docs/security/phase-2-rls-matrix.md`: recruiter access. |
| M5 — matrix claims did not match SQL | Reconciled matrix entries to actual views, direct grants, and RPCs; clarified service-only operations and restricted catalog visibility to authenticated users. Added missing trusted workflows where appropriate. | `docs/security/phase-2-rls-matrix.md`: identity, catalog, community, judging, communications, and certificate entries; `docs/database/phase-2-schema-draft.sql`: corresponding policies, views, RPCs, and ACL. |
| M6 — lifecycle actions lacked state/audit completeness | Added audited registration withdrawal and join-request withdrawal with required reason. Moderation warnings are persisted as moderation actions and reports are transitioned to resolved/dismissed; status-specific moderation is restricted to valid source states. | `docs/database/phase-2-schema-draft.sql`: `public.registration_withdraw`, `public.team_withdraw_join_request`, `public.community_moderate`; `docs/security/phase-2-rls-matrix.md`: lifecycle RPCs; `docs/database/phase-2-relationships.md`: lifecycle notes. |
| M7 — expired pending order could be returned | `payment_create_order` now serializes on the team, locks the existing order, expires it inline if its deadline passed, unlocks the roster and records the transition before creating a new order. Expiry, cancellation, and webhook paths use the same team-then-order lock order. | `docs/database/phase-2-schema-draft.sql`: `public.payment_create_order`, order expiry/cancel and webhook functions; `docs/database/phase-2-architecture.md`: payment ordering; `docs/database/phase-2-relationships.md`: payment lifecycle. |

### Low findings

| Finding | Correction | Affected files and sections |
|---|---|---|
| L1 — verifier used a hard-coded global threshold and lock | Removed database-global rate counting and serialization. Per-source/global abuse thresholds, monitoring, and response are assigned to the public Edge Function boundary and must be configured before exposing verification. | `docs/database/phase-2-schema-draft.sql`: `public.certificate_verify`; `docs/database/phase-2-architecture.md`: certificate verification; `docs/security/phase-2-rls-matrix.md`: certificate verification. |
| L2 — privileged audit reasons could be empty or NULL | Enforced non-NULL, nonblank reasons in role grants/revocations, Admin permission grants/revocations, and Super Admin transfer. Transfer remains service-role-only, with the trusted operator recorded. | `docs/database/phase-2-schema-draft.sql`: `public.admin_grant_role`, `public.admin_revoke_role`, `public.admin_grant_permission`, `public.admin_revoke_permission`, `public.admin_transfer_super_admin`. |

## Static self-audit against the 15 findings

The source was inspected after the changes. This is static review only.

- [x] H1: post-payment exception audit insert uses matching columns and values and has before/after JSON snapshots.
- [x] H2: moderation restore is constrained to hidden content; draft/archived content cannot be published through restore.
- [x] H3: certificate RPC has no `anon` or `authenticated` execute grant; direct access is service-role-only.
- [x] H4: proposed admin/communications functions and explicit execute grants exist for the documented workflows.
- [x] H5: webhook event IDs are idempotent; verified same-transaction failed-to-succeeded status advancement is represented without rewriting immutable transaction identity; late/unapplied outcomes are retained.
- [ ] H6: target Supabase operator permissions and PostgREST behavior for the dedicated non-login owner cannot be proven without target-project validation. No insecure `BYPASSRLS` fallback is proposed.
- [x] M1: stale no-policy placeholder is removed.
- [x] M2: audience and role-target read policies are aligned to recipient visibility.
- [x] M3: safe Admin permission/audit/invitation projections are present and avoid exposing raw sensitive fields.
- [x] M4: participant/scope consent updates serialize and current required versions invalidate stale consent for future reads.
- [x] M5: matrix entries were reconciled with SQL policies, views, function signatures, and execution grants.
- [x] M6: join withdrawal and registration withdrawal have reasoned audit transitions; moderation records supported actions and validates the current state.
- [x] M7: expired pending order handling is done inline under the documented team-then-order lock sequence.
- [x] L1: certificate lookup no longer uses a fixed global database threshold or global lock; edge abuse controls remain a deployment requirement.
- [x] L2: the five listed privileged role/permission functions reject NULL and blank reasons.

## Remaining limitation and decision

**Unresolved finding: H6 (High).** The actual Supabase project and migration operator have not been checked. This cannot be safely represented as resolved by editing a document: it requires a controlled compatibility check against the intended deployment. The SQL remains a proposed, unexecuted draft, not a production-ready schema.

**Decision: NOT READY — CORRECTIONS REQUIRED.** The other 14 findings have corresponding design corrections in the reviewed documents. Do not begin database implementation until H6 has been resolved in a separately authorized controlled validation, and then perform database-level authorization, concurrency, and compatibility testing.

## Phase 2.7 follow-on — H6 ownership prerequisites

The Phase 2.6 planning review identified two specific SQL ordering/privilege prerequisites within H6. The Phase 2.7 design correction now:

- Grants schema `CREATE` to `incux_rpc_owner` immediately before safe-view owner transfers, and revokes it immediately afterward.
- Repeats the temporary schema grant before function owner transfers and revokes it before runtime RPC execute grants.
- Explicitly grants the trusted migration operator `incux_rpc_owner` membership with `SET TRUE`, `INHERIT FALSE`, and `ADMIN FALSE`; asserts that the operator can `SET ROLE`, cannot inherit the role's privileges, and no API role can `SET ROLE` to it.
- Requires PostgreSQL 16+ for per-membership options and stops on older versions pending a separately reviewed operator model.
- Documents the later-migration sequence: temporary schema `CREATE`, `SET ROLE incux_rpc_owner`, alter/replace owner-controlled views/functions, `RESET ROLE`, and revoke schema `CREATE`.

Affected locations: `docs/database/phase-2-schema-draft.sql` authorization contract, safe-view owner block, and final function owner block; `docs/database/phase-2-architecture.md` migration ownership sequence; `docs/security/phase-2-rls-matrix.md` role ownership and privilege boundary; `docs/security/phase-2-security-review.md` privileged function section; `docs/security/phase-2.6-validation-runbook.md` and `scripts/validation/phase-2.6-role-validation.sql` validation steps; `docs/security/phase-2.7-audit-report.md`.

**H6 remains unresolved.** Static source changes do not prove that the target Supabase migration operator can create the role, grant non-inheriting membership, transfer ownership, or perform later migrations. The disposable target validation described in Phase 2.6 remains mandatory. No SQL was executed and no Supabase project was connected.

## Phase 2.8 superseding H6 correction

The Phase 2.7 follow-on above records the then-proposed `ADMIN FALSE` contract. That contract is superseded for PostgreSQL 17: a non-superuser CREATEROLE creator receives an unmodifiable bootstrap ADMIN membership. Phase 2.8 accepts that ADMIN capability only for the trusted migration operator, requires a second explicit SET-only membership, and forbids API-role membership/ADMIN capability. See `docs/security/phase-2.8-correction-log.md` for the rationale and validation limits. H6 remains open until the actual disposable-project checks pass.
