# Phase 2.6 — Disposable Supabase Validation Runbook

**Purpose:** prepare controlled validation of H6 (migration operator and dedicated RPC role ownership). The companion SQL is a disposable-project test, not a migration. It has not been executed and no Supabase project has been contacted.

**Status:** preparation only. H6 remains unresolved until checks pass using the actual migration operator and intended migration path.

## Identities are not interchangeable

| Context | What its identity proves | What it does not prove |
|---|---|---|
| Dashboard SQL Editor | Usually the SQL Editor's database role (Supabase documents it runs as `postgres`). Record `session_user` and `current_user` from that session. | It does not prove which role applies CLI migrations. |
| Read-only CLI check / `supabase db push --dry-run` | A dry run reports migration state/planned work. It does not execute migration DDL. If a separate read-only SQL probe is made through a CLI connection, record its `session_user` and `current_user` without credentials. | Neither a dry run nor a different read-only connection proves the identity or grants used during an actual migration. A project ref identifies a project, not a database role. |
| Actual migration operator | The database role that executes migration statements through the intended deployment path. It must be identified from that path's configured connection/authentication and verified by a disposable test run. | A local CLI login, Dashboard account, or guessed role name is not proof. |

The hardened SQL pins its expected project ref to `bhnhhaurdnnalcozsviq` and requires the Dashboard-confirmed ref to match. It still cannot inspect the connected Supabase project ref from PostgreSQL; perform the manual checks below. The SQL requires `session_user = current_user = expected_operator` before it changes database objects. Do not run it in SQL Editor unless SQL Editor truly uses the actual migration operator. Do not infer that identity from `supabase db push --dry-run`; a dry run does not test DDL privileges or execute this script.

## Scope and safety boundary

The script tests one dedicated role, one RLS-protected fixture table, one function and one view in each of `public` and `private`, role membership options, temporary schema `CREATE`, ownership transfer, and a later object replacement. It does not apply the full schema or validate all Phase 2 policies. PostgreSQL does not expose a trustworthy project-ref variable to SQL; the pinned expected ref and typed Dashboard confirmation are operator safeguards, not database-side connection attestation.

**Never run this package against production or staging.** Use a newly created disposable Supabase project with no real participant data. Verify the Dashboard project ref immediately before the test. The script requires PostgreSQL 17 or later and intentionally rejects superuser identities. Never place database URLs, passwords, access tokens, API keys, or service-role keys in this repository, SQL, shell history, or reports.

The actual migration operator must have `CREATEROLE` and `CREATE WITH GRANT OPTION` on `public`, and on `private` if it already exists. If `private` is absent, preflight requires database `CREATE` and the script creates it inside the transaction. Running this SQL manually proves only the SQL role and DDL behavior of that connection. If the eventual CLI migration runner applies additional identity transitions or session settings, a later disposable migration through that exact runner is still required before H6 can pass.

## PostgreSQL 17 automatic ADMIN OPTION behavior and chosen design

PostgreSQL 17 automatically grants a non-superuser role creator with `CREATEROLE` membership in a newly created role with `ADMIN TRUE`, `SET FALSE`, and `INHERIT FALSE`. PostgreSQL's catalog can contain multiple grants for one role/member pair when the grantors differ. Here, the automatic row is granted by the bootstrap/platform administrator (Supabase documents `supabase_admin`); the explicit self-grant is recorded under the migration operator. A later `GRANT` updates the row for that grantor, so a grant from the operator does not downgrade the platform-granted row. The creator cannot remove or change that bootstrap row; it can only manage its own separate grant, and effective ADMIN remains.

The selected design accepts the documented automatic `ADMIN TRUE` membership for the single trusted non-superuser CREATEROLE migration operator. It also creates a distinct membership row granted by that operator with `SET TRUE`, `INHERIT FALSE`, and `ADMIN FALSE`. The script requires exactly two grantor-distinct rows: a bootstrap/platform-granted ADMIN row and an operator-granted SET-only row. It verifies effective SET, no inheritance, and the expected operator ADMIN capability. The ADMIN path lets the operator grant or revoke owner-role membership for other roles; that is a real delegation capability and cannot be represented as non-delegable. It is accepted only if the operator and its inherited/SETtable administrative roles are trusted and reviewed. The SQL separately verifies that `authenticator`, `anon`, `authenticated`, and `service_role` have no membership or ADMIN capability in `incux_rpc_owner`.

A separately provisioned owner role with non-admin membership would be preferable only if Supabase provides a supported provisioning path that can create it or control the bootstrap membership. Supabase does not provide ordinary project users unrestricted superuser access, so do not assume that path exists. If the actual operator cannot safely hold the automatic ADMIN authority, stop and redesign around narrower `SECURITY INVOKER`/RLS operations or a trusted server-side boundary. Do not bypass the check or grant API roles.

## Phase 0 — prepare, do not connect yet

1. Confirm in the Dashboard that the project name is `incuxai-hackathon-validation` and the ref is `bhnhhaurdnnalcozsviq`; never reuse production or staging.
2. Independently inspect the local link record (`supabase/.temp/project-ref`) and confirm it contains the same ref. This is only a local-link check; separately re-confirm the project ref in the Dashboard immediately before execution.
3. Confirm PostgreSQL major/minor version and exact intended migration route.
4. Identify the actual migration operator and how the migration route authenticates to PostgreSQL. Record role names and observed identity values only, never credentials.
5. Distinguish SQL Editor identity, any read-only CLI identity, and actual migration operator using the table above. Supabase documents that passwordless CLI access can create a temporary `cli_login_postgres` membership path; do not assume SQL Editor `postgres` is the migration operator.
6. Inspect all roles that the candidate operator inherits from or can `SET ROLE` to, including `supabase_privileged_role` if present. Record their attributes, memberships, and relevant grants. The supplied observation (`postgres` member with `ADMIN FALSE`, `INHERIT TRUE`, `SET TRUE`) describes membership options only; it does not establish the parent role's power. Stop if that chain is not understood and accepted.
7. Confirm the project is disposable and has no `incux_rpc_owner` role, `phase_2_6_validation_*` objects, or conflicting `private` schema objects. If any named object/role exists, stop and use a fresh disposable project.
8. A `db push --dry-run` may inspect migration state only. It is not evidence of the database operator's privileges or a substitute for executing through the intended migration route.

## Phase 1 — set fail-closed confirmations

Only after the actual operator path is known and the project has been confirmed, replace the two placeholders at the top of `scripts/validation/phase-2.6-role-validation.sql`:

- `app.phase_2_6_expected_project_ref` is pinned to the disposable project ref and must not be changed.
- `app.phase_2_6_confirmed_dashboard_ref`: independently re-read the exact same ref from the Dashboard.
- `app.phase_2_6_expected_operator`: exact database role expected for both `session_user` and `current_user`.

The script itself never contains connection credentials. Use the normal secure mechanism of the selected database client. If the migration path uses `SET ROLE` or another identity transition such that session and effective users differ, this version aborts; document that chain and get a separately reviewed validation path rather than bypassing the check.

## Phase 2 — automated SQL checks (not executed)

Run the script as a single transaction/session, and only in the disposable project after independently matching the Dashboard ref. The script performs the following, in order:

1. Validates both confirmed project refs, `current_database()`, PostgreSQL 17+, and exact equality of `session_user`, `current_user`, and the explicitly named actual operator.
2. Requires a non-superuser operator with `CREATEROLE` and `CREATE WITH GRANT OPTION` on `public`; checks fixture names are unused before creating objects.
3. Emits a read-only diagnostic of the operator's direct and transitive role chain. Review its role attributes/grants, especially any role reachable with `INHERIT` or `SET`; stop if an administrative parent role is unexplained.
4. Creates `incux_rpc_owner` with no login, superuser, database/role creation, replication, or RLS bypass capabilities.
5. Creates the `private` schema only if absent (inside the transaction); requires database `CREATE` if creation is needed, or `CREATE WITH GRANT OPTION` if it already exists. It then attempts the explicit constrained membership and checks the two grantor-distinct rows: the automatic ADMIN row and a separate operator-granted `SET TRUE` / `INHERIT FALSE` / `ADMIN FALSE` row. Effective operator ADMIN is expected; all API-role membership and ADMIN paths are rejected.
5. Checks before the first schema grant that the owner lacks `CREATE` on both `public` and `private`; any pre-existing effective privilege is a hard failure.
6. If membership passes, creates a single disposable table and forced-RLS policy, proves `SET ROLE` changed `current_user` while `session_user` remained the operator, inserts one fixture row, and confirms `RESET ROLE` restored the operator.
7. Creates representative function and view fixtures in both `public` and `private`; grants `CREATE` to the owner on both schemas for each ownership-transfer window, transfers ownership, revokes, and immediately asserts that both privileges are gone.
8. Simulates a later migration in both schemas by temporarily granting `CREATE`, switching to the owner, replacing fixture functions/views, resetting role, revoking `CREATE`, then immediately asserting it is gone from both schemas.
9. Removes API-role fixture ACLs. It grants `authenticated` only the public fixture view/RPC. Final assertions verify no API table or column privileges (including INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER, MAINTAIN), the expected public fixture access, no private RPC execution, expected owners, and the intended membership shape.
10. Any failed assertion or SQL statement leaves the transaction aborted; explicitly `ROLLBACK` or close the session. Do not issue `COMMIT` after an error. On success only, COMMIT persists the role, membership, private schema if newly created, and named fixtures for manual API checks.

The expected PostgreSQL 17 membership shape should pass the membership check. Any unexpected shape, missing automatic ADMIN row, missing explicit SET-only row, or API-role membership is a hard failure before ownership-transfer tests. Capture the SQLSTATE and error message without connection details. Do not retry with broader roles/grants.

## Phase 3 — manual Dashboard and PostgREST checks

These checks are not performed by the SQL script and do not establish full application security:

1. Confirm the disposable Dashboard ref remains the confirmed ref.
2. If the SQL transaction committed, inspect the fixture role's attributes and test function/view owners. Confirm the owner cannot log in, is not superuser/CREATEROLE/BYPASSRLS, and has no `CREATE` on `public` after each tested migration window.
3. Confirm `private` is not exposed through PostgREST. Do not add it to exposed schemas for this test.
4. Using only a disposable test identity, check the `authenticated` view/RPC route and confirm only the fixture result is returned.
5. Confirm `anon` cannot read the public view or execute the public RPC; confirm `authenticator`, `anon`, `authenticated`, and `service_role` cannot SELECT or write the base fixture table. Confirm API roles cannot execute the private RPC or read its view, and `private` remains unexposed to PostgREST.
6. Inspect function owners and fixed `search_path` in both schemas. This fixture has no personal data and does not validate the full application RLS matrix.
7. Review Security Advisor warnings and database logs; investigate unexpected warnings rather than suppressing them.

Do not copy API URLs, keys, tokens, or credentials into the repo or report. If SQL Editor cannot represent API roles, use a dashboard API test tool or an approved local test client with credentials held only in local secret storage.

## Phase 4 — record and decide

Record without credentials: PostgreSQL version, private disposable project ref (if useful), migration route, actual operator, observed `session_user`/`current_user`, role option results, owner transfers, later migration simulation, and manual API/RLS results. Keep SQLSTATE/error details free of connection information.

H6 remains **UNRESOLVED** until the actual migration operator passes the role creation/membership-option checks, ownership transfers, subsequent migration, and API/RLS checks. Also verify the operator's inherited and SETtable role chain, including the observed `supabase_privileged_role`, before accepting its ADMIN authority. A dry run, SQL Editor-only test under a different identity, static check, or role-creation success alone is not sufficient.

## Cleanup

**Preferred and complete cleanup:** delete the entire disposable Supabase project from the Dashboard after preserving credential-free results. Re-check the project ref immediately before deletion. This also removes any role membership that may not be revocable by the test operator.

If the membership assertion fails, PostgreSQL aborts the transaction and the role, membership, and fixture DDL are rolled back. Issue `ROLLBACK` in that same session (or close it) and verify no transaction remains open. Do not run fixture cleanup against a failed/aborted transaction.

If the script reaches `COMMIT`, project deletion remains the safest cleanup. A retained-project cleanup must be carried out by a separately authorized database administrator after reconfirming the disposable project and checking each object owner and role-membership grantor. Drop only the exact fixture views, functions, table, policy (dropped with table), role, membership, and fixture ACLs. If `private` did not exist before this run and the script created it, remove it only after the fixture objects and role are gone and only if it is empty; never drop a pre-existing schema. Do not use `CASCADE`, `DROP OWNED`, broad schema cleanup, or guessed role identifiers. The migration operator may not have authority to revoke a bootstrap-granted membership, so do not assume a hand-written `REVOKE`/`DROP ROLE` sequence will succeed. If any privilege/ownership check is uncertain, delete the disposable project instead.

## Abort conditions

Stop before execution if any project-ref, operator, version, object-inventory, or privilege preflight cannot be verified. Stop during execution on any assertion/error; rollback and preserve the failure result. Never grant superuser, `BYPASSRLS`, client/API-role membership, or broad permanent schema privileges to make a check pass. The expected automatic ADMIN row for the trusted creator is accepted; an unexpected membership shape or any API-role membership/ADMIN path is a hard failure.

## References

- PostgreSQL 17 [CREATE ROLE](https://www.postgresql.org/docs/17/sql-createrole.html), [role attributes and CREATEROLE behavior](https://www.postgresql.org/docs/17/role-attributes.html), [GRANT / membership options](https://www.postgresql.org/docs/17/sql-grant.html), [role inquiry functions](https://www.postgresql.org/docs/17/functions-info.html), [ALTER FUNCTION](https://www.postgresql.org/docs/17/sql-alterfunction.html), and [ALTER VIEW](https://www.postgresql.org/docs/17/sql-alterview.html).
- Supabase [Postgres roles](https://supabase.com/docs/guides/database/postgres/roles), [managing environments and custom-role migration caveat](https://supabase.com/docs/guides/deployment/managing-environments), and [Security Advisors](https://supabase.com/docs/guides/observability/advisors).
