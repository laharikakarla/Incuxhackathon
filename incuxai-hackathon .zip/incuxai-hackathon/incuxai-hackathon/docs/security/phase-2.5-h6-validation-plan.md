# Phase 2.5 — H6 Migration Operator and RPC Role Validation Plan

**Scope:** H6 only. This plan distinguishes PostgreSQL's documented capabilities from unverified Supabase project behavior. No SQL was run and no project was accessed. H6 remains unresolved until the actual migration operator passes the disposable-project validation.

## H6 in the proposed design

The schema draft creates `incux_rpc_owner` as a non-login, non-superuser, `NOBYPASSRLS` role; grants selected underlying object privileges; transfers selected views and functions to it; and removes temporary schema `CREATE`. The migration operator must be able to assume the owner role for transfers and later migrations, without giving client/API roles that ability.

Relevant source files are `docs/database/phase-2-schema-draft.sql`, `docs/database/phase-2-architecture.md`, `docs/security/phase-2-rls-matrix.md`, the Phase 2.3 review, and the Phase 2.4 correction log. The Phase 2.6 SQL/runbook are a diagnostic package only, not a migration.

## 1. Required PostgreSQL capabilities

| Operation | Required capability |
|---|---|
| Create dedicated owner | `CREATEROLE` (or superuser, which the managed-role test intentionally rejects). The new role must remain `NOLOGIN`, `NOSUPERUSER`, `NOCREATEDB`, `NOCREATEROLE`, `NOREPLICATION`, and `NOBYPASSRLS`. |
| Create `private` if absent | Database `CREATE`; creating in an existing schema requires schema `CREATE`. |
| Grant underlying table/sequence privileges | Ownership or the corresponding grant options for the migration operator; only privileges required by the specific functions/views should be given to the owner. |
| Transfer function/view ownership | The operator must own/alter the object, be able to `SET ROLE` to the new owner, and the new owner must have `CREATE` on the object's schema at transfer time. |
| Modify custom-owned objects in later migrations | The actual future migration identity must own the object or be able to assume its owner role with the required `SET` option. This must be tested through the intended deployment path. |

The Phase 2.6 validation script checks both `session_user` and `current_user`; it requires them to be the same named actual migration operator at entry, then checks `current_user` transitions on `SET ROLE` and resets while `session_user` remains unchanged. If the real migration path uses a different identity chain, stop and document it rather than bypassing the guard.

## 2. Distinguish connection identities

- **Dashboard SQL Editor identity:** Supabase documents SQL Editor queries run as `postgres`. That proves only what that SQL Editor session can do.
- **Read-only CLI identity:** `supabase db push --dry-run` reports migration state/planned work and does not execute migration SQL. If a separate CLI-based read-only SQL probe is used, record its `session_user` and `current_user`; neither proves the identity used for an actual migration unless the same connection/authentication path is used.
- **Actual migration operator:** the PostgreSQL role that executes migration statements via the intended deployment route. Determine it from the configured route and verify it in a disposable test execution. Do not infer it from the user's Dashboard login, local CLI account, project ref, or dry-run output.

The SQL Editor and CLI may use different routes and identities. The validation SQL is valid evidence for H6 only when it is executed as the same actual operator intended to apply migrations. The script intentionally aborts if `session_user`, `current_user`, and the explicitly configured operator do not match.

## 3. PostgreSQL 17 automatic membership and selected model

PostgreSQL 17 documents that a non-superuser with `CREATEROLE` who creates a role automatically receives membership in that new role with `ADMIN TRUE`, `SET FALSE`, and `INHERIT FALSE`. The auto-grant is recorded under the bootstrap/platform grantor. PostgreSQL 16+ permits multiple catalog grants for one role/member pair when grantors differ. The later self-grant is recorded under the operator, so its `SET TRUE`, `INHERIT FALSE`, `ADMIN FALSE` options form a second row; a GRANT from the same grantor updates that grantor's existing row. The creator cannot change or remove the bootstrap-granted row, so effective ADMIN remains true.

The selected design accepts PostgreSQL 17's automatic ADMIN membership for the trusted migration operator. The explicit operator grant is a second row because its grantor differs from the bootstrap/platform grantor. This ADMIN path lets the operator grant owner membership to another role and is not non-delegable. It is acceptable only if the migration operator and all privileges it inherits or can reach with `SET ROLE` are reviewed and trusted, and if it is not an application/API identity. Catalog checks must verify `authenticator`, `anon`, `authenticated`, and `service_role` have no membership or ADMIN option in `incux_rpc_owner`. The observed disposable project reports `postgres` as a member of `supabase_privileged_role` with `ADMIN FALSE`, `INHERIT TRUE`, and `SET TRUE`; this proves membership options only, not what privileges that role confers. Inspect that role's attributes and grants before accepting `postgres` as a migration operator. Every membership change must be reviewed/audited. The owner role itself remains `NOLOGIN`, `NOINHERIT`, and `NOBYPASSRLS`.

A separately provisioned owner role with `ADMIN FALSE` for the migration operator would reduce delegation risk only if a superuser or Supabase-supported provisioning mechanism can create the owner role and establish the membership. Supabase does not give ordinary project users unrestricted superuser access, so do not assume this path is available. If the deployment operator cannot be trusted with automatic ADMIN, use a separately reviewed `SECURITY INVOKER`/RLS or server-side operation model instead. Do not weaken API isolation or substitute `service_role` as owner.

## 4. Supabase compatibility assessment

PostgreSQL supports role membership options, ownership changes, fixed `search_path`, `SECURITY DEFINER`, forced RLS, and catalog inspection. Supabase documents custom roles and migration problems with objects owned by custom roles. Those facts make the design plausible, not validated. Project-specific role attributes, hosted protections, migration connection behavior, and object ownership must still be tested.

The actual `postgres` role capabilities cannot be assumed from its name. Record `rolsuper`, `rolcreaterole`, database/schema privileges, and membership options in the disposable project. A `db push --dry-run` that says the database is up to date is only migration-state information: it provides no evidence that a subsequent migration can create roles or alter custom-owned objects.

## 5. Disposable-project validation sequence

Use `docs/security/phase-2.6-validation-runbook.md` and `scripts/validation/phase-2.6-role-validation.sql`. The script is marked NOT EXECUTED and is not a migration.

1. Create a fresh disposable project with no real participant data and confirm its project ref in the Dashboard.
2. Identify the actual migration route and database operator. Keep SQL Editor identity, any read-only CLI identity, and migration operator observations distinct; never record credentials. Supabase documents a possible temporary `cli_login_postgres` membership path for passwordless CLI use, so determine actual `session_user` and `current_user` during the migration route.
3. Confirm target PostgreSQL is 17+ and inspect operator role attributes, all inherited/SETtable memberships (including `supabase_privileged_role` if present), and required `CREATEROLE` / schema-grant capabilities. The observed parent membership options do not reveal that role's privileges.
4. Configure the script's disposable project confirmations and actual operator name. Run only if both `session_user` and `current_user` match that operator.
5. The script creates `private` only if absent, creates the owner, then verifies the expected automatic ADMIN row and explicit non-admin SET row. Effective operator ADMIN is expected; API role membership/admin is forbidden.
6. It creates named fixture objects in `public` and `private`. It checks pre-grant `CREATE` is absent on both schemas, performs each schema grant/ownership transfer/revoke in both, and aborts if post-revoke `CREATE` remains.
7. It switches to the owner for subsequent function/view replacement in both schemas, resets to the operator, and again asserts schema `CREATE` is revoked. Final checks include all table/column privileges and expected fixture API ACLs before commit.
8. If it commits, manually inspect the disposable PostgREST/RLS behavior described in the runbook, then delete the disposable project. If transaction fails, rollback and confirm it left no test objects.
9. Record exact PostgreSQL version, migration route, operator role, `session_user`, `current_user`, role options, transfer outcomes, later migration result, and manual API checks, without secrets.

Never broaden privileges to force the test through. Never run the package on production or staging. If the actual migration identity chain differs from the script's strict equality requirement, obtain a separately reviewed validation path rather than editing out the identity check.

## 6. Safe fallback if the ownership model is unsupported

Do not replace the RPC owner with `service_role` or assume `postgres` is an equivalent low-privilege owner. Prefer `SECURITY INVOKER` operations with narrow grants and RLS. Move operations that require trusted authority to server-side functions with current database-backed permission checks and secrets held only server-side. Retain a `SECURITY DEFINER` RPC only if its owner, grants, fixed search path, RLS behavior, and migration ownership are demonstrated safe in the target environment. Any alternative requires a new design review.

## Required manual checks and H6 status

Still required: (1) confirm the Dashboard ref is `bhnhhaurdnnalcozsviq` and the local link record agrees; (2) establish the actual migration path and operator; (3) record SQL Editor/read-only CLI identities separately; (4) execute through the actual operator and verify both session/effective identities; (5) inspect CREATEROLE and schema grant capabilities; (6) verify the automatic ADMIN and explicit SET membership rows plus API exclusion; (7) test public and private ownership transfer/revocation; (8) test a later migration through the intended runner; (9) manually verify PostgREST/RLS behavior and every direct table privilege; and (10) delete the disposable project after recording credential-free results.

**H6 status: UNRESOLVED pending controlled validation.** The design no longer requires impossible ADMIN FALSE for the creator. Static review confirms the documented PostgreSQL 17 behavior and specifies the accepted elevated operator path, but cannot show that Supabase permits the required role creation/SET grant or that the deployment operator and subsequent migrations behave as expected. Only execution through the intended operator in the named disposable project can establish those facts.

## References

- PostgreSQL 17 [CREATE ROLE](https://www.postgresql.org/docs/17/sql-createrole.html), [role attributes and CREATEROLE behavior](https://www.postgresql.org/docs/17/role-attributes.html), [GRANT / membership](https://www.postgresql.org/docs/17/sql-grant.html), [role inquiry functions](https://www.postgresql.org/docs/17/functions-info.html), [ALTER FUNCTION](https://www.postgresql.org/docs/17/sql-alterfunction.html), and [ALTER VIEW](https://www.postgresql.org/docs/17/sql-alterview.html).
- Supabase [Postgres roles](https://supabase.com/docs/guides/database/postgres/roles), [managing environments](https://supabase.com/docs/guides/deployment/managing-environments), and [Security Advisors](https://supabase.com/docs/guides/observability/advisors).
