# Phase 2.14 — Read-Only Disposable Supabase Preflight

**Date:** 2026-11-13  
**Scope:** Read-only preflight for the approved disposable project only.  
**Decision:** **NO-GO — do not request or run the Phase 2.15 migration identity probe yet.**

## Safety statement

The only explicitly targeted project reference was `bhnhhaurdnnalcozsviq` (`incuxai-hackathon-validation`). No SQL statement reached the database: the CLI rejected both remote commands because this CLI session had no Supabase access token. No migration, role change, grant, revoke, DDL, or Phase 2.6 script was run. The production project `incuxai-hackathon` was not targeted.

The request's stated architecture and Phase 2.13 plans were not all present as repository files. The available local material and previous results supplied in the conversation were used as historical context; they are not represented as newly verified facts.

## Commands and checks performed

### Repository and configuration inspection

Commands/checks:

- Enumerated repository `AGENTS.md` files: none found.
- Enumerated `docs/`: Phase 2.12, Phase 2.13, Phase 2.13.1, and Phase 2.14 documents were absent before this report was created. Available relevant files included the Phase 2 database architecture/schema, Phase 2 security documents, Phase 2.6 runbook/SQL, and Phase 2.8.1 membership review.
- Inspected `package.json` scripts without reading environment values. Scripts are `dev`, `build`, `preview`, `lint`, and `typecheck`; there is no migration script and no Supabase CLI package dependency.
- Checked `supabase/migrations`: directory absent; no local migration files were found.
- Checked `README.md` for migration command instructions: none found.
- Read only the local `project_id` field from `supabase/config.toml`: `incuxai-hackathon`. Other configuration values were not printed.
- Checked tracked `.env`-like filenames with `git ls-files`: none found.
- Read the local Supabase project reference cache and the linked-project metadata reference only; did not read pooler URLs or credential files.
- Inspected the saved `section5-membership-output.csv` role-membership evidence and Phase 2.6 object labels. The Phase 2.6 SQL remains the old `incux_rpc_owner` validation, not the Phase 2.12 domain-owner architecture.

### CLI version

Command used in PowerShell, with CLI telemetry disabled for this process and no package installation:

```powershell
$env:SUPABASE_TELEMETRY_DISABLED = '1'
$env:SUPABASE_DISABLE_TELEMETRY = '1'
npx --no-install supabase --version
```

Result: `3.1.0`.

The first version invocation attempted a telemetry-cache write outside the workspace and was blocked by filesystem permissions. Re-running with telemetry disabled succeeded. No repository file was changed by this.

### Explicit target resolution and database identity query

The reference below was supplied explicitly; the command did not rely on the linked-project default:

```powershell
$target = 'bhnhhaurdnnalcozsviq'
$sql = "SELECT current_database() AS database_name, current_user AS current_user, session_user AS session_user, current_setting('server_version') AS server_version;"
npx --no-install supabase db query --remote=$target --read-only $sql
```

Sanitized CLI output:

```text
Target: project incuxai-hackathon-validation (bhnhhaurdnnalcozsviq) · production
Error: DbQueryLoginRequiredError — Access token not provided.
```

The CLI resolved the explicit target to the named disposable project. It then stopped before executing the SQL because this CLI session had no access token. The CLI's `production` environment label is recorded as displayed; it does not change the explicit project reference, but the label should be reconfirmed in the Dashboard immediately before any future mutation.

### Remote migration history

Command:

```powershell
npx --no-install supabase migration list --remote=bhnhhaurdnnalcozsviq
```

Result: `AccessTokenRequiredError — Access token not provided.` Remote migration history was **not** read. The command was read-only; no migration was applied.

### Credential-safe environment check

Checked only whether process environment variable **names** matching `SUPABASE_ACCESS_TOKEN`, `SUPABASE_DB_PASSWORD`, `SUPABASE_DB_URL`, or `SUPABASE_PROJECT_REF` existed. No matching names were present. No values were read or printed. The CLI error independently confirms that the current CLI invocation could not obtain an access token.

## Findings by requirement

| Check | Result | Evidence / limitation |
|---|---|---|
| 1. Active linked project reference | **PARTIAL PASS** | Local link cache and CLI target resolution both identify `bhnhhaurdnnalcozsviq` / `incuxai-hackathon-validation`. The CLI's environment label says `production`; confirm the target in the Dashboard again before any mutation. All commands here explicitly supplied the disposable ref. |
| 2. Supabase CLI version | **PASS** | `npx --no-install supabase --version` → `3.1.0`. |
| 3. Intended migration command and credential route | **UNKNOWN** | No migration command appears in `package.json` or `README.md`; no migration directory exists. CLI help shows `db push` accepts a database password option, while remote queries also require CLI access-token authorization. No intended deployment command or credential route is configured/documented locally. No credential values were accessed. |
| 4. Migration files and remote history | **PARTIAL** | No local `supabase/migrations` directory. Remote `migration list` failed before reading history because CLI access-token authentication was unavailable. |
| 5. Current PostgreSQL version | **NOT REFRESHED** | Remote identity/version query did not execute. Local `.temp/postgres-version` cache says `17.11.0.019`; previous supplied live result was PostgreSQL 17.11. These are historical/cache evidence, not a current read-only database result. |
| 6. Role attributes and complete memberships | **NOT REFRESHED** | Requires a remote database read. CLI auth failure prevented querying current role catalog. Previous report/CSV remains historical evidence only. |
| 7. Schema privileges and effective permissions | **NOT REFRESHED** | Requires remote catalog and privilege queries. Previous results cannot establish current grants. |
| 8. Validation-name collisions | **NOT REFRESHED** | Remote object inventory did not run. Previous results said six Phase 2.6 collisions were false, but no fresh Phase 2.13 canonical fixture-name inventory is defined in repository files. |
| 9. Known vs unknown identities | **PARTIAL** | Query identity is unknown in this attempt because no SQL ran. Historical preflight reported `supabase_read_only_user` for both `session_user` and `current_user`; that is not evidence of migration identity. Migration `session_user`, `current_user`, created-object owner, and subsequent-migration identity remain unknown. |
| 10. Change from previous preflight | **PARTIAL** | Target ref and CLI version match prior evidence. Current CLI auth is unavailable, unlike the prior reported successful query session. Database roles, grants, version, history, and object collisions cannot be compared freshly. |

## Comparison with previous results

Previous disposable-project results supplied in the conversation reported:

- Project `incuxai-hackathon-validation`, reference `bhnhhaurdnnalcozsviq`.
- Supabase CLI `3.1.0`; PostgreSQL `17.11`.
- The earlier read-only query connection had `session_user = current_user = supabase_read_only_user`.
- `postgres` was reported non-superuser with `CREATEROLE` and `CREATEDB`; database owner was `postgres`, with database `CREATE` available.
- `postgres` had effective `public CREATE` and `CREATE WITH GRANT OPTION`; `private` was absent at that time.
- The six Phase 2.6 fixture collision checks were reported false; `incux_rpc_owner` was absent at that time.
- API roles were reported without superuser/CREATEROLE attributes and without membership in the then-proposed owner role.
- The saved membership CSV records direct memberships of `postgres` granted by `supabase_admin`, including ADMIN-enabled membership to API roles and `supabase_privileged_role` membership with ADMIN false, INHERIT true, SET true. It also records transitive authenticator and `pg_monitor` memberships.

This preflight **did not refresh any of those database facts**. The exact target reference still matches the approved disposable reference in local cache and CLI target resolution. The current process has no Supabase CLI access token, preventing remote reads. The local `supabase/config.toml` project id reads `incuxai-hackathon`, which differs from the disposable project name; all remote commands therefore explicitly pinned the disposable reference. Do not use an implicit linked target for future operations until this configuration difference is understood.

## Confirmed facts versus unknowns

### Confirmed in this run

- CLI version is 3.1.0.
- Local Supabase link cache contains the approved disposable project reference.
- An explicitly targeted CLI command resolved to the expected disposable project name and reference.
- This CLI invocation lacked access-token authentication and did not execute the identity/version SQL.
- The remote migration history was not read.
- No local migration directory or documented migration command was found.
- No tracked `.env`-like filenames were found; no secret values were read or printed.
- No database mutation or migration identity probe was performed.

### Still unknown

- Current PostgreSQL version and current database identity.
- Current role flags, all direct/transitive memberships and grantors/options.
- Current schema/database ACLs and effective privileges.
- Current existence of proposed roles or validation objects.
- Remote migration history.
- Intended migration command, credential route, and actual migration operator.
- `session_user`, `current_user`, and owner of objects created by the actual migration runner.
- Whether a later migration can replace domain-owned functions with only a narrow temporary privilege path.

## Discrepancies and blockers

1. **CLI authentication blocker:** remote read-only checks failed because the current Supabase CLI session has no access token. Do not work around this by printing, copying, or placing credentials in the repository or shell history. An authorized operator must establish the approved CLI session outside this report, then repeat only the missing read-only checks with the explicit disposable reference.
2. **Project configuration mismatch:** local `supabase/config.toml` identifies `incuxai-hackathon`, while the disposable reference is `bhnhhaurdnnalcozsviq`. The explicit CLI reference resolved correctly in this run, and no production target was queried. Keep explicit project targeting mandatory and confirm the Dashboard project name/reference before further remote commands.
3. **Architecture/plan files absent:** Phase 2.12, Phase 2.13, and Phase 2.13.1 specifications are not in the repository. Their agreed direction was taken from conversation context; the accepted architecture is not independently reconciled against a local canonical document.
4. **No canonical Phase 2.13 fixture names:** the only local validation script is Phase 2.6, which creates `incux_rpc_owner` and `phase_2_6_validation_*` objects. It is not compatible with the Phase 2.12 domain-owner architecture and was not executed. Define and review Phase 2.13 probe object names before collision checks.
5. **Credential route and migration identity:** no migration deployment command is documented. CLI auth identity, database login identity, `session_user`, `current_user`, created-object owner, and later-migration identity must remain distinct until a separately approved disposable migration probe observes them.

## Future read-only steps

After an authorized operator restores the intended CLI read access, repeat these checks with the reference spelled out in every remote command:

1. Database identity and server version via `supabase db query --remote=bhnhhaurdnnalcozsviq --read-only`.
2. Role attributes and complete direct/transitive role membership graph, including grantors and ADMIN/INHERIT/SET options.
3. Database and schema ACLs, grant options, and effective privileges for the migration operator, API roles, existing platform roles, and reviewed test-role names.
4. Exact collision checks for the approved Phase 2.13 fixture names.
5. Remote migration history via `supabase migration list --remote=bhnhhaurdnnalcozsviq`.
6. Reconcile all new evidence with previous reports and record only sanitized outputs.

These read-only checks do not prove the actual migration identity. The Phase 2.15 probe remains a separate database mutation requiring explicit approval.

## Final recommendation

**NO-GO — do not request approval for the Phase 2.15 migration identity probe yet.** First resolve CLI read-only authentication and repeat the missing database preflight against the explicit disposable reference. Document the intended migration command and credential route, reconcile the local project-id mismatch, define canonical probe object names, and confirm the target again in the Dashboard. Only then should the operator review a concrete Phase 2.15 probe for explicit approval.

---

## Phase 2.14.1 — Read-only retry addendum

**Date:** 2026-11-13  
**Scope:** Retry the missing Phase 2.14 checks only.  
**Result:** Target verified; remote SQL authentication still unavailable. No database state was changed.

### Target verification

The local reference cache still contains `bhnhhaurdnnalcozsviq`. The first database command explicitly selected that reference, and the CLI resolved it as:

```text
Target: project incuxai-hackathon-validation (bhnhhaurdnnalcozsviq) · production
```

The project name and reference matched the permitted disposable target. No command used the linked-project default or the production project reference. The CLI's `production` environment label remains noted as a label for this explicitly selected target; the project name and reference are the target verification evidence.

### Retry performed

PowerShell command, with no package installation and process telemetry disabled:

```powershell
$env:SUPABASE_TELEMETRY_DISABLED = '1'
$env:SUPABASE_DISABLE_TELEMETRY = '1'
$target = 'bhnhhaurdnnalcozsviq'
$sql = "SELECT current_database() AS database_name, current_user AS current_user, session_user AS session_user, current_setting('server_version') AS server_version;"
npx --no-install supabase db query --remote=$target --read-only $sql
```

Sanitized result:

```text
Target: project incuxai-hackathon-validation (bhnhhaurdnnalcozsviq) · production
Error: DbQueryLoginRequiredError — Access token not provided.
```

The SQL did not execute. The operator's statement that local CLI authentication was restored is not borne out by this command invocation: this process did not have usable Supabase CLI access-token authentication. No secret values were inspected or printed. Because the first required live database query failed before execution, I stopped rather than attempting further remote queries.

### Checks completed in this retry

| Check | Result | Evidence |
|---|---|---|
| Explicit disposable target | **PASS** | CLI resolved the provided reference to `incuxai-hackathon-validation` and the exact approved reference. |
| PostgreSQL version and database identity | **NOT RUN** | Identity/version query was rejected before SQL execution. |
| Role attributes and complete membership graph | **NOT RUN** | No authenticated database query was possible. |
| Membership grantors and ADMIN/INHERIT/SET options | **NOT RUN** | No authenticated database query was possible. |
| Schema/database grants and effective privileges | **NOT RUN** | No authenticated database query was possible. |
| Phase 2.13 fixture-name collision checks | **NOT RUN** | No canonical Phase 2.13 fixture names exist in the repository, and no authenticated database query was possible. |
| Remote migration history | **NOT RUN** | Not retried after authentication failed at the initial database query; the previous Phase 2.14 attempt also received `AccessTokenRequiredError`. |
| Migration command and credential route | **UNRESOLVED** | Repository still contains no documented migration command or migration directory. The intended route cannot be inferred from CLI login state. |

### Comparison and decision update

The target name/reference remain consistent with the earlier preflight and the saved local link metadata. The current remote database facts remain unrefreshed. Prior reported PostgreSQL 17.11, `supabase_read_only_user` query identity, role memberships, grants, and collision results are still historical evidence only. The migration identity remains unknown; successful CLI login would not establish it even if login were available.

**Final recommendation remains NO-GO — do not request approval for the Phase 2.15 migration identity probe yet.** First make the intended CLI authentication available to the same PowerShell process executing the explicitly targeted read-only command, then rerun the database identity/version query. Only after it succeeds should the remaining diagnostics and migration-history listing run, each with the explicit disposable project reference. No Phase 2.15 probe, DDL, migration, or other database mutation is authorized by this report.
