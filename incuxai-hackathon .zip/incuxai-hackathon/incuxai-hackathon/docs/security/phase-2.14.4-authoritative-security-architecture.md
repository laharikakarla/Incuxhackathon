# Phase 2.14.4 — Authoritative Security Architecture (Consolidated Working Specification)

**Status:** Design baseline only. **Database implementation readiness: NO-GO. Migration identity probe: NOT AUTHORIZED.**  
**Scope:** Reconciles surviving Phase 2 documents with architecture decisions supplied and accepted in the project conversation. This is static analysis; no SQL was executed and no Supabase project was contacted.

> **Evidence boundary:** The approved Phase 2.12, 2.13, and 2.13.1 source specifications and the historical 79-function/30-view classification report are absent from this checkout and Git history. This document preserves the decisions evidenced by the later review/design sequence, but its operation/view/helper matrices are a proposed reconstruction from the current SQL draft. They must not be represented as verbatim approved historical classifications. Decision provenance and uncertainty are in the [decision register](phase-2.14.4-decision-register.md); contradictions in the [implementation conflict inventory](phase-2.14.4-implementation-conflict-inventory.md).

## 1. Decision hierarchy and readiness

The accepted direction is hybrid RLS plus narrowly scoped database operations. A verified user's identity comes from the signed JWT and `auth.uid()`; caller-supplied user IDs never prove identity. Prefer SECURITY INVOKER and RLS for user-scoped operations. Use narrow SECURITY DEFINER transaction functions only where atomic invariants require a controlled privilege boundary. System work uses distinct custom LOGIN identities only after hosted-project feasibility is proven. Payment webhooks/refunds run in an independently controlled runtime. No universal `incux_rpc_owner`, routine application use of `service_role`, or trust in mutable JWT metadata, ordinary actor parameters, or caller-controlled GUCs.

The database design remains **NO-GO for detailed implementation** until the exact role/membership/ownership lifecycle, real migration execution identity, subsequent replacement of domain-owned functions, trigger audit identity, runtime login/pooler behavior, and per-operation grants have a defensible and disposable-project-validated design. The Phase 2.14.2 CLI migration route is a candidate only; a dry run or documented CLI feature does not establish the hosted database identity or privilege path.

### Source hierarchy

1. User-approved direction captured in the project conversation and later Phase 2.14.2 workflow decisions.
2. Surviving corrected Phase 2 design and security docs, where consistent with that direction.
3. Current SQL draft as evidence of existing proposed objects and legacy behavior, **not** as authority where it conflicts.
4. Phase 2.14.3 recovery review, this decision register, and conflict inventory for missing evidence and unresolved points.

When sources disagree, the disagreement remains open until explicit decision and evidence; this document does not silently resolve business values.

## 2. Trust boundaries and data execution

```text
Browser -- signed user JWT --> PostgREST / authenticated SQL entry
                                  | auth.uid(); RLS; invoker-first
                                  | narrow domain transaction only when needed
Independent payment runtime -- verified provider webhook --> payment runtime identity
Other isolated workers -- authenticated system job --> domain-specific system identity
                                  |
                     PostgreSQL transaction + trigger audit + outbox
                                  |
                  Outbox dispatcher --> external provider (after commit)
```

No network call occurs while a business row lock is held. A payment provider callback is verified cryptographically by the payment runtime over the exact raw request body, checked for timestamp/replay and provider event ID, then submitted with the verified event bytes/digest and event identifier. PostgreSQL independently checks order linkage, expected INR amount/currency, transaction state, uniqueness/idempotency, valid transition, and refund ceiling within a transaction. A boolean such as “signature verified”, ordinary actor ID, or GUC is not proof of webhook identity. The exact database authentication mechanism for system/webhook identities remains unvalidated.

### Roles and permissions — required target shape, not hosted-project proof

| Identity class | Attributes and memberships | Intended access | Prohibited |
|---|---|---|---|
| `anon` | Platform role; no privileged membership | Only explicitly public safe projections/verifier endpoint | Private schemas, sensitive tables, internal functions |
| `authenticated` | JWT-bound user; no CREATEROLE/BYPASSRLS | Narrow user functions and safe invoker views; RLS scopes rows | Role/permission mutation, payment finalization, audit writes, judge/admin data outside authorization |
| `service_role` | Treat as highly privileged platform credential | No routine app transaction role; only platform operations if unavoidable | Broad table/function grant as application backend |
| Domain function owners (proposed) | NOLOGIN, NOSUPERUSER, NOCREATEROLE, NOCREATEDB, NOBYPASSRLS; no memberships | Own only functions in one security domain; exact table/column privileges; no schema/table ownership | Login, cross-domain membership, unrestricted schema CREATE, user API reachability |
| System runtime identities (proposed individually) | LOGIN only if disposable validation proves route; NOSUPERUSER, NOCREATEROLE, NOCREATEDB, NOBYPASSRLS; no SET ROLE path | EXECUTE only on named private domain transaction functions; no direct table access | Owner-role membership, broad function execution, direct sensitive DML |
| Migration operator | Actual identity unknown | Temporary, auditable, narrowly scoped deployment authority if feasible | Permanent broad owner/admin membership |
| Audit writer owner (proposed) | NOLOGIN, no table/schema ownership; trigger-only EXECUTE path | Append-only audit INSERT through triggers/functions | API EXECUTE, arbitrary caller-selected actor/event |

Exact role names, attributes, schema/table/column grants, role membership, and operator grantor path require validation. Domain owner names should be assigned only after one-owner-per-function-domain mapping and dependency review. A compromised definer can exercise all its effective grants; a nested definer expands that authority to the union of reachable privileges. Therefore nested EXECUTE edges must be explicitly inventoried, schema objects qualified, fixed search_path minimal, and owner memberships empty. FORCE ROW LEVEL SECURITY is not a substitute for least privilege and does not neutralize superuser/BYPASSRLS or a permissive policy granted to the owner.

### Identity and audit

- **User:** validate JWT at the database API boundary; use `auth.uid()` and current authorization state. The actor is derived, not passed as evidence.
- **System:** authenticate a distinct runtime login/credential and map it to a fixed system actor type/name. No browser identity or caller-selected actor.
- **Webhook:** independent payment runtime verifies provider signature/replay before calling the payment transaction; database checks event ID/digest, order, amount/currency and legal transition. The transaction is authenticated as the payment worker, not by a boolean claim.
- **Audit:** append-only business event rows are written by trusted triggers in the same transaction as the state change. API identities receive no INSERT/UPDATE/DELETE on the audit table. Business operations must not separately insert duplicate audit rows where a state trigger already records the transition. Operational logs (worker attempts, errors, provider latency) are separate from canonical business audit.
- **Required event fields (proposed):** event UUID, event type, entity type/ID, actor type, actor user ID nullable, fixed system identity nullable, request/correlation ID, previous/new state where applicable, reason where required, occurred-at, minimal nonsecret metadata. Do not copy credentials, full provider payloads, or unnecessary personal data.
- Preserve append-only score-edit history, including draft changes; team discussion message body is not copied to audit, but edits/deletion/moderation/emergency access produce metadata-only events. Audit atomicity depends on trigger transaction and must be tested. External immutable retention is a later operational control, not a substitute for database append-only grants.

### Outbox and payment

Write outbox intent in the same transaction as the business state. A worker leases/claims with bounded locking, performs external calls only after commit, records retry/idempotency outcomes, and tolerates crashes. Provider event ID uniqueness, payment order uniqueness, transaction/order composite keys, fee-version snapshots, INR amount equality, paid-team duplicate-pending prevention, verified-success transaction requirement, refund transaction/order linkage, serialized cumulative refund cap, receipt-after-paid rule, and immutable paid financial history remain mandatory. Changes to fee configuration create immutable versions; existing orders retain snapshot and expire after the adopted 24-hour default unless product decision changes it.

## 3. Operation-by-operation matrix: 79 public functions

**Legend:** U = user JWT; S = authenticated system worker; W = independently authenticated payment webhook/runtime; P = safe public projection through constrained verifier; I = SECURITY INVOKER + RLS; D = narrow domain SECURITY DEFINER transaction; E = Edge orchestration. Table names are relations visible in the current draft. “Audit: trigger” means canonical event belongs to triggers, not an RPC-authored audit row. Exact column read/write sets, nested calls, signatures of dependencies, and ACLs must be derived before implementation; this matrix is a proposed security disposition, not an ACL manifest.

| # / function (current signature) | Proposed caller / execution; owner domain | Data touched and invariant/audit/locking | Decision and open point |
|---:|---|---|---|
| 1 `team_create(text,text,text,uuid[])` | U; D team | teams, memberships, policy version, skills; one active team/member, capacity, exactly one leader; audit trigger; serialize membership/capacity | Atomic D; caller is leader from auth.uid(); verify skills cannot leak private profile |
| 2 `team_join(uuid)` | U; D team | memberships, team, size policy, payment orders; unique active membership and locked/paid roster; audit; lock team | D; join eligibility and payment interaction |
| 3 `team_request_join(uuid,text)` | U; I if self-row insert is sufficient | requests, team, memberships; one active request and no existing active team; audit | Prefer I with RLS/unique constraint; validate cross-team uniqueness |
| 4 `team_decide_join_request(uuid,bool,text)` | U leader; D team | request, membership, team, policy, orders; capacity/one-team/roster; audit; lock team/request | D; leader authorization rechecked under lock |
| 5 `team_invite_member(uuid,uuid)` | U leader; D team | invitation, team, membership, orders; active invitation uniqueness, capacity; audit | D; target is invitee, never actor |
| 6 `team_accept_invitation(uuid)` | U invitee; D team | invitation, membership, team, policy, orders; invitee auth.uid, one-team/capacity; audit + locks | D; consume invite atomically |
| 7 `team_respond_invitation(uuid,bool)` | U; D compatibility wrapper | invitation; likely alias of accept/reject; audit only once | Preserve until callers and exact behavior reconciled; possible alias |
| 8 `team_revoke_invitation(uuid,text)` | U leader; D team | invitation, order/roster state; only pending invitation; audit | D; lock team and invitation |
| 9 `team_withdraw_join_request(uuid,text)` | U requester; I or D team | own request; pending transition only; audit | I if row-local policy/transition sufficient |
| 10 `team_expire_pending_workflows()` | S scheduler; D team | expired invitations/requests/orders; deterministic state transitions; audit; bounded batches/locks | System identity required; scheduler route unknown |
| 11 `team_remove_member(uuid,uuid,text)` | U leader/admin; D team | membership, team, orders; leader/capacity/payment roster rules; audit + team lock | D; post-payment exception path explicit |
| 12 `team_transfer_leader(uuid,uuid,text)` | U current leader/admin; D team | memberships/team/orders; exactly one active leader; audit; lock team | D; prevent transfer after payment absent approved exception |
| 13 `team_dissolve(uuid,text)` | U leader/admin; D team | team, memberships, orders; valid lifecycle/financial preservation; audit + locks | D; paid team cannot erase financial history |
| 14 `team_lock_roster(uuid,bool,text)` | U authorized admin/team flow; D team | team/order; payment initiation and terminal fail unlock; audit | D; actor permission and payment state must be checked |
| 15 `team_post_payment_exception(uuid,text,uuid,text)` | U Super Admin only; D team/payment | team, membership, payment/order, approval/audit; preserve original financial facts | Rebuild from corrected design; current draft implementation was identified broken |
| 16 `team_policy_set(smallint,smallint,timestamptz,text)` | U authorized admin; D team | immutable policy versions; check min/max/effective interval; audit | D; product limits unresolved |
| 17 `admin_grant_role(uuid,app_role,text)` | U Super Admin/authorized admin; D identity | role grants; last Super Admin invariant; audit + serialize role changes | D; actor from auth.uid; target is explicit |
| 18 `admin_revoke_role(uuid,text)` | U authorized admin; D identity | role grants; last Super Admin protection; audit + lock/serializable check | D |
| 19 `admin_grant_permission(uuid,text,text)` | U authorized admin; D identity | permission grants; scope/valid permission; audit | D; permission catalog and delegation rules |
| 20 `admin_revoke_permission(uuid,text)` | U authorized admin; D identity | permission grants; preserve last-admin controls; audit | D |
| 21 `admin_grant_recruiter_access(uuid,text,text)` | U authorized admin; D recruiter | recruiter access grants/workspace if any; audit | D; workspace model unresolved; participant consent remains separately required |
| 22 `admin_revoke_recruiter_access(uuid,text)` | U authorized admin; D recruiter | grant state; immediate future-access denial; audit | D; serialize against reads as practical |
| 23 `admin_set_recruiter_consent_version(text,text,text)` | U authorized admin; D recruiter | consent-version config; immutable version; audit | D; final consent language unresolved |
| 24 `admin_transfer_super_admin(uuid,uuid,uuid,text)` | U current Super Admin; D identity | role grants; prevent zero-admin state, authenticated succession; audit + lock | D; both actor/target verified; no caller actor proof |
| 25 `payment_set_gateway_order(uuid,text)` | S payment worker; D payment | payment order/provider reference; unique mapping, valid state; audit | System only; credentials outside DB |
| 26 `payment_set_fee(bigint,timestamptz,text)` | U admin with payment-config permission; D payment | immutable fee config/version; old/new/reason/actor/time; audit | D; INR and no rewrite existing orders |
| 27 `payment_cancel_fee_version(uuid,text)` | U authorized admin; D payment | fee config state; preserve referenced versions; audit | D; cannot mutate snapshot |
| 28 `payment_create_order(uuid)` | U team leader via E orchestration + D payment | team/order/fee snapshot/outbox; unique pending order, lock roster, 24h expiry; audit | Edge retains verified user JWT; DB derives actor, locks and inserts; provider call after commit |
| 29 `payment_record_verified_webhook(text,uuid,text,text,bigint,char(3),payment_transaction_state,bytea)` | W payment runtime; D payment | event/digest, order, transaction/refund; signature verified outside, DB revalidates all facts/idempotency; audit + locks | Never callable by anon/auth; boolean/digest alone is not auth; require authenticated worker |
| 30 `payment_expire_order(uuid)` | S payment worker; D payment | order/team roster; only expired unpaid order; audit + lock | System identity, idempotent |
| 31 `payment_cancel_order(uuid,text)` | U or S depending reason; D payment | order/team state; correct actor authorization, no cancellation of paid history; audit + lock | Split user cancellation vs system cancellation if semantics differ |
| 32 `payment_request_refund(uuid,uuid,bigint,text)` | U authorized admin; D payment | order/transaction/refunds; approved amount and reason; serialize balance; audit + row lock | Refund policy/exceptions unresolved |
| 33 `payment_finish_refund(uuid,text,bool)` | W/payment runtime; D payment | refund, txn, order; provider outcome/idempotency; audit + lock | Authenticated worker, not caller boolean as proof |
| 34 `payment_issue_receipt(uuid,text,text)` | S payment worker; D payment | receipt/order; paid successful transaction only, unique receipt; audit | System identity; no receipt before paid |
| 35 `recruiter_set_consent(text,text,bool)` | U participant; D recruiter | own consent history/scope/version; revoke immediately; audit + serialize access | Identity from auth.uid; preserve history |
| 36 `recruiter_add_shortlist(uuid)` | U recruiter; D recruiter | shortlist/candidate; active recruiter + grant + current consent; audit | D; no candidate data after consent revoked |
| 37 `recruiter_save_note(uuid,text)` | U recruiter; D recruiter | private note; same access/consent; restricted author access, retention; audit metadata | D; note content not audit payload |
| 38 `community_create_post(uuid,text,text,post_visibility)` | U; I + RLS | posts; author-only draft edits, valid visibility; audit state trigger | I for own draft; publish/moderation must use separate authorized transition |
| 39 `community_create_comment(uuid,uuid,text)` | U; I + RLS | comments/post; parent same post, access follows post/team; audit | I after same-post constraint |
| 40 `community_report_content(uuid,uuid,text,text)` | U; I + RLS | report/content; reporter identity, target relation; audit | I if content ID/type binding enforced |
| 41 `team_post_discussion_message(uuid,text)` | U current team member; I + RLS | private team messages; current membership, no recruiter/moderator auto-access; metadata audit on edit/delete/moderation/emergency | I; emergency access separate grant/audit |
| 42 `judge_assign_submission(uuid,uuid,uuid,text)` | U authorized evaluation admin; D judging | assignment/submission/judge; active judge, no duplicate active assignment, conflict check; audit + lock | D; target judge is not actor |
| 43 `judge_declare_conflict(uuid,text)` | U assigned judge; D judging | assignment/conflict; self declaration, immutable history; audit | D; access only assignment |
| 44 `judge_resolve_conflict(uuid,judge_conflict_state,text)` | U evaluation admin; D judging | conflict/assignment; actor permission and valid lifecycle; audit | D; no self-resolution unless authorized |
| 45 `judge_save_score(uuid,uuid,numeric,text DEFAULT NULL)` | U assigned judge; D judging | evaluation/criteria/scores; rubric consistency, score bound, own assignment; append score edit history; audit + lock/conditional state | D; no visibility to other judges |
| 46 `judge_submit_evaluation(uuid)` | U assigned judge; D judging | evaluation/scores; completeness and one-way submitted state; audit + lock | D |
| 47 `submission_save_version(uuid,text,text,text,text,text)` | U team member with permissions; D submission | submission/version; version order, roster/team access; audit | D if version allocation concurrent |
| 48 `submission_finalize(uuid,uuid)` | U team leader or authorized member; D submission | submission/final version/team; deadline and one finalization; audit + lock | D; derive actor, enforce event deadline |
| 49 `event_set_submission_deadline(timestamptz,text)` | U event admin; D event | event config/version; audit | D; event singleton/version semantics unresolved |
| 50 `evaluation_release(uuid,text)` | U Super Admin/evaluation admin; D judging | evaluation/public projection; authorized release only; audit | D; scores confidential until release |
| 51 `certificate_verify(text)` | P via rate-limited safe projection; no direct general table grant | certificate code/status/limited public result; unpredictable code, no PII, rate limit | Move behind isolated verifier endpoint if DB cannot enforce rate limits safely |
| 52 `certificate_issue(uuid,uuid,uuid,text)` | U authorized admin; D certificate | certificate/participant/team; eligibility and unique unpredictable code; audit | D; eligibility unresolved |
| 53 `certificate_grant_name_consent(uuid,bool)` | U participant; I or D certificate | own consent history/scope/version; audit | auth.uid derived; decide only if publication needs name |
| 54 `certificate_revoke(uuid,text)` | U authorized admin; D certificate | certificate state/reason; audit | D; retention policy unresolved |
| 55 `certificate_revoke_name_consent(uuid)` | U participant; I or D certificate | own consent history; immediate public-name removal; audit | D/I based schema history |
| 56 `registration_decide(uuid,bool,text)` | U authorized registration admin; D registration | registration; transition/decision actor; audit + lock | D; user cannot approve self |
| 57 `registration_submit()` | U; I or narrow D registration | own registration; required profile/eligibility and one submission; audit | auth.uid, no target actor |
| 58 `registration_withdraw(text)` | U; I or narrow D registration | own registration; withdrawal lifecycle and timestamps; audit | auth.uid |
| 59 `community_moderate(uuid,uuid,uuid,text,text)` | U authorized moderator; D community | report/target/action; target must match report; cannot publish draft without author or explicit publish permission; audit | Rebuild with status-transition allowlist and locks |
| 60 `admin_invitation_create(bytea,timestamptz,text)` | U authorized admin; D identity | invitation token hash/expiry; one-time digest, never raw secret; audit | D; invitation channel/identity checks |
| 61 `admin_invitation_revoke(uuid,text)` | U authorized admin; D identity | invitation; pending-only revoke; audit | D |
| 62 `admin_invitation_accept(uuid,uuid,bytea)` | U invitee; D identity | invitation/role grant; target must equal auth.uid; hashed token/expiry/one-use; audit | Remove caller identity proof ambiguity; D |
| 63 `admin_announcement_create(text,text,announcement_audience)` | U admin; I draft + RLS | announcement; author draft, safe audience | I if draft-only |
| 64 `admin_announcement_update(uuid,text,text,announcement_audience,text)` | U author/admin; I draft + RLS | own draft; published edits use audited D path | Split draft edit from published correction |
| 65 `admin_announcement_target(uuid,uuid,uuid,app_role,bool)` | U authorized admin; D event-content | target relation; valid announcement/audience/target; audit | D; target checks and auth |
| 66 `admin_announcement_publish(uuid,text)` | U authorized admin; D event-content | announcement; publish transition only; audit | D; draft moderation cannot publish |
| 67 `admin_schedule_create(text,text,timestamptz,timestamptz,text,announcement_audience)` | U admin; I draft + RLS | schedule; date checks; audit transition | I draft-only |
| 68 `admin_schedule_publish(uuid,text)` | U authorized admin; D event-content | schedule publish state; audit | D |
| 69 `admin_schedule_update(uuid,text,text,timestamptz,timestamptz,text,announcement_audience,text)` | U admin; I draft or D published correction | schedule; valid dates and transition; audit | Split by lifecycle to avoid unauthorized publish |
| 70 `admin_rubric_create(text)` | U evaluation admin; D judging | rubric version; immutable once used; audit | D |
| 71 `admin_rubric_add_criterion(uuid,text,text,text,int,numeric,smallint)` | U evaluation admin; D judging | rubric criteria; bounds/order/version checks; audit | D; immutable published rubric |
| 72 `admin_rubric_publish(uuid,text)` | U evaluation admin; D judging | rubric; immutable published version; audit | D |
| 73 `admin_certificate_type_set(certificate_kind,text,bool)` | U certificate admin; D certificate | certificate type config/version; audit | D; existing certificates unaffected |
| 74 `service_enqueue_notification(uuid,text,text,uuid,text)` | S notification worker; D notification | notification/outbox; fixed system identity, idempotency; audit event only if business event | Narrow worker identity |
| 75 `admin_community_category_set(text,text,bool)` | U community admin; D community | category config; audit | D |
| 76 `team_skill_requirement_set(uuid,uuid,smallint,bool)` | U leader/admin; D team | team skill requirements; active team membership/capacity unaffected; audit | D, or I with leader policy if row-local |
| 77 `admin_skill_set(text,text)` | U catalog admin; D catalog | skill catalog; uniqueness/normalization; audit | D |
| 78 `admin_technology_set(text)` | U catalog admin; D catalog | technology catalog; uniqueness; audit | D |
| 79 `admin_interest_area_set(text,text,bool)` | U catalog admin; D catalog | interest catalog; uniqueness/active flag; audit | D |

No row above authorizes a grant today. Before SQL drafting, enumerate exact selected columns, including SELECTs needed by WHERE/JOIN/RETURNING, and evaluate SELECT *, whole-row values, rowtype expansion, triggers, nested calls, ON CONFLICT and FOR UPDATE. Concurrency requires row locks or conditional updates plus unique/exclusion constraints where specified. Trigger events must be reconciled to avoid duplicate RPC+trigger history.

## 4. View access matrix: all 30 current views

Current draft declares 30 public views with security_barrier but none with security_invoker. View ownership/effective privileges depend on migration execution and are therefore unknown. Target is security_invoker when underlying grants and RLS suffice; otherwise replace with a narrow authenticated/private projection or Edge endpoint. Never use a view as an RLS bypass. Candidate source columns below are from current definitions and require exact re-extraction during SQL drafting.

| # / view | Proposed access and required source scope | Exposure / decision |
|---:|---|---|
| 1 `my_profile` | authenticated; profiles(user_id, display_name, phone, college, degree, branch, academic_year, city, state_region, timestamps); self RLS | security_invoker; phone only self |
| 2 `my_registration` | authenticated; registration status/submitted/decision fields | security_invoker; self only |
| 3 `public_team_directory` | anon/authenticated; teams(id,name,slug,description,created_at) | invoker/public-safe projection; exclude private roster/contact |
| 4 `my_team_roster` | authenticated; memberships + profiles display name/role/joined | invoker; current member/team RLS, omit contact |
| 5 `my_teams` | authenticated; team id/name/slug/description/status/policy/timestamps | invoker; current membership |
| 6 `current_team_size_policy` | anon/authenticated; active policy min/max/effective date | safe invoker projection |
| 7 `current_team_fee` | anon/authenticated; active fee version/INR amount/effective date | safe invoker projection; no internal change reason |
| 8 `my_payment_summary` | authenticated; own leader/team order status, snapshot amount/currency/timestamps | invoker; no gateway payload/refund admin notes |
| 9 `recruiter_candidate_directory` | recruiter only; profile candidate fields | replace with consent/access-filtered narrow projection; consent checked at request time |
| 10 `recruiter_candidate_skills` | recruiter only; participant skills + catalog | consent-filtered; no unconsented rows |
| 11 `recruiter_candidate_links` | recruiter only; profile links | consent-filtered; validate link visibility |
| 12 `released_eval_projection` | public/auth as product decides; evaluation/submission/criterion/feedback after release | invoker/replacement; no unreleased scores/judge IDs/private feedback |
| 13 `my_submission_versions` | authenticated team member; versions/title/repo/demo/docs fields | invoker + current membership RLS; repository URL privacy decision |
| 14 `public_released_projects` | anon/authenticated; team/submission/final version fields | safe projection after release; no private metadata |
| 15 `public_community_feed` | anon/authenticated; published posts only | invoker; explicit published state |
| 16 `public_announcements` | anon/authenticated; published audience-matching fields | invoker safe projection |
| 17 `public_schedule` | anon/authenticated; published schedule only | invoker safe projection |
| 18 `my_role_summary` | authenticated; own role summary | invoker; protected role lookup, not editable profile/JWT metadata |
| 19 `my_admin_permissions` | authorized admin only; own/current permission records | replace/narrow; do not disclose other admins or enable escalation |
| 20 `authorized_audit_log` | narrowly authorized auditor/admin; minimized audit fields | move to privileged projection; never grant raw audit table to all users |
| 21 `my_admin_invitations` | authorized admin; own/scope invitation metadata | invoker/filtered; never reveal token material |
| 22 `recruiter_candidate_interests` | recruiter only with consent; candidate interest catalog | consent-filtered, current grant |
| 23 `my_recruiter_notes` | recruiter author/authorized admin only | invoker; sensitive notes, retention and author scope |
| 24 `my_candidate_shortlists` | recruiter workspace/user only | workspace sharing unresolved; no implicit shared recruiter access |
| 25 `my_judge_assignments` | assigned judge only | invoker; assignment scope and conflicts minimized |
| 26 `my_judge_score_sheet` | assigned judge's own evaluation only | invoker; confidential until authorized release; exclude peer drafts |
| 27 `my_certificates` | participant's own certificates | invoker; verification code should not be directly exposed |
| 28 `my_notifications` | recipient only | invoker; recipient RLS, no cross-user access |
| 29 `my_team_discussion_messages` | current authorized team member only | invoker; moderators/recruiters excluded absent audited emergency grant |
| 30 `community_reaction_counts` | public count only | invoker/replacement; aggregate must not reveal identities |

Exact view column sets, owner, underlying grants and RLS policies are a SQL drafting deliverable. Views 9–11 and 22–24, 20, 26, 29 require the strongest consent/confidentiality review; consider moving sensitive projections behind an Edge endpoint rather than widening direct grants.

## 5. Private helper and trigger inventory: all 18 current functions

The names below are the current draft inventory. Proposed owner classes are boundaries to implement, not a claim of existing ownership. No public EXECUTE by default. Trigger functions are invoked by their triggers, not client EXECUTE. Helper functions require exact grants to calling owner/function and fixed qualified object access.

| # / helper | Proposed class / owner | Security and access requirements |
|---:|---|---|
| 1 `private.has_role` | protected authorization helper; identity domain | Prefer invoker where nonrecursive. If definer is necessary, narrowly scoped owner, qualified role-grant reads, EXECUTE only to policy/function callers; never trust profile metadata |
| 2 `private.has_permission` | protected authorization helper; identity domain | Same; evaluate current DB grant state, no recursive policy path |
| 3 `private.is_team_member` | RLS helper; team domain | Avoid membership-table policy recursion; if definer, owner gets only required membership SELECT and fixed search_path |
| 4 `private.is_team_leader` | RLS helper; team domain | Same, strict active leader predicate |
| 5 `private.can_judge_submission` | RLS helper; judging domain | Assignment+active judge+conflict checks, no broad evaluation access |
| 6 `private.can_recruiter_view` | RLS helper; recruiter domain | Current recruiter role/grant and live consent/scope/version; revocation immediate |
| 7 `private.assert_team_roster` | internal team transaction validator | EXECUTE only to team owner functions; lock-safe assertions and applicable policy version |
| 8 `private.team_roster_constraint_trigger` | constraint trigger; team domain | Validate exactly one leader/size/one active team with deferred-safe locks; error atomically |
| 9 `private.check_score_bound` | trigger; judging domain | Criterion/rubric max bound, nonnegative; prevent changing criteria/rubric race |
| 10 `private.guard_published_rubric` | trigger; judging domain | Reject mutation after published/used; serialize publish/edit |
| 11 `private.check_comment_parent` | trigger; community domain | Parent comment must belong to same post; FK/check trigger validates relation |
| 12 `private.check_moderation_target` | trigger; community domain | Report and content IDs/type must match; moderation action lifecycle |
| 13 `private.log_state_transition` | trigger audit writer | Trusted trigger-only INSERT to append-only audit; actor context from trusted DB identity/JWT mapping, not mutable GUC; transaction atomic |
| 14 `private.guard_payment_order_update` | trigger; payment domain | Snapshot immutable; pending expiry/roster lock/paid state constraints |
| 15 `private.reject_financial_fact_mutation` | trigger; payment domain | Reject UPDATE/DELETE of immutable fee/receipt/audit facts except explicit audited correction model |
| 16 `private.guard_transaction_update` | trigger; payment domain | Verified transaction matching order amount/currency and legal transition; idempotent event uniqueness |
| 17 `private.guard_refund_transition` | trigger; payment domain | Correct order/transaction linkage, serialized cumulative amount ceiling, approval/audit |
| 18 `private.touch_updated_at` | generic timestamp trigger | Invoker/trigger only; no security-sensitive reads/writes beyond NEW timestamp |

**Trigger trust constraints:** Trigger execution does not itself authenticate the actor. User JWT identity must be read from verified request claims at the DB boundary; direct runtime identity is mapped to a fixed system principal; webhook requires authenticated runtime plus verified event processing. Caller-set session variables alone are forgeable. Test invoker/definer nesting and trigger current_user/session_user behavior. Trigger owner should have only audit INSERT; domain functions should not gain audit UPDATE/DELETE. If PostgreSQL cannot establish an unforgeable actor context for the selected call path, retain only DB-authenticated identity and external operational correlation, and do not claim a trusted per-user actor event.

## 6. SQL draft conflicts and modernization gate

Current [schema draft](../database/phase-2-schema-draft.sql) is a legacy proposal, not implementation authority. Static inspection found:
- Universal `incux_rpc_owner` with broad public table DML/sequence access and an allow-all internal owner policy.
- A broad service_role EXECUTE surface and application RPCs with sensitive state changes.
- 79 public functions declared SECURITY DEFINER; this conflicts with invoker-first design.
- 30 security_barrier views and zero security_invoker views in the draft.
- `row_security=off` in privileged functions; must be removed or justified per function and never used to sidestep intended RLS.
- Broad search_path entries including public/private/auth and unqualified object risk; use fixed minimal path and schema-qualified references.
- `SELECT *`, whole-row/rowtype references and `RETURNING *` can require/expose more privileges than the proposed column allowlist.
- RPC-level audit inserts overlap state-transition triggers and risk duplicate/fabricated events.
- No transactional outbox model in the draft despite accepted worker architecture.
- Legacy payment webhook parameters cannot by themselves prove signature verification; no actor boolean/GUC substitute.
- Old moderation/announcement flow must not publish a draft through an unapproved path.
- Certificate verifier must not expose PII or rely on a global, trivially exhausted rate limit.
- Role creation/ownership transfer/replacement path and migration operator privileges are unresolved.

For each construct, rewrite against the target function matrix, retain every business invariant, create explicit grants/policies/constraints, and independently review before any migration. Do not mechanically delete functions: aliases and clients are unverified.

## 7. Migration workflow and validation

Candidate workflow: reviewed, versioned Supabase CLI migrations deployed in a controlled serialized process, with migration history checked and approval evidence. This is **not yet approved for execution**. Never use production for feasibility testing. The target for any later authorized tests is only disposable project ref `bhnhhaurdnnalcozsviq`.

Before adoption, prove in that project:
1. Exact CLI auth route, DB connection route, `session_user`, `current_user`, new-object owner, and subsequent migration identity separately.
2. NOLOGIN owner creation and negative attributes; owner function assignment; function/schema/table privileges; no runtime/API membership or SET ROLE.
3. How migration operator can replace owner-owned functions later, using a narrowly scoped, temporary, reviewable privilege mechanism; test interruption and revoke/recovery. Do not infer automatic authority.
4. Hosted behavior for FORCE RLS, invoker/definer nesting, trigger execution identity, view security_invoker, role grants, private schema, pooler modes and system custom LOGINs.
5. Negative API-role access and exact EXECUTE allowlists; absence of direct sensitive DML.
6. Runtime identities separately (payment, notification, scheduled/team workflows, other justified domains); prove session/current identity, no SET ROLE, no direct tables, only named function.
7. Trigger audit actor mapping for PostgREST JWT and custom runtime connections; reject caller GUC forgery.
8. Outbox uniqueness/retries/crash rollback/idempotency with no real provider.
9. Migration history consistency and failure recovery without broad destructive cleanup.

Tests that mutate DB objects or migration history require separate explicit operator approval and isolated disposable confirmation. Current report documents only read-only preflight evidence; no probe has established migration identity. Database execution identity remains unknown. Do not run Phase 2.6 validation SQL without a separate fresh safety review and all preconditions.

## 8. Open business and technical decisions

Business: team minimum/maximum; actual INR fee; final refund/exceptions; dates/location; eligibility; consent wording; judge count/rubric/release rules; certificate eligibility; retention/privacy; recruiter workspace sharing.

Technical: exact 79 operation source signatures and alias/client compatibility; normalized per-function column sets; exact 30 view projections and grants; exact 18 helper ownership; audit actor binding; custom runtime connection route; migration operator identity/temporary owner-replacement mechanism; CLI deployment and transaction boundaries; transaction-pooler identity behavior; private schema existence/ownership; rate-limit service for certificate verification; outbox schema/lease/retry policy; whether secure event-level score drafts and team message metadata fit retention/access rules.

## 9. Traceability and decision

Use the [decision register](phase-2.14.4-decision-register.md) for each accepted/proposed/unresolved decision, source, conflict and follow-up. Use the [implementation conflict inventory](phase-2.14.4-implementation-conflict-inventory.md) for individual legacy SQL problems. Use the [Phase 2.14.2 workflow design](phase-2.14.2-migration-workflow-design.md) only as a candidate workflow; [Phase 2.14.3 recovery review](phase-2.14.3-documentation-recovery-review.md) describes missing historical specifications and archive status.

**Final decision: NO-GO for detailed SQL drafting and any database-changing validation.** The high-level architecture direction is coherent, but detailed grants, identities, object ownership, actual migration identity, replacement lifecycle, and actor/audit trust have not been proven. A future independent reviewer should sign off the recovered 79/30/18 matrices and migration plan before implementation.

