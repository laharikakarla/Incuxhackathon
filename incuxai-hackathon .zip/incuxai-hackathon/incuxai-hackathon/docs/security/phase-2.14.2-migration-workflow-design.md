# Phase 2.14.2 — Migration Workflow Design and Feasibility

**Status:** Design proposal only. No migrations were created or executed. No Supabase project was contacted.  
**Decision:** **NO-GO for migration execution or the Phase 2.15 identity probe until the actual migration identity and ownership lifecycle are validated in the disposable project.**

## 1. Goals and architecture boundary

This workflow preserves the accepted Phase 2.12 architecture:

- User operations derive identity from a verified JWT and `auth.uid()`.
- User-facing operations use RLS and `SECURITY INVOKER` where sufficient.
- Narrow domain-specific `NOLOGIN` roles own only appropriate `SECURITY DEFINER` functions.
- System workloads use separate, least-privilege runtime identities.
- Payment/webhook/refund processing runs in an independently controlled runtime.
- Audit is trigger-owned and append-only.
- Views use `security_invoker` where caller grants and RLS safely constrain them.
- No universal function owner, no routine `service_role` application transactions, and no permanent broad migration grants.

The accepted Phase 2.12 specification and Phase 2.13 plans are not present in the current repository. The above points are taken from the user-approved direction and Phase 2.14 context; the plan must be reconciled with a canonical architecture document before implementation.

The latest Phase 2.14.2 findings supplied by the user state that the read-only CLI session reported an empty local/remote migration comparison and observed PostgreSQL 17.11 with `supabase_read_only_user`. These newer supplied findings supersede the earlier access-token failure recorded in the Phase 2.14 report for those checks. The report file itself has not been updated here, and these observations were not independently re-queried for this design-only task.

## 2. Supported deployment route comparison

| Route | Repeatability and history | Identity clarity | Credential/security considerations | Assessment |
|---|---|---|---|---|
| Supabase CLI `db push --remote=<project-ref>` | Applies local timestamped migration files not present in remote `supabase_migrations.schema_migrations`; supports dry-run and migration listing | The actual PostgreSQL login/effective role/object owner still must be observed. CLI authentication does not establish them. | Uses Supabase CLI authentication and a hosted database connection credential/route. Avoid implicit linked targets. Keep credentials out of command text and files. | **Recommended deployment mechanism after validation.** Explicit target and version-controlled migrations provide a repeatable process. |
| CI job running the same CLI command | Same migration history and semantics as CLI push; supports serialized, reviewed deployment | Same unresolved database execution identity as local CLI until observed from actual migration execution | Store CLI token and database credential in CI secret storage. Scope job and secrets to disposable environment during validation; do not print values. | **Recommended eventual operator interface**, but it does not by itself improve database least privilege. |
| Direct `psql` or CLI remote database URL | Can apply SQL, but does not inherently provide the CLI migration-file comparison/history workflow | Connects as the username in the supplied database route; that identity still must be checked | Connection URLs/passwords passed through arguments can leak through shell history/process inspection/logs. | Not recommended as the normal workflow. Reserve direct tools for approved recovery/diagnostics with controlled credentials. |
| Dashboard SQL Editor | Manual execution; bypasses the repository migration sequence unless separately reconciled | SQL Editor identity may differ from CLI migration identity | Easy to apply unreviewed ad hoc DDL; it does not prove migration-path ownership behavior | Not the deployment workflow. Never use it to bypass migration history. |
| `db push --dry-run` | Shows proposed migration work, applies nothing | Does not execute migration DDL and therefore proves no migration identity or object owner | Safe planning check when the explicit target is correct | Required review step, but not identity evidence. |

Supabase’s current deployment guidance describes `db push` as applying pending local migrations and tracking them in `supabase_migrations.schema_migrations`. Its CLI v3 guidance uses `--remote=<ref>` and notes that implicit/legacy target options are deprecated. Verify the exact installed CLI 3.1.0 behavior again before adopting future CLI versions. [Database migration deployment](https://supabase.com/docs/guides/deployment/database-migrations), [CLI v3 hosted-target behavior](https://supabase.com/docs/guides/local-development/local-and-hosted-projects)

## 3. Credential and identity model

Treat these as separate facts:

1. **Supabase CLI authentication:** the platform access token authorizes CLI operations against Supabase. It identifies/authorizes the CLI session; it is not itself the PostgreSQL role executing migration SQL.
2. **Database connection credential and route:** for hosted `db push`, Supabase documents the project database password separately from the CLI access token (including `SUPABASE_DB_PASSWORD` for CI workflows). A remote database URL is another route but can expose credentials if handled carelessly. Never place secrets in this document, migration files, shell history, or logs.
3. **`session_user`:** PostgreSQL login identity for the established database session.
4. **`current_user`:** effective SQL identity at the statement. It may differ after role changes or while a `SECURITY DEFINER` function runs.
5. **Migration object owner:** normally the role that creates the object, unless it is subsequently transferred. This must be inspected after the actual migration path.
6. **Subsequent migration identity:** must be observed separately when a later migration replaces an object owned by a domain owner.

The previous read-only diagnostic identity was `supabase_read_only_user`; it is not evidence of the migration identity. No migration command or credential route is documented in the current repo, and no local migrations directory exists. The actual database login, effective migration role, object owner, and subsequent migration role remain **unknown**. Do not infer them from CLI version, successful login, a dry run, or `migration list`.

### Credential handling recommendation

- Prefer a controlled CI/deployment environment for the eventual repeatable workflow, with the CLI access token and database credential stored separately in its secret manager and scoped to the approved environment.
- Keep the disposable project reference explicit on every remote command. The local `supabase/config.toml` project id differs from the disposable project name, so do not rely on implicit linked-target selection.
- Avoid passing a database password or full connection URL as a literal command argument. Use the CLI’s documented secure prompt/environment mechanism after verifying exact CLI 3.1.0 behavior. Never echo environment variables.
- Serialize deployments: only one migration push at a time. Review the dry-run output and target before the separately approved apply step.
- Do not set an unattended confirmation flag until the deployment approval gate has independently confirmed the project and exact pending migrations.

Supabase documents CLI access-token and hosted database-password variables as distinct inputs for CI. That documents the credential separation, not the PostgreSQL role selected by a particular hosted connection. [Hosted project and CI environment variables](https://supabase.com/docs/guides/local-development/local-and-hosted-projects)

## 4. Function ownership lifecycle

### Initial creation

For a definer function, the desired owner is a domain-specific `NOLOGIN` role with no superuser, role-creation, database-creation, replication, or RLS-bypass capability. It must not own protected tables/schemas or receive unrelated domain privileges.

Two possible creation patterns need validation:

1. Create under the migration operator, then transfer ownership to the domain owner.
2. Temporarily let the migration session assume the domain owner and create the function while that role is `current_user`.

Neither is assumed supported in the hosted project. Pattern 2 avoids a post-creation transfer but still requires temporary schema `CREATE` for function creation and a valid role-assumption path.

PostgreSQL ownership rules that inform the test:

- The creating role becomes function owner unless ownership is changed.
- Function ownership transfer requires the executing role to own the function and be able to `SET ROLE` to the new owner; the new owner must have `CREATE` on the function’s schema.
- Replacing an existing function requires ownership (including effective authority through membership in the owner role). `CREATE OR REPLACE` preserves owner and ACLs; it does not transfer ownership to the migration operator.
- Schema `CREATE` alone must not be treated as permission to replace a domain-owned function.

These PostgreSQL rules are documented, but Supabase’s managed migration identity and grant path remain unverified. [PostgreSQL 17 `CREATE FUNCTION`](https://www.postgresql.org/docs/17/sql-createfunction.html), [PostgreSQL 17 `ALTER FUNCTION`](https://www.postgresql.org/docs/17/sql-alterfunction.html)

### Subsequent replacement

A later migration cannot be assumed to replace a domain-owned function merely because the migration operator created it originally or has schema `CREATE`. Test an expected-denial call first, then test the candidate temporary mechanism:

1. A separately authorized grantor grants the migration session a short-lived, domain-specific ability to `SET ROLE` to one owner. The migration operator must not receive `ADMIN` on the owner role for this purpose.
2. Grant the owner role schema `CREATE` only for the migration window if the actual replacement/creation operation requires it. Do not leave schema `CREATE` on the function owner or runtime roles by default.
3. The migration session assumes the owner role, performs only reviewed changes to that domain’s functions, then resets to its original role.
4. The grantor revokes the temporary membership and schema privilege. Verify both are absent, API/runtime roles cannot assume the owner, and the functions still have the intended owner/ACL.
5. Repeat with a later migration to prove the process is repeatable.

This is a **candidate workflow, not a confirmed mechanism**. The current operator may lack authority to grant/revoke membership or schema privileges. A just-in-time grant can also leave elevated access if the workflow is not atomic or revocation fails. The controlled test must establish who grants it, whether it can be limited to the domain, how it is revoked on failure, and whether the Supabase CLI migration process can use it.

### Recommended ownership approach

Prefer creating/replacing a function under its domain owner during a tightly scoped migration window, then removing temporary access. Do not grant the operator permanent membership in every owner role, permanent schema `CREATE`, `BYPASSRLS`, or a universal owner role. If the hosted project cannot support a safe just-in-time membership/grantor path, **stop and redesign the deployment authority model** rather than silently granting standing broad privileges.

## 5. Migration history and review strategy

The supplied Phase 2.14 results say `supabase migration list` showed an empty local/remote comparison. No local `supabase/migrations` directory exists. Before the first migration is created in a later authorized phase:

1. Establish the intended source-of-truth migration folder and naming convention; do not generate one as part of this design task.
2. Keep each migration timestamped, reviewed, and immutable once applied. Later corrections should be new forward migrations, not edits to already applied migration files.
3. Use one serialized deployment job; first run a dry-run with the explicit disposable reference, review every pending migration, then request separate approval to apply.
4. Use `supabase migration list --remote=<exact-ref>` before and after a push to compare local files with the database history.
5. Preserve sanitized evidence of pending/applied migration IDs and outcomes, never credentials.
6. Treat `supabase_migrations.schema_migrations` as a record of migration application, not proof that each database object has the expected state.
7. Use `migration repair` only as an explicitly reviewed history correction after catalog state is independently understood. It changes history metadata; it does not apply or reverse the migration SQL. Never use it to disguise a failed or partial deployment.

Supabase’s deployment guide describes migration history comparison and warns that direct dashboard changes bypass the normal migration workflow. [Migration history and repair guidance](https://supabase.com/docs/guides/deployment/database-migrations)

## 6. Failure, rollback, and partial-application recovery

Do not assume every CLI migration is transactionally atomic. Validate transaction behavior through the actual CLI 3.1.0 deployment route in the disposable project. PostgreSQL supports transactional DDL for many operations, but the migration file and runner determine the boundary; some commands or external effects may not be rollbackable.

| Failure point | Possible state | Safe response |
|---|---|---|
| Role creation or attribute setup fails | Transactional changes may roll back; otherwise a partial role or grant may remain | Stop. Inspect exact role state and migration history. Do not retry blindly or drop a guessed role. Use an exact reviewed cleanup or discard the disposable project. |
| Ownership transfer fails | Function may retain its original owner; prior grants/schema changes may or may not persist | Inspect function owner, ACL, membership graph, and schema privileges. Restore only by a reviewed exact operation; if ambiguous, stop and use a fresh disposable project. |
| Replacement fails | Existing definition may remain, while earlier nontransactional grants may persist | Inspect definition/owner/ACL and migration history. Avoid replacing or dropping more objects until state is known. Prefer a corrective forward migration once state is understood. |
| Failure after temporary grants, before revocation | Temporary membership or schema `CREATE` may remain active if not in the same transaction | Treat as a security failure. Revoke only through the known grantor/authorized path, then verify all memberships and effective privileges. If safe revocation cannot be proven, discard the disposable project. |
| Later migration fails | Prior successful migrations remain; the failing migration may be all-or-partial depending on runner transaction behavior | Compare catalog state and migration history. Do not manually delete history or rerun blindly. Use a forward repair after review or recreate the disposable project. |

Do not use broad cleanup such as `CASCADE`, `DROP OWNED`, bulk schema deletion, or manual history edits. The remote `db reset` workflow is destructive and must not be used as routine rollback. Deleting/recreating the disposable project is the clean fallback only after separate explicit approval and fresh target verification.

## 7. Recommended deployment workflow

Subject to disposable validation and later explicit authorization:

1. Author changes in reviewed migration files, with function owner, fixed search path, ACL, and RLS behavior explicit in each relevant change.
2. Validate locally against a disposable local Supabase stack before any hosted test.
3. Have one CI/deployment job run with separately scoped CLI and database credentials; never print their values.
4. Pin the exact project ref in every remote CLI command. Never rely on the current local link or `supabase/config.toml` project id for target safety.
5. Run migration status and dry-run. A dry run confirms only the proposed file set, not the database identity or permissions.
6. Obtain explicit approval for the exact disposable deployment.
7. Apply one migration batch through `supabase db push --remote=<exact-disposable-ref>` only after identity and temporary-privilege behavior pass validation.
8. Capture the actual migration identity and created/replaced object ownership from a dedicated approved probe; compare pre/post role memberships, schema grants, function ACLs, and migration history.
9. Confirm temporary access is removed, then run read-only verification and a later replacement migration.
10. Rehearse failure cases and cleanup on disposable project only. Production remains out of scope for this validation.

The CLI v3 command exposes the remote target explicitly and can show a dry-run of planned work. Neither the dry-run nor CLI login proves the PostgreSQL identity. [CLI v3 target and dry-run behavior](https://supabase.com/docs/guides/local-development/local-and-hosted-projects)

## 8. Disposable-only feasibility validation

The only permitted target for future tests is `incuxai-hackathon-validation` (`bhnhhaurdnnalcozsviq`). Every hosted command must specify that exact reference. Stop if the CLI does not resolve the target name and ref exactly. Never use the production project.

Required approval-gated tests, in order:

1. **Read-only preflight:** current database/version/identity, migration history, all relevant roles and membership paths, schema ACLs/grant options, effective privileges, and exact fixture-name collision checks.
2. **Migration identity probe:** a uniquely named, reviewed probe migration applied by the exact planned CLI deployment route; observe `session_user`, `current_user`, and fixture object owner. This mutates the disposable database and migration history and requires explicit approval.
3. **Initial owner transfer:** create a fixture function as the observed operator, attempt the planned ownership transfer to one NOLOGIN domain owner, and verify required owner/schema privileges and exact ACLs.
4. **Subsequent replacement:** prove replacement is denied without temporary authorization, then test the reviewed just-in-time mechanism; revoke it and verify the final owner, membership graph, schema grants, and API/runtime role exclusions.
5. **Failure injection:** fail after each relevant grant/ownership/replacement boundary; inspect partial state and migration history; test the documented exact recovery path.
6. **Second migration:** run a separate follow-up fixture migration through the same path to show the lifecycle is repeatable and no privilege accumulated.
7. **Cleanup:** use exact reviewed cleanup or delete the disposable project after preserving sanitized evidence. Deletion requires separate approval.

The existing Phase 2.6 validation script is not suitable for this architecture: it targets `incux_rpc_owner`, a universal role explicitly rejected by Phase 2.12. Do not execute it or treat its results as proof of the domain-owner lifecycle.

## 9. Hosted Supabase limitations and assumptions

### Documented platform behavior

- Supabase supports versioned SQL migrations through the CLI and tracks applied versions in `supabase_migrations.schema_migrations`.
- Supabase CLI and database credentials are separate configuration inputs in documented CI workflows.
- PostgreSQL roles, membership options, function ownership, and `SECURITY DEFINER` execution follow PostgreSQL semantics, subject to hosted-project privileges.
- Supabase documents custom PostgreSQL roles and RLS as database access controls.

### Not verified for this project

- Which login role `db push` uses, what `session_user`/`current_user` the migration statements see, and who owns newly created objects.
- Whether the actual migration operator can create the proposed NOLOGIN owner roles or set every required negative role attribute.
- Whether ownership transfer is permitted under the target's schema/role grants.
- Whether a separate trusted grantor can grant and revoke narrowly scoped `SET` membership and temporary schema `CREATE` around the CLI migration.
- Whether the migration runner's transaction boundary makes grants, replacements, revocations, and migration-history updates atomic as required.
- Whether subsequent CLI migrations can replace owner-owned functions without a permanent broad grant.
- Whether the target project’s `private` schema, exposed schemas, and pooler route match the architecture assumptions.

No hosted capability is considered verified from documentation or static inspection alone.

## 10. Unresolved questions

1. What exact reviewed command will deploy migrations, and will it run locally or in CI?
2. Which non-secret authentication route does that command use: CLI platform access token, database password, or both? Where are the secret values held, without copying them into this repository?
3. What are the actual `session_user`, `current_user`, and created-object owner through that command?
4. Who can grant and revoke temporary membership to each domain owner, and can this be done with `ADMIN FALSE`, `INHERIT FALSE`, and `SET TRUE` for the migration operator?
5. Can schema `CREATE` be granted only for the migration window and safely revoked on success and failure?
6. Does `db push` apply a migration transactionally in the exact CLI version/route, and what happens to migration history after injected failure?
7. Can the exact workflow replace a domain-owned function on a later migration without lasting operator membership or broad schema rights?
8. Are canonical Phase 2.13 fixture names and an approved cleanup strategy defined?
9. The local config's project id differs from the disposable project name. Will every future command pin `--remote=bhnhhaurdnnalcozsviq`, and will the operator confirm Dashboard project name/ref before mutation?

## 11. Final recommendation

**NO-GO — do not execute migrations or request approval for the Phase 2.15 identity probe yet.**

The normal long-term route should be a reviewed, serialized Supabase CLI `db push` from version-controlled migration files, preferably through a controlled CI job with explicit target and separately managed CLI/database credentials. However, the actual PostgreSQL execution identity is unknown, the repository has no migration files or documented deployment command, and there is no validated way to give the migration operator temporary domain-owner authority and revoke it safely.

The next authorized step is to define the exact disposable probe package and perform the read-only preflight, then request approval for the one-time disposable migration identity probe. Do not begin implementation migrations until the probe and subsequent-replacement test pass without permanent broad privileges.
