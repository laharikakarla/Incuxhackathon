# AICUXORA Phase 4.2 — Independent Security Architecture Review

**Review mode:** Static repository review only. No Supabase connection, SQL execution, migration, credentials, database mutation, application change, commit, or push.  
**Verdict:** **NO-GO** for backend implementation, SQL drafting, or migrations. The Phase 4.1 product decisions are largely compatible with the accepted identity/RLS architecture, but they conflict with old payment assumptions and are not yet reflected in an implementation-ready, independently reviewed security specification. Major Phase 2.14.5 and migration-feasibility blockers remain.

## 1. Executive verdict

The confirmed product model is clear at the business level: accounts, verified email, profiles, and individual event registration precede payment; team size is 2–5; future payment is per participant, with an independent payment state for each participant. That model is compatible with the accepted principles that identity comes from a verified JWT and `auth.uid()`, authorization is enforced by RLS/database transactions, and an actor ID supplied by a client is not proof.

It is **not yet reconciled with the old database proposal**. The Phase 2.14.4 decision register still lists D-015 as one payment per team and D-023 as initially free registration. The draft SQL implements a team-level fee/order model. Phase 4.1 is later product direction and controls product meaning, but the authoritative security architecture, decision register, SQL draft, and function/view matrices have not been updated or re-approved to reflect individual payments. The earlier team payment roster-lock rule also needs re-evaluation; it must not be mechanically retained for a per-participant charge.

No local evidence shows a functioning Supabase Auth integration, deployed database objects, migration path, approved runtime identities, or validated RLS. Phase 2.14.4 is explicitly a reconstructed working specification, not the missing original Phase 2.12/2.13 source. Phase 2.14.5 identifies unresolved critical identity, audit, definer-owner and migration blockers. Static inspection cannot clear them.

## 2. Document traceability matrix

| Source | Present? | Role and relevant sections | Review treatment |
|---|---|---|---|
| `phase-2.14.4-authoritative-security-architecture.md` | Yes | §§1–7; trust boundaries, identity/audit, outbox/payment, proposed 79-function, 30-view and helper matrices | Current architecture direction, explicitly design-only and NO-GO. Matrices are proposed reconstructions, not recovered original approvals. |
| `phase-2.14.4-decision-register.md` | Yes | D-002–D-013 identity/roles/audit/outbox; D-014–D-019 team/payment/recruiter/judge/moderation/certificate; D-020–D-028 traceability/migration | Accepted architecture decisions are preserved, but D-015 and D-023 are stale against Phase 4.1 product decisions. D-022/D-026 keep detailed classifications and migration feasibility unresolved. |
| `phase-2.14.4-implementation-conflict-inventory.md` | Yes | C-01–C-13, M-01–M-21 and draft-wide observations | Confirms legacy SQL conflicts: universal owner, service-role grants, direct audit writes, non-invoker views, broad definer functions, and other unsafe constructs. It explicitly does not authorize edits or treat SQL as implementation authority. |
| `phase-2.14.5-independent-security-audit.md` | Yes | Executive verdict; C-01–C-04; H-01–H-08; M-01–M-07 | Most recent independent security findings. NO-GO remains. Critical gaps include user/system actor binding, audit actor authenticity, definer/RLS ownership boundaries and migration replacement. |
| `aicuxora-phase-4-backend-readiness.md` | Yes | §§1–10 | Records no client/backend integration, no migration directory, schema as unexecuted proposal, requirements mapping and NO-GO. Updated for Phase 4.1; correctly notes the old per-team assumptions need reconciliation. |
| `aicuxora-phase-4.1-registration-decision.md` | Yes | §§1–8 | Authoritative confirmed product decisions for account/profile/individual registration/future per-participant payment. Payment values and venue remain open. NO-GO preserved. |
| `phase-2-architecture.md`, `phase-2-relationships.md`, `phase-2-rls-matrix.md`, `phase-2-security-review.md` | Yes | Earlier architecture, relationships, RLS and security assumptions | Historical design material. Where these conflict with Phase 2.14.4 accepted direction or Phase 4.1 product decisions, they are not implementation authority. |
| Original Phase 2.12, 2.13 and 2.13.1 source specifications | **Missing from this checkout and inspected Git history** | Their decisions are summarized/reconstructed by later documents | Do not claim their detailed matrices were recovered verbatim. Request source exports if exact provenance is required; otherwise explicitly ratify the later proposed reconstruction. |

## 3. Product-to-security architecture mapping

| Confirmed requirement | Compatibility | Required control / unresolved detail |
|---|---|---|
| Accounts before payment; email verification required | Compatible with Auth/JWT architecture | Auth provider must enforce verification; callback/recovery behavior and hosted settings need validation. UI state cannot self-verify an account. |
| Profile completion independent of payment | Compatible | Profile subject must bind to `auth.uid()`; define which fields are private/public and editable; prohibit self-edit of role/permission fields. |
| Individual event registration | Compatible in principle; schema proposal must be reconciled | One participant's registration belongs to that participant. Submission must not set paid state. Eligibility, approval/review, duplicate registration, withdraw and reopen policy remain undefined. |
| Team size 2–5 | Compatible with existing adopted team invariants | Enforce atomically, include leader in count, preserve exactly one active leader and one active team per participant. Confirm effective policy version and membership/registration ordering. |
| Future individual participant payment | Conflicts with old payment proposal, not with the core identity architecture | Separate participant-level order/transaction/refund state. Never infer payment from leader/team. Fee, currency, provider, payment obligation timing, refunds and chargebacks remain open. Do not apply old per-team roster-lock semantics without a new decision. |
| Super Admin, Registration Admin, Content Admin | Compatible with protected backend authorization in principle | Define permission catalog and exact operations per role; protected grants, initial bootstrap, invitation proof, revocation and last-Super-Admin controls are not implementation-ready. No frontend-only enforcement. |
| Venue, fee, provider not yet known | No conflict | Do not invent or hardcode these as final values. Define how TBD content is presented and later published. |

### Confirmed architecture decisions (not feasibility proof)

- User identity comes from a verified signed JWT and `auth.uid()`. Browser-supplied IDs, mutable profile data and editable JWT metadata are not identity or authorization proof.
- Prefer SECURITY INVOKER plus RLS. Use narrow domain-specific NOLOGIN SECURITY DEFINER transaction owners only where atomic privileged behavior requires them; no universal owner.
- Distinguish `user`, `system`, and `webhook` actors. A parameter, boolean, or custom GUC is not proof of actor identity.
- Avoid routine application use of shared `service_role`; payment/webhook/refund work is assigned to an independently controlled runtime direction.
- Audit events are intended to be trigger-owned, append-only and atomic with business changes; outbox/inbox processing is intended for external side effects.
- SECURITY INVOKER views are preferred only when underlying grants/RLS preserve boundaries; otherwise use narrower projections.

These decisions are documented at architecture level. Their exact policies, grants, owners, identities, function manifests and hosted behavior are not verified.

### Confirmed product decisions (Phase 4.1)

Accounts may precede payment; email verification is required; profiles are independent of payment; event registration is individual; team size is 2–5; future payment is individual with independent participant state. Fee, provider and venue remain TBD. These must not be reinterpreted as team-level billing.

### Proposed/reconstructed details

The 79 public operation, 30 view, and 18 private helper/trigger classifications in Phase 2.14.4 are explicitly proposed reconstructions from the draft. They are not established historical approvals. Exact function-column grants, per-role owners, view projections, identity context, audit triggers and call graphs remain to be specified and reviewed.

## 4. Adversarial review

### A. Authentication and identity

**Compatible direction:** the product requirement for email verification can use the Auth provider; user database actions can use verified JWT context and `auth.uid()`.

**Blocking gaps:** local config is not hosted Auth proof; the Phase 4 report identifies a local callback URL/port mismatch; no Supabase application client or real auth flow is implemented; recovery/session lifecycle and account deletion are not tested. Phase 2.14.5 C-01/H-02 says the architecture does not bind every user/system/Edge/pooler call path to an observable, non-forgeable DB identity. In a SECURITY DEFINER body `current_user` becomes the function owner; system login identity alone is not a participant identity.

**Attack check:** a browser submitting another student's UUID as `actor_id` must fail to change that student's profile or registration. A service credential plus an actor UUID is insufficient. Missing or conflicting JWT context must fail closed. Password recovery must require the Auth provider's token flow and must not permit UI-only success.

### B. Student data

The draft proposes profiles and registration tables, but no deployed RLS is evidenced. The controls must distinguish private contact data (email/phone) from intentionally public profile fields. Profile ownership must bind to `auth.uid()`; registration ownership and read access must be independent from team membership. A teammate should receive only the member data needed for team participation, not unrestricted contact/profile fields. Admin access must be permission-scoped and audited.

**Attack check:** student A cannot select/update student B's profile or registration by changing route IDs, request bodies, RPC targets, filters, or nested resource IDs. Public/recruiter views must not reveal phone/email absent a specifically authorized and consented flow.

### C. Teams

The accepted invariant set includes one active team per participant, leader included in the 2–5 count, exactly one active leader, versioned team-size policy, transactional membership operations, and previously adopted payment/roster protections. The per-participant payment decision changes how that last payment interaction is applied and requires a product decision; a team cannot be treated as paid because its leader paid.

**Attack/race checks:** concurrent team creation/join/invitation acceptance cannot put a participant on two active teams or over capacity; competing invitations cannot exceed 5; concurrent leader transfer/removal cannot leave zero or two leaders; an ordinary member cannot add/remove/transfer other members; expired/revoked invites cannot be accepted. These need database constraints plus locking/conditional transitions, not frontend checks. Lock ordering and retry behavior remain undefined (Phase 2.14.5 M-01).

### D. Individual payments

Product and architecture agree that payment will be later and per participant. The old Phase 2 draft and D-015 do not: D-015 specifically adopts one payment per team by the leader; SQL defines team fee/payment orders. Phase 4.1 supersedes that product rule but does not itself define a safe replacement schema or transaction design.

**Required attack defenses:** no registration-submit endpoint, team leader action, client callback, or teammate event changes another participant's payment status. The future payment record must bind to the correct participant, registration/event context and immutable fee snapshot. Provider signature verification must occur in the independent worker over the exact raw request body; database processing must independently verify event uniqueness, order/participant binding, amount/currency and valid state transition. Duplicate and out-of-order events must be idempotent; refund totals must be serialized and capped. No locks may be held across a provider call. Failed/retried worker processing must not produce duplicate charges, refunds, receipts or audit events.

Phase 2.14.5 H-03 and H-07 remain open: worker-to-database authentication and proof, inbox/outbox schema and recovery are not specified. The old `payment_finish_refund(..., bool)` is not a trustworthy proof mechanism if its boolean is caller-controlled. Fee, provider, currency, payment deadline, refund policy, chargeback and whether payment gates participation remain unresolved.

### E. Administration

The requested Super Admin, Registration Admin, Content Admin roles can fit protected permission records, but the old SQL's role and function implementation is not safe to adopt wholesale. Define a permission-to-operation matrix: registration admins must not edit content or grant roles; content admins must not approve registrations or access payment/private student data; only an explicitly authorized Super Admin can administer roles, with last-Super-Admin safety. Admin invitation acceptance must bind the verified Auth identity and invited email, not a supplied target user ID.

Every grant, revoke, registration decision, content publish, configuration change, and exceptional override needs authenticated actor, previous/new state, timestamp and reason where appropriate. Trigger-owned audit still needs trusted actor mapping (C-02/H-06). Frontend route guards are only navigation; database/server authorization is mandatory.

### F. Database and migration feasibility

Current SQL is historical/unexecuted and conflicts with the accepted design: Phase 2.14.5 records all 79 public RPC definitions as SECURITY DEFINER, 30 views without `security_invoker`, universal `incux_rpc_owner` broad table grants/allow-all policy, service-role access, direct audit inserts, `row_security=off`, broad rowtypes/`SELECT *`/`RETURNING *`, and no outbox model. Do not apply it as-is.

Domain-specific NOLOGIN owner roles, FORCE RLS, trigger-owned audit, custom LOGIN workloads and independent payment runtime are design directions only. Exact table/column grants, policy predicates, memberships, search paths, nested definer permissions and trigger execution identity are missing. Migration operator identity and subsequent replace of domain-owned functions remain unknown; a CLI dry run or read-only identity is not enough. Transaction-pooling identity behavior and custom runtime login routes are unverified.

## 5. Unresolved conflicts and decisions

| Issue | Classification | Required resolution |
|---|---|---|
| D-015 / old SQL: one payment per team, leader pays, fee version per team; Phase 4.1: payment per participant | **Product decision superseded; implementation conflict unresolved** | Update the authoritative decision register and architecture after review. Preserve per-participant ownership and separate payment status. Reclassify payment operations and remove team-level assumptions before any SQL specification. |
| D-023: initial registration free; Phase 4.1: account/profile/registration before later payment | **Product lifecycle decision superseded; implementation conflict unresolved** | Amend decision provenance. Clarify registration submission/acceptance independent of payment; define any payment activation gate only after product decides. |
| Team roster lock when payment begins/succeeds vs individual payment | **Unresolved business rule** | Decide whether any individual payment event affects team roster, and under what condition. Do not infer from old team-order workflow. |
| Registration state and approval | **Unresolved** | Confirm eligibility, whether submission is immediate acceptance or review, duplicate registration, withdrawal, reopening and correction policies. |
| Payment values/operations | **Unresolved** | Fee, currency, provider, timing, retries, refund/partial refund, chargebacks, receipts and payment-gates-participation policy. |
| Admin permissions | **Partially specified** | Map the three confirmed roles to every operation; define bootstrap/invite/revoke and emergency access. |
| Historical detailed function/view/helper matrices | **Provenance gap** | Recover original Phase 2.12/2.13/2.13.1 source or explicitly ratify reconstructed matrices as new decisions. |
| Migration and runtime identities | **Critical feasibility blocker** | Validate only in the disposable project after a separately reviewed test package and explicit authorization. |

## 6. Findings by severity

### Critical

1. **C-01 — Product payment model and current database design disagree.** Phase 4.1 requires individual payment; D-015 and the draft encode team-level payment. Implementing the old model can incorrectly mark non-paying teammates paid and corrupt fee/refund/audit ownership. **References:** Phase 4.1 §§1–5; decision register D-015; Phase 2 schema payment tables/functions; Phase 2.14.5 H-03.
2. **C-02 — Authenticated actor cannot yet be proven through every database path.** JWT forwarding, `auth.uid()` in Edge/definer/pooler calls, and system actor mapping are not specified/validated. **References:** Phase 2.14.5 C-01/H-02; architecture §§2–3.
3. **C-03 — Domain owner/RLS boundary and function replacement are not implementable as specified.** Exact owners, memberships, policies, grants and safe subsequent migration lifecycle are missing. **References:** Phase 2.14.5 C-03/C-04; architecture §§1, 7; D-026.
4. **C-04 — Trusted audit actor/writer is unresolved.** Triggers provide atomicity, not actor authenticity; custom GUCs or parameters are forgeable, while trigger owner identity can obscure the original user. **References:** Phase 2.14.5 C-02/H-06; architecture §2/D-011.

### High

1. **H-01 — Individual registration states and authorization are underspecified.** Ownership, eligibility, review, withdrawal, duplicate handling and payment independence require explicit server-side transitions. **References:** Phase 4.1 §4; Phase 4 readiness §4 row 3; draft registration functions.
2. **H-02 — Admin permissions are not mapped to the three product roles.** Risk of cross-role privilege escalation or excessive student-data access. **References:** Phase 4 requirements; Phase 2.14.5 H-01; draft `user_role_grants`/permission functions.
3. **H-03 — User/team privacy boundaries are not fully manifest.** Profile contact data and team roster projection need exact columns and policy-specific negative tests. **References:** Phase 2.14.5 H-01/H-04/H-05; draft profile/team views.
4. **H-04 — Payment worker trust, event processing and recovery are incomplete.** Verified signature, replay, amount/order binding, idempotency, refunds and transactional outbox need one coherent per-participant flow. **References:** Phase 2.14.5 H-03/H-07; architecture §2.
5. **H-05 — Runtime and migration execution path unvalidated.** Actual migration identity, owner transfer/replacement, JIT privilege/revocation, custom logins and pooler behavior remain unverified. **References:** architecture §7; D-025/D-026; Phase 2.14.5 C-04/M-07.
6. **H-06 — No database implementation or migrations exist in this checkout.** UI previews must not be mistaken for functional authentication or persistence. **References:** Phase 4 readiness §§3, 9; repository inspection summarized there.
7. **H-07 — Legacy SQL cannot be used as a first implementation.** It violates the accepted invoker-first/domain-owner/audit boundary. **References:** Phase 2.14.4 conflict inventory C-01–C-13; Phase 2.14.5 evidence boundary.

### Medium

1. **M-01 — Team policy/payment interaction needs new semantics.** Existing one-team/capacity/leader invariants remain; old roster-lock trigger point is not automatically valid for per-person payment. **References:** D-014/D-015; Phase 4.1 §5; Phase 2.14.5 M-01.
2. **M-02 — Account lifecycle and consent need operational detail.** Email change, unverified account cleanup, deletion, retention and privacy requests are not specified. **References:** Phase 4.1 §§2, 6; Phase 2.14.5 M-05.
3. **M-03 — Public/admin content model is incomplete.** Domains, prizes, FAQs, event settings and venue publication need a decision between static launch content and authorized content management. **References:** Phase 4 readiness §4 rows 8–9.
4. **M-04 — Auth callback/configuration alignment remains.** Local redirect settings and hosted configuration must be deliberately reconciled before the Auth client goes live. **References:** Phase 4 readiness §3.
5. **M-05 — Existing view, alias and call-site compatibility requires complete traceability.** The proposed 79/30/18 inventories are reconstructed, and aliases/external callers are not fully evidenced. **References:** decision register D-020–D-024; Phase 2.14.5 H-01/H-04.
6. **M-06 — Independent payment runtime is an operational trust boundary, not yet validated.** Need credential separation, worker deployment, monitoring, incident response and provider reconciliation decisions. **References:** D-005; Phase 2.14.5 H-03/H-07.

### Low

1. **L-01 — Documentation status can be misread.** Older architecture/RLS docs and the detailed SQL are more concrete than the newer direction; each should be clearly treated as historical/unexecuted in a future documentation reconciliation. **References:** implementation conflict inventory C-16; D-028.
2. **L-02 — Missing original source documents limit exact historical traceability.** The surviving 2.14.4 document is explicit about this limitation; do not describe reconstructed matrices as recovered approvals. **References:** architecture evidence boundary; Phase 2.14.3 review.

## 7. Exact feasibility tests required

All tests below are **future approval-gated tests**. None has passed by this review. Prepare a test package with object names, expected catalog state, negative assertions, transaction boundaries and cleanup before requesting approval. Use only the disposable project explicitly identified in the approved validation plan; verify its reference immediately before each operation. Never target production.

### Gate 0 — Read-only target and baseline

- Confirm disposable project reference through the locally linked project metadata and an independently read-only remote identity query; stop if either disagrees.
- Record CLI version, PostgreSQL version, database `session_user`/`current_user`, migration history, role attributes/membership graph including grantors and ADMIN/INHERIT/SET, schema/database privileges, relevant object collisions, and Auth/PostgREST role availability.
- Record outputs in sanitized form; no secrets. Compare with the last preflight and stop on unexpected objects, privilege changes, target ambiguity, or drift.
- This gate is read-only but any remote query still requires its own authorization and target pinning; this Phase 4.2 review did not execute it.

### Gate 1 — Actual migration identity and ownership lifecycle

Requires explicit approval for disposable database mutation. A CLI authentication identity or dry run is not proof of database identity.

1. Through the exact intended migration command and credential route, execute a narrowly scoped, reversible identity probe that records CLI route separately from database `session_user`, `current_user`, and resulting object owner. The probe itself creates a uniquely named disposable object and changes migration history only if implemented as a migration; document this before approval.
2. Create isolated NOLOGIN domain-owner test roles with required negative attributes; verify no superuser, CREATEROLE, BYPASSRLS, table/schema ownership, or unrelated role membership.
3. Grant only the minimum schema access needed for function creation/ownership and verify both direct and effective privileges. Demonstrate API and runtime identities cannot become members or `SET ROLE` to an owner; inspect all membership grantors/options.
4. Migration operator creates a disposable function under initial operator ownership; transfer it to the NOLOGIN domain owner. Verify owner and ACL.
5. As migration operator, attempt a subsequent `CREATE OR REPLACE FUNCTION` on the domain-owned function; record expected denial unless an explicitly temporary mechanism is in place.
6. Test a bounded, narrowly scoped JIT privilege path: grant only required membership/SET or equivalent ownership authority, replace function, revoke immediately, and verify role membership/schema grants return to baseline. Do not grant permanent broad CREATEROLE, schema CREATE, owner membership, or API access to make the test pass.
7. Run a second migration using the intended operator; verify it can make only the approved change and that function owner, privileges, memberships and schema grants remain correct. Test interruption after grant and before revoke, and demonstrate recovery without broad cleanup.
8. Test failed transactional migration and partial nontransactional/externally committed steps; verify migration history and catalog state, rollback/recovery and whether project discard is safer.

**Pass condition:** one documented route performs initial creation and later replacement with least privilege, cleanup is independently verifiable, and every failure stage is recoverable. If no such route works, change architecture/migration model before SQL implementation.

### Gate 2 — Runtime identity and API-role isolation

For every final named system runtime (names must come from an approved manifest; do not infer them), separately test:

- login through its intended connection route and pooler mode; record `session_user`/`current_user` under autocommit and transaction use;
- no `SET ROLE` required; `SET ROLE` to domain owners and other runtimes denied;
- no direct application table/sequence access except explicitly approved entries;
- only its exact schema/function allowlist is executable; PUBLIC/anon/authenticated and unrelated runtime roles are denied;
- no owner role can be assumed through direct/transitive membership or ADMIN/SET option;
- a test invocation accesses only its domain and fails closed without required authenticated context;
- credential is independently stored/rotated/revoked, not exposed to browser or shared as an undocumented project-wide secret.

Test each login independently. One successful runtime is not evidence for another. Verify API roles `anon`, `authenticated`, `authenticator`, and `service_role` cannot assume any function-owner or system role.

### Gate 3 — Auth, RLS, invoker/definer and view boundaries

Using disposable test users and fabricated non-production records:

- verified JWT user A can read/write only allowed own profile/registration; user B cannot access them by direct table, view, RPC, altered ID or relationship traversal;
- missing, invalid, expired, unverified or conflicting JWT context is denied as specified; browser actor IDs and editable role metadata do not grant access;
- team member sees only approved roster fields; nonmember cannot see private team data; leader-only operations fail for nonleaders; concurrent operations preserve capacity and one-team/one-leader invariants;
- `auth.uid()`, `auth.role()`, `session_user` and `current_user` are observed for PostgREST invoker calls, Edge-forwarded user JWT calls, definer functions, triggers, direct custom logins and pooled connections;
- test owner-specific FORCE RLS policies and prove owner is not table/schema owner, superuser or BYPASSRLS; attempt cross-user reads/writes as adversarial owner principal;
- test nested invoker/definer calls, trigger execution identity, fixed search path, schema-qualified names and hostile same-name objects; API caller must not alter a session setting to forge actor context;
- for each exposed view, test underlying grants/RLS as invoker and inspect output columns; cross-domain projections that cannot safely be invoker-scoped must be inaccessible directly and use the approved narrow boundary;
- test no API can insert/update/delete canonical audit rows or execute internal audit writer directly.

### Gate 4 — Audit identity and atomicity

- Run successful and rejected user operations and assert trigger-generated audit actor is the verified user only when JWT context is valid.
- Run system and webhook operations and assert actor type/identity derives from the independently authenticated workload, not a passed ID, boolean, digest, or custom GUC.
- Attempt to forge actor parameters/GUCs, reuse pooled sessions, invoke triggers through alternative paths, and write audit rows directly; expect denial or fixed trusted workload attribution.
- Force a constraint/business failure after a trigger would write audit; verify the business row and audit event both roll back. Retry a successful operation and ensure one canonical event, not duplicate RPC+trigger events.
- Verify event allowlists and metadata minimization; no secret, full row, or unnecessary personal information is recorded. Score edit history is append-only; team discussion body is not copied into audit while edit/delete/moderation/emergency access metadata is recorded.
- If protection against privileged database/admin compromise is required, separately test/plan external immutable log retention; a database trigger cannot defend against an actor with DDL privileges.

### Gate 5 — Team concurrency and lifecycle

- Race simultaneous team creation and joins for the same participant; race multiple invitation acceptances at the capacity boundary; race removal/transfer/dissolution; race payment initiation against roster changes.
- Assert 2–5 including leader, one active team per participant, exactly one active leader, policy version pinning, valid invitation transitions, and idempotent retries.
- Check every transaction rollback leaves no partial invitation, membership, leader, notification or audit state. Confirm explicit lock order and safe retry behavior.
- No payment-triggered team lock rule is accepted until a product rule for individual payments is decided.

### Gate 6 — Future individual payment and outbox, no real provider

Only after fee/provider and payment-gating decisions; use a fake provider/test harness with no real gateway credentials or live charges.

- Ensure each payment obligation/order is tied to one participant and correct event-registration context; participant A's paid event cannot alter participant B.
- Verify fee snapshot amount/currency and immutable version; changing fee leaves existing orders unchanged.
- Verify signature processing uses exact raw-body bytes in the worker; database validates participant/order/amount/currency and state independently. Reject forged boolean, ordinary actor ID, event digest alone or unverified call.
- Deliver duplicate, delayed, replayed and out-of-order event IDs; assert one financial transition/audit outcome and correct no-op/reconciliation behavior.
- Race retries/order creation/refund requests; enforce per-participant uniqueness policy and serialized cumulative refund cap. Verify receipt only after successful payment; failed/partial refunds preserve history.
- Simulate worker crash before provider call, after provider success but before acknowledgement, lease expiry, retry, dead letter, reconciliation and duplicate delivery. External call must occur after DB commit and outside lock-holding transaction.
- Assert registration submit, team leader payment and teammate status cannot mark participant paid. No fake payment-success UI or DB state is acceptable.

### Gate 7 — Recovery, monitoring, and cleanup

- Inject failures at role creation, grant, ownership transfer, function replace, post-grant/pre-revoke, subsequent migration and cleanup. Record transactionality, persistent effects, detection query, safe recovery, and project-discard threshold for each.
- Ensure cleanup drops only uniquely named test fixtures created by the test after verifying ownership/identity. Never use broad schema/role drops or wildcard cleanup. Recheck catalog and migration history against baseline; if clean recovery cannot be proven, discard/recreate the disposable project under explicit authorization.
- Capture sanitized evidence and independently review results. No test result automatically authorizes production or detailed migrations.

## 8. Minimum secure backend implementation sequence

This sequence is conditional on the gates above; it is not implementation authorization.

1. Ratify product/architecture reconciliation: individual registration and payment, team-payment interaction, registration approval/eligibility, and admin role boundaries.
2. Obtain or explicitly ratify the reconstructed 79-operation, 30-view, and 18-helper/trigger inventories; keep all compatibility aliases until callers are verified.
3. Complete exact threat/permission manifests: every function caller, verified actor source, owner, EXECUTE grant, columns/tables, RLS policy, nested calls, locks, audit event and idempotency rule; every view projection and every helper/trigger owner.
4. Complete feasibility gates 0–4 in disposable project, including migration lifecycle, runtime identities, Auth/RLS, definer/view, and audit actor tests; independent security review approves evidence.
5. Define the minimum launch scope and migration dependency graph. Establish schemas/constraints and protected identity first; then profile and individual registration; then team/invitation transactions; then submissions; then published content/admin authorization; then audit/outbox mechanisms. Payment is a later separately gated slice and must be participant-level.
6. Draft migrations only after gates pass, with repeatable migration history, failure/recovery plan, and review of exact ACL diffs. Do not use the existing SQL draft as-is.
7. Run disposable functional, negative-security, concurrency and failure-injection tests; obtain independent review before any production authorization decision.

## 9. Conditions to change NO-GO

The NO-GO decision changes only when all applicable conditions are met and documented:

1. Phase 4.1 decisions are incorporated into a reviewed authoritative architecture and decision register; D-015/D-023 are explicitly superseded and team/payment interactions are settled.
2. Registration eligibility, approval, withdrawal, payment activation and three admin role boundaries are explicit enough to define state transitions and authorization.
3. Recovered function/view/helper matrices are ratified or replaced by a traceable, reviewed complete manifest; no missing signature, alias, caller, owner, grant, RLS predicate or sensitive projection is inferred.
4. Actual migration identity and a repeatable least-privilege ownership/replacement/revoke/recovery lifecycle pass in the disposable project.
5. Every runtime login/route, API-role exclusion, pooler identity, `SET ROLE` denial and domain function allowlist passes independent tests.
6. User JWT identity, system/webhook actor binding, audit trigger identity and atomic rollback/append-only controls pass positive and adversarial tests.
7. Team concurrency, user data isolation, admin separation, view boundaries and future payment idempotency/refund invariants pass the relevant disposable tests.
8. No unresolved Critical or High finding remains; independent reviewer signs off. Production migration remains a separate approval gate.

## 10. Recommendation and single next phase

**NO-GO.** Phase 4.1 product decisions are compatible with the core identity/RLS architecture, but they supersede stale team-payment/free-registration assumptions that remain in the decision register and SQL proposal. Identity binding, audit authenticity, domain-owner/RLS boundaries, migration identity and function replacement, runtime isolation, exact grants, and complete operation manifests remain unresolved. No feasibility test has passed in this review.

**Recommended single next phase: Phase 4.3 — Product and Architecture Reconciliation with Disposable Test Package.** Update the authoritative decision/specification set to reflect individual participant payments and the confirmed registration journey; resolve only the remaining product choices needed for the first launch; create one exact, independently reviewable, disposable-only test package for Gates 0–7 with expected assertions, cleanup and approval boundaries. Stop at the package and request explicit approval before any database-changing probe. This is the shortest safe path to evidence; it does not begin backend implementation.
