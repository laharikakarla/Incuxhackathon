# Phase 2.7 — RPC Role Ownership Prerequisite Audit

**Review type:** static inspection of the Phase 2 SQL/design and the Phase 2.6 disposable validation package. No SQL was executed, no Supabase project was contacted, and no runtime compatibility is claimed.

## Scope

This audit covers only H6 ownership prerequisites:

1. Schema `CREATE` ordering before view and function ownership transfers.
2. Explicit migration-operator membership and `SET ROLE` validation.
3. Owner function/view privileges and later migration sequencing.

## Corrections made

### 1. Schema `CREATE` ordering

In `docs/database/phase-2-schema-draft.sql`, the authorization contract now creates the RPC owner with restricted role attributes. Immediately before the safe-view `ALTER VIEW ... OWNER TO` statements, it temporarily grants `CREATE` on `public` and `private`; it revokes those privileges immediately after the view transfers. Before the final dynamic function-owner transfer, it temporarily grants schema `CREATE` again and revokes it immediately afterward. Thus the role does not retain schema `CREATE` at runtime.

### 2. Migration operator membership

The SQL draft now explicitly grants the migration operator membership in `incux_rpc_owner` with `SET TRUE`, `INHERIT FALSE`, and `ADMIN FALSE`. It checks that the operator can `SET ROLE`, does not inherit the owner privileges, and that `anon`, `authenticated`, and `service_role` cannot set the owner role. The intended database must be PostgreSQL 16 or later for per-membership options; the SQL design stops on older versions instead of falling back to an inheriting grant.

### 3. Subsequent migration sequence

The architecture, RLS matrix, security review, and Phase 2.6 runbook now specify the later-migration operation:

1. The intended migration operator temporarily grants schema `CREATE` to `incux_rpc_owner`.
2. The operator uses `SET ROLE incux_rpc_owner` to update objects owned by that role.
3. The migration resets to the operator identity.
4. It revokes the temporary schema `CREATE` grant.

The operator's `SET` membership remains non-inheriting and non-delegable so this sequence can be repeated without giving client roles membership. The operator must also have authority to grant and revoke the schema privilege; this is a target-project prerequisite to validate.

The Phase 2.6 SQL validation package and runbook were aligned with this sequence. Their default project-ref/operator placeholders remain fail-closed and they have not been run.

The privilege rules are based on PostgreSQL's documented requirements: ownership transfer requires the operator to own the object, be able to `SET ROLE` to the new owner, and give that owner `CREATE` on the schema; role membership can separately control `SET`, `INHERIT`, and `ADMIN` on PostgreSQL 16+. See [ALTER FUNCTION](https://www.postgresql.org/docs/current/sql-alterfunction.html), [ALTER VIEW](https://www.postgresql.org/docs/current/sql-alterview.html), [GRANT](https://www.postgresql.org/docs/16/sql-grant.html), and [role membership](https://www.postgresql.org/docs/16/role-membership.html). Supabase documents custom-role ownership/migration issues in [Managing Environments](https://supabase.com/docs/guides/deployment/managing-environments); that guidance does not validate this specific design or project.

## Files updated

- `docs/database/phase-2-schema-draft.sql`: restricted role attributes, PostgreSQL version guard, operator membership grant/assertion, temporary view and function transfer schema privileges.
- `docs/database/phase-2-architecture.md`: migration ownership sequence and compatibility gate.
- `docs/security/phase-2-rls-matrix.md`: owner membership and temporary privilege boundaries.
- `docs/security/phase-2-security-review.md`: Phase 2.7 correction note and privileged-function boundary.
- `docs/security/phase-2.4-correction-log.md`: follow-on correction record while preserving the prior Phase 2.4 history.
- `docs/security/phase-2.6-validation-runbook.md`: revised prerequisite and validation instructions.
- `scripts/validation/phase-2.6-role-validation.sql`: now checks PostgreSQL 16+, constrained membership, separate temporary schema-grant windows, and owner transfer sequence.

## Static self-audit

- [x] RPC role is `NOLOGIN`, `NOINHERIT`, `NOSUPERUSER`, `NOCREATEDB`, `NOCREATEROLE`, `NOREPLICATION`, and `NOBYPASSRLS` in the proposal.
- [x] No `anon`, `authenticated`, or `service_role` membership in the RPC owner is proposed; SQL asserts this.
- [x] Migration operator membership is explicit and limited to `SET TRUE`, `INHERIT FALSE`, `ADMIN FALSE`.
- [x] The SQL asserts that only the intended operator can `SET ROLE` and does not inherit owner privileges.
- [x] Temporary schema `CREATE` precedes all view owner changes and is revoked immediately after them.
- [x] Temporary schema `CREATE` precedes the function owner-transfer loop and is revoked before RPC execute grants.
- [x] SQL assertions reject residual `CREATE` on `public` or `private` after each transfer window.
- [x] Later-migration grant / `SET ROLE` / `RESET ROLE` / revoke sequence is documented.
- [x] Phase 2.6 validation package uses a PostgreSQL 16+ guard and reflects the new ownership order.
- [x] Phase 2.6 package has not been executed as part of this audit; no SQL parser or database result is claimed.
- [ ] Supabase target operator support for `CREATEROLE`, per-membership options, schema grants, `SET ROLE`, view/function ownership, and later migrations remains to be manually confirmed.
- [ ] PostgREST view access and forced-RLS behavior under the new owner remain to be manually tested in the disposable target.

## Remaining risks and manual gate

This correction resolves the two source-level prerequisites, but it does not establish Supabase compatibility. The exact target project's PostgreSQL version and migration identity are unknown. The proposed SQL now deliberately stops below PostgreSQL 16; any alternate membership approach requires separate security review. The migration operator must also be able to grant/revoke schema `CREATE` and execute `SET ROLE` at both initial and later migration time. The final function loop still targets every function in `public` and `private`; use a clean disposable project and scope any later implementation to reviewed objects.

Before any migration work, complete the manual checks in [phase-2.6-validation-runbook.md](phase-2.6-validation-runbook.md) against a disposable project matching the intended environment. Do not test first in production, grant superuser or `BYPASSRLS`, or treat static success as runtime proof.

## Decision

# H6 DESIGN PREREQUISITES CORRECTED — TARGET VALIDATION STILL REQUIRED

The SQL and documentation now state a coherent privilege sequence and explicit operator-membership contract. H6 is **not resolved** until disposable Supabase validation passes for the actual intended operator and project version. No readiness or production-compatibility claim is made.

## Phase 2.8 superseding correction note

The Phase 2.7 report's claim that the migration operator has a non-delegable `ADMIN FALSE` membership is superseded. PostgreSQL 17 automatically gives a non-superuser CREATEROLE creator a bootstrap `ADMIN TRUE`, `SET FALSE`, `INHERIT FALSE` membership in a role it creates, and that creator cannot remove it. The corrected design accepts this ADMIN path only for the trusted migration operator, adds a separate explicit `SET TRUE`, `INHERIT FALSE`, `ADMIN FALSE` membership path, and rejects all API-role membership/ADMIN capability. The validation now exercises ownership in both `public` and `private`, verifies API table/column privileges, and pins/manual-confirms the disposable project ref. See [Phase 2.8 correction log](phase-2.8-correction-log.md) and [Phase 2.8 audit report](phase-2.8-audit-report.md). No runtime compatibility is claimed.
