# AICUXORA 2027 — Phase 4.10 Autonomous Security Audit & Implementation Readiness

**Audit date:** 2026-11-14 (Asia/Calcutta)  
**Scope:** Offline repository review and local frontend quality checks.  
**Decision:** **NO-GO for backend implementation, SQL drafting/application, migrations, or database-changing validation.** The public site and portal previews pass the available local checks, but the accepted security architecture and individual-payment product decision are not yet represented by an implementation-ready, validated database design.

## 1. Executive summary

The repository contains a working React/TypeScript/Vite public website and student/admin **previews**. Its routes, branding and honest “not connected” states are present. It has no Supabase application client, no authentication integration, no migrations directory, and no connected persistence. The student and admin screens must therefore continue to be described as previews. In particular, `/student/*` and `/admin/*` are not access-controlled routes; they are not suitable for real personal or administrative data.

The largest implementation blocker is architectural drift: the accepted architecture prefers authenticated `auth.uid()` + RLS, narrow domain-specific owners only where necessary, isolated system identities, trigger-owned audit, and a separate payment runtime. The legacy SQL draft still proposes a universal `incux_rpc_owner`, broad table/sequence privileges, broadly `SECURITY DEFINER` functions, broad RLS bypass settings, service-role application calls, public views without `security_invoker`, and team-level payment orders. It is a design artifact, not an approved implementation source.

The product decision is individual registration with later **per-participant** payment. This conflicts with the SQL draft’s team payment model and older decision-register items. Registration must never imply payment; one participant’s payment must not change a teammate’s status. Fee, provider, venue, registration eligibility/approval, and several lifecycle rules remain open.

The operator-reported Command 2 result is useful evidence for that diagnostic query only: the validation project query ran as `supabase_read_only_user` against PostgreSQL 17.11. It does not identify the migration operator or object owner. Command 3’s role inventory has not been executed. The migration identity, domain-owner replacement lifecycle, runtime role feasibility, and audit actor trust remain unverified. No Supabase access or database operations were performed for this audit.

## 2. Scope, method and boundaries

Reviewed the current repository structure; React routes/components and forms; package scripts/configuration; local Supabase configuration; database SQL proposal; Phase 2.14.4 authoritative architecture, decision register and conflict inventory; Phase 2.14.5 independent audit; Phase 4 readiness, registration decision and security review; and Phase 4.9 baseline/Command 3 preparation.

Static source counts in the legacy SQL draft: 79 public function definitions, 30 public views, 18 private function definitions, 30 triggers and 61 policies. These counts describe the local draft only; they do not establish which objects exist in any hosted database. The 79/30/18 matrices in the recovered Phase 2.14.4 documents are proposed reconstructions; missing historical specifications prevent treating every row as recovered, independently approved original behavior.

Local quality checks were run from the repository:

| Check | Command | Result |
|---|---|---|
| TypeScript | `npm run typecheck` | Exit 0 |
| ESLint | `npm run lint` | Exit 0 |
| Production build | `npm run build` | Exit 0; TypeScript build and Vite production bundle completed |

Vite emitted a bundle-size warning: the main minified JavaScript chunk is approximately 596.93 kB (182.64 kB gzip), above its 500 kB advisory threshold. This is a performance improvement item, not a build failure. No dependency installation, tests, browser session, Supabase command, SQL, migration, or database connection was run for this report. Prior Phase 3 QA documentation says browser console, actual rendering, and 320px layout checks remain unverified; this report does not claim those checks passed.

No application source, SQL draft, configuration, or existing documentation was changed. This report is the only file created for Phase 4.10. Existing uncommitted files were preserved.

## 3. Repository and implementation status

| Area | Repository evidence | Status / consequence |
|---|---|---|
| Public event website | `src/pages/public/Pages.tsx`, public layout and shared components; exact company logo in `public/assets/brand/incux-ai-logo.jpeg` | Implemented locally; confirmed product facts and visibly tentative details are represented. Browser/visual QA is not established by this audit. |
| Routes | `src/app/router.tsx` | Public routes include home, about, domains/tracks, timeline, prizes, evaluation, rules/FAQ, community, contact, login/register and auth-state pages. Student and admin route trees are also present. Wildcard route handles unknown paths. |
| Student portal | `src/pages/PortalPages.tsx`, `PortalLayout.tsx` | Preview only: dashboard contains no real records; profile inputs are disabled; team, invitations, announcements, submissions and account recovery are not persisted. |
| Admin portal | `src/pages/PortalPages.tsx`, `router.tsx`, `PortalLayout.tsx` | Preview only: student/admin routes are reachable without authentication; this is explicitly disclosed in the UI. No role enforcement or admin operation exists. Do not enter real data. |
| Authentication | Public registration/login/recovery components; no Supabase client SDK dependency or `createClient` usage found | Client-side validation and preview notices only. No account creation, email verification, sign-in, session, recovery token validation or authorization. |
| Backend integration | `package.json`, `src/`, `supabase/` | Supabase CLI is a development dependency; `@supabase/supabase-js` is absent. Query-client provider presence is not backend connectivity. |
| Migrations | No `supabase/migrations` directory | No deployable migration history/workflow in the repository. A SQL draft is not a migration. |
| Local Supabase configuration | `supabase/config.toml` | Contains local project identifier `incuxai-hackathon` and Auth URLs on port 3000; Vite convention is 5173. This is not evidence of hosted project settings. Reconcile callback URLs before real Auth integration. Email confirmation is disabled in the local configuration, while the confirmed product requirement says verification is required; validate and deliberately configure the local/hosted distinction before enabling Auth. |
| Database design | `docs/database/phase-2-schema-draft.sql` | Proposed, unexecuted, and in conflict with later accepted security/product decisions. Not implementation-ready. |

The portal layout explicitly says there is no sign-in, role check, database, or saved data. Disabled actions and empty states avoid fabricating student records/statistics. This is appropriate for a preview; it is not a substitute for server-side authorization.

## 4. Security architecture consistency review

| Requirement | Accepted direction / current evidence | Finding |
|---|---|---|
| User identity | Verified JWT and `auth.uid()`; no caller-supplied user ID as proof | UI has no auth flow. SQL functions and actor/audit details require rework/review against this rule. |
| Individual registration | One participant submits their own event registration; submission is distinct from payment | Product decision is clear. The draft’s registration/payment lifecycle is not the approved representation. Eligibility, approval, duplicate/withdrawal rules remain unresolved. |
| Individual payment, later phase | Separate state per participant; no inference from a leader or teammate | Draft has `team_fee_config_versions`, `team_payment_orders`, payer/team relationship and a one-pending-or-paid-order-per-team index. This is a direct conflict. Do not adapt or deploy it as-is. |
| Teams | Current product rule is 2–5 members | Draft’s transactional team invariants need a new review in context of individual registration/payment. Do not mechanically retain payment-triggered roster locks. |
| Roles and function ownership | No universal RPC owner; prefer invoker + RLS; narrowly owned definer functions only where justified | Draft creates `incux_rpc_owner` (`phase-2-schema-draft.sql:1021`) and grants broad table and sequence privileges (`:1027` onward). This conflicts with the accepted architecture. |
| RLS and function security | Least privilege; nonrecursive helper design; exact grants | Draft has 96 `SECURITY DEFINER` occurrences and 96 `row_security = off` occurrences (static text counts). Every function/helper must be individually reclassified; global patterns are not evidence of safe enforcement. |
| Views | `security_invoker` where underlying grants/RLS make it safe; otherwise narrow server-side projection | Draft has 30 `security_barrier=true` public views and no `security_invoker` option. A barrier is not a replacement for caller-context RLS. Each view needs an explicit column/data-boundary review. |
| System identities | Separate, constrained identities only after hosted route validation; no routine `service_role` for app transactions | Draft grants sensitive RPC use to `service_role` and checks its role in code. This is not the selected least-privilege model. Custom login/pooler capabilities remain untested. |
| Payment webhook | Independent payment runtime, verified event processing, database-side integrity/idempotency | Draft’s `payment_record_verified_webhook` is callable in the legacy service-role model. A parameter or Edge assertion is not proof of signature verification. Worker authentication and DB authorization need a validated trust path. |
| Audit | Trigger-owned, append-only trusted events, atomic with business state | Draft contains 71 direct `INSERT INTO public.audit_log` text occurrences. Direct caller/function writes risk duplicate or fabricated records and conflict with the trigger-owned direction. Actor authenticity through triggers is still a blocker. |
| Outbox | Transactional outbox; external calls after commit, not while a DB lock is held | No explicit outbox table/model was found in the SQL draft (`outbox` search yielded no matches). Notification/webhook functions are not proof of an atomic outbox. |
| Admin permissions | Super Admin and delegated admins enforced in the database | UI is not guarded, as disclosed. Draft role checks and privilege assignment need explicit protected storage, transitions, last-Super-Admin protection and an audited authorization model. |
| Recruiter/judge/private data | Consent and assignment bound to current state; scores confidential until authorized release | The legacy draft requires per-object review; no actual deployed policies or runtime proof exist. Do not expose these features through the preview or views until reviewed. |
| Certificates | Unpredictable server-side verification with privacy-safe projection and abuse controls | Draft and docs need implementation-level proof of non-enumerability, rate limits, revocation and no personal-data leakage. No hosted implementation exists. |

The local draft is a legacy proposal, not a security boundary. RLS being enabled, a function having a `SECURITY DEFINER` label, or a hidden frontend control does not prove safe access. The accepted architecture remains a design direction with unresolved actor binding, function-owner privileges, audit trust, runtime isolation and migration lifecycle.

## 5. Phase 4.9 Command 2 evidence and Command 3 review

### Command 2: recorded operator evidence

The operator supplied evidence that the read-only identity/version query succeeded against `incuxai-hackathon-validation` (`bhnhhaurdnnalcozsviq`). The CLI displayed environment label `production`; the operator also reported the Dashboard’s validation `main` branch label as `PRODUCTION`. These labels do not change the explicitly supplied project reference and do not make it the separate production project. The production reference remains prohibited and was not accessed in this audit.

| Field | Recorded result |
|---|---|
| `database_name` | `postgres` |
| `session_user` | `supabase_read_only_user` |
| `current_user` | `supabase_read_only_user` |
| `server_version` | `17.11` |
| `server_version_num` | `170011` |
| CLI exit status | `0` |
| Capture time | 2026-11-13, approximately 18:24 local time (UTC+05:30), from operator screenshot description |
| Execution route | Authenticated interactive PowerShell; temporary SQL file; explicit `--remote=bhnhhaurdnnalcozsviq`; `--read-only`; telemetry disabled for the invocation and restored |

This is operator-reported screenshot evidence; the screenshot itself was not present in the repository during this review. It proves the identity and version observed for that diagnostic query, not the CLI login identity, migration session identity, object owner, or identity used by a future migration. Do not equate `supabase_read_only_user` with the migration operator.

### Command 3: exact SQL proposed, not executed

Phase 4.9 Command 3 is two independent read-only catalog queries. It remains unexecuted and needs fresh operator review/approval per query; Command 2 approval did not authorize it.

**Command 3a — visible role attributes:**

```sql
SELECT rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb,
       rolreplication, rolbypassrls, rolcanlogin, rolconnlimit
FROM pg_catalog.pg_roles
ORDER BY rolname;
```

**Command 3b — direct membership edges:**

```sql
SELECT member_role.rolname AS member_role,
       granted_role.rolname AS granted_role,
       grantor_role.rolname AS grantor_role,
       m.admin_option, m.inherit_option, m.set_option
FROM pg_catalog.pg_auth_members AS m
JOIN pg_catalog.pg_roles AS member_role ON member_role.oid = m.member
JOIN pg_catalog.pg_roles AS granted_role ON granted_role.oid = m.roleid
JOIN pg_catalog.pg_roles AS grantor_role ON grantor_role.oid = m.grantor
ORDER BY member_role.rolname, granted_role.rolname, grantor_role.rolname;
```

The SQL is read-only SELECT against PostgreSQL catalogs and is syntactically appropriate for PostgreSQL 17, including `inherit_option` and `set_option` in `pg_auth_members`. Command 3a shows returned role attributes; it does not show memberships or effective privileges. Command 3b reports direct edges: `member_role` receives membership in `granted_role`. It includes grantor and `ADMIN`, `INHERIT`, and `SET` options, but does not itself calculate transitive reachability, effective privileges, or prove that catalog output is complete. Missing output rows cannot be treated as proof that a role or edge is absent unless visibility/completeness is established.

The Phase 4.9 command sheet passes a multiline PowerShell here-string as a positional `$sql` argument. That transport previously produced PostgreSQL syntax error 42601 (end of input) for Command 2. Do not use that form for the next attempt. The SQL need not change; use the documented CLI `--file` route with a unique temporary file, explicit validation ref, and `--read-only`. Run in the same authenticated interactive PowerShell window that successfully listed projects. Keep telemetry disabled only for the invocation and restore its previous process value in `finally`; initialize the exit code before invocation, check it, remove the file in `finally`, and verify the CLI output resolves to the exact validation ref before treating results as evidence. Use the independently prepared file-based form for each query and require fresh approval before executing either one. This review neither ran nor authorized a query.

**Risks and limits:** CLI project-name labels such as `production` are not a replacement for the exact reference check. `--read-only` protects against accidental query mutation but does not establish the caller’s identity or query-result completeness. The operator must preserve full sanitized output, timestamp, exact target ref, exit code, and the command/SQL used. Do not include tokens, connection strings, or credentials in evidence.

## 6. Findings by severity

### Critical

1. **No approved implementation database or validated migration route.** Migration identity, new-object ownership, ability to transfer ownership, later replacement of domain-owned functions, temporary privilege revocation and partial-failure recovery are unknown. A read-only query identity is not migration evidence.
2. **Confirmed payment model conflicts with legacy schema.** Product decision is individual registration and later per-participant payment. Draft fee/order tables and uniqueness rules are team-scoped. Implementing them risks one participant’s payment changing or representing another participant’s obligation.
3. **Actor/audit authenticity is not established.** The accepted trigger-only audit approach still lacks a proven unforgeable mapping from authenticated user/system/webhook action to trigger context. Draft direct audit inserts increase fabrication/duplication risk.
4. **Frontend student/admin routes have no real authentication or authorization.** They are clearly labeled previews, but must not receive production or personal data. Adding persistence before database-side access control would expose sensitive student/admin operations.

### High

1. **Legacy universal owner and broad grants contradict accepted least privilege.** The draft grants `incux_rpc_owner` broad public-table and sequence permissions and uses broad definer patterns; replace only through a newly specified/reviewed design, not an ad hoc migration.
2. **Service-role and custom runtime trust boundaries remain unresolved.** Existing draft service-role calls conflict with the selected independent worker/domain identity model. Login route, pooler behavior, role assumption denial and runtime credential isolation require disposable-project evidence.
3. **View/RLS boundaries are not reconciled.** Thirty public views lack `security_invoker`; sensitive recruiter, judge, payment, team-private and aggregate data need per-view projection decisions and exact underlying grants.
4. **No explicit transactional outbox found.** External operations could be lost, duplicated or performed inside transaction/lock windows without an outbox and retry/idempotency design.
5. **Command 3 role inventory remains unexecuted.** The historical membership CSV lacks current query/target/time provenance. Role graph assumptions remain incomplete.
6. **Auth configuration mismatch and email verification setup.** Local callback URL uses port 3000 while Vite uses 5173; local config disables email confirmation while product requires verification. Hosted settings are unknown; resolve deliberately before enabling Auth.

### Medium

1. **The production bundle has an oversized chunk warning.** Consider route-level lazy loading/code splitting after backend/security work is unblocked; current build succeeds.
2. **Browser and responsive verification is incomplete.** Especially 320px layout, browser console, keyboard flow, contrast, focus and real screen-reader behavior. Static CSS and semantic markup cannot prove rendered usability.
3. **Role/view/helper matrices are reconstructed.** Restore original function/view/helper specifications or have product/security owners explicitly approve the reconstructed 79/30/18 inventories before implementation.
4. **Registration and event business rules remain incomplete.** Eligibility, approval, duplicate registration, withdrawal/reopen and launch sequencing need product decisions.
5. **No automated test script is configured.** Typecheck/lint/build do not establish behavior. Add focused tests only when requested/authorized and once interfaces are settled.

### Low

1. Provide provenance-backed source screenshots/direct output for the Command 2 observation in the evidence archive, without including secrets.
2. Keep preview labels visible and avoid UI wording that could be read as successful registration, verification, payment, or secure admin execution.

## 7. Five recommended next actions

1. **Complete read-only Command 3a role attributes** in the operator’s authenticated PowerShell, after fresh approval. Use a temporary SQL file, exact disposable reference, `--read-only`, capture target/UTC+local time/exit status, and stop if the resolved ref differs.
2. **Review its output before separately approving Command 3b.** Interpret memberships in the correct direction and preserve incomplete visibility as unknown; derive transitive paths only from a sufficiently complete graph.
3. **Close the product/schema conflict in documentation first.** Supersede stale per-team payment/free-registration decisions with the Phase 4.1 product model, then commission a fresh independent reconciliation of registration, individual payment states, refunds, webhook identity, idempotency, receipts and team interaction. Do not patch or execute the legacy SQL ad hoc.
4. **Resolve migration and trusted-identity design before mutations.** Specify the real migration route and temporary ownership-replacement lifecycle, user JWT binding, system/webhook authentication, trigger audit identity, exact grants, RLS and outbox. Then independently review a disposable-only experiment manifest with narrowly scoped approval gates.
5. **Only after architecture and validation gates are met, implement Auth/backend in dependency order.** First settle Auth redirects/email verification and identity/profile/RLS; then individual registration and team invariants; content/submissions; admin permissions/audit; later, independently isolated individual payment/webhook/refund and outbox. Keep every feature disabled until its server-side enforcement is validated.

## 8. Prioritized implementation roadmap and gates

| Order | Work | Required evidence/gate |
|---:|---|---|
| 1 | Approve reconciled product/security requirements and recover complete 79-function, 30-view, 18-helper/trigger baseline | Traceable decisions; independent security review; no stale per-team/free-registration rule treated as current |
| 2 | Read-only disposable catalog baseline (including Command 3, one query at a time) | Explicit project ref; provenance and completeness limits recorded; fresh operator approval for each query |
| 3 | Validate migration execution/ownership lifecycle in disposable project | Actual migration session identity, object owner, domain owner transfer, subsequent replace, temporary privilege revoke, failure recovery; specific mutation approval for each test |
| 4 | Validate runtime identities, pooler, JWT/user context, definer/RLS nesting and trigger audit identity | Positive and negative tests; no API/runtime path can assume owners; audit actor cannot be forged by ordinary callers |
| 5 | Draft/review migration specification and secure core identity/profile policies | Schema/function/view grants line up with accepted architecture; no universal owner or broad service-role access |
| 6 | Implement and validate account verification, profile and individual registration | `auth.uid()` ownership; lifecycle transitions, duplicate/withdraw rules; no payment side effects |
| 7 | Implement team membership/invitations and content/submission workflows | Atomic capacity/leader/one-active-team invariants; authorization, audit, state/version rules |
| 8 | Implement admin roles, permission transitions and append-only audit | Last Super Admin protection, trusted actor, tested deny cases and read projections |
| 9 | Add future individual participant payments and independent provider runtime | Confirm fee/provider/policy; verified signature, idempotency, amount/currency/order binding, refunds, outbox/retries and immutable history; no cross-participant status updates |
| 10 | Browser/accessibility/responsive and operational release review | Authenticated route tests, no console errors, 320px/desktop, keyboard/focus/contrast, backups/monitoring/recovery evidence |

The first two steps are evidence gathering only. Any experiment that creates/changes database objects, roles, grants, ownership, migration history or runtime credentials remains separately approval-gated. No approval is implied by this roadmap.

## 9. Final readiness decision

**NO-GO for backend implementation and database-changing validation.** The frontend build/type/lint checks pass, but they do not resolve the critical security and product/schema blockers. Continue with the read-only validation sequence only under the existing exact-target and per-command approval controls. Do not execute Command 3 without fresh operator approval; do not start migrations or use the legacy SQL draft as implementation authority.

### Evidence references

- [Phase 4 backend readiness](aicuxora-phase-4-backend-readiness.md) — static integration inventory, auth redirect mismatch, product/schema conflict, NO-GO.
- [Phase 4.1 registration decision](aicuxora-phase-4.1-registration-decision.md) — confirmed per-participant registration/payment semantics and open decisions.
- [Phase 4.2 independent security review](aicuxora-phase-4.2-independent-security-review.md) — stale D-015/D-023 and security blockers.
- [Phase 4.9 read-only baseline completion](aicuxora-phase-4.9-read-only-baseline-completion.md) — Command 2 and Command 3 SQL, limits and migration-identity distinctions.
- [Phase 2.14.4 authoritative architecture](phase-2.14.4-authoritative-security-architecture.md) — accepted direction and unresolved implementation gates.
- [Phase 2.14.4 decision register](phase-2.14.4-decision-register.md) — traceability; includes stale decisions superseded at product level.
- [Phase 2.14.4 conflict inventory](phase-2.14.4-implementation-conflict-inventory.md) and [Phase 2.14.5 independent audit](phase-2.14.5-independent-security-audit.md) — legacy conflicts and remaining blockers.
- [Database schema draft](../database/phase-2-schema-draft.sql) — unexecuted proposal; source of static counts/conflicts described above.
- Frontend source reviewed: `src/app/router.tsx`, `src/pages/PortalPages.tsx`, `src/pages/public/Pages.tsx`, `src/components/layout/PortalLayout.tsx`, `src/styles.css`, `package.json`, `supabase/config.toml`.
