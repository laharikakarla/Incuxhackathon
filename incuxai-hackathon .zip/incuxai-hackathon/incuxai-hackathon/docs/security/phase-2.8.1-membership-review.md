# Phase 2.8.1 — Final PostgreSQL 17 Membership Semantics Review

**Scope:** PostgreSQL 17 role membership semantics and whether the Phase 2.8 RPC-owner validation models them correctly. The supplied disposable-project observations were considered. No SQL was executed and no Supabase project was contacted in this review.

## Decision

# NOT READY — CORRECTIONS REQUIRED

The PostgreSQL 17 membership model in Phase 2.8 is valid when the automatic grant and explicit self-grant have different grantors. The validation SQL and documentation now state and check that distinction. The design is not yet approved for use by the actual Supabase migration operator: the provided facts do not identify the role used by the real migration path, do not establish that `postgres` is non-superuser, and do not show what privileges the inherited/SETtable `supabase_privileged_role` provides. Those are required gates before accepting the operator's ADMIN delegation power.

## PostgreSQL 17 semantics

1. **Can two membership rows exist for the same member and granted role? — Yes, when grantors differ.** PostgreSQL 16 introduced support for multiple role-membership records. PostgreSQL 17's `pg_auth_members` records the grantor as well as `roleid` and `member`.
2. **What does a later GRANT do? — It updates the membership options associated with that grantor; a different grantor can have a separate row.** The automatic role-creator grant is attributed to the bootstrap superuser. Supabase's current documentation identifies the platform grantor as `supabase_admin` for roles created by `postgres`. A subsequent self-grant by `postgres` is a separate grantor record; it does not change the platform row.
3. **Can the creator downgrade or revoke the automatic ADMIN grant? — No.** The CREATEROLE creator cannot modify the bootstrap-granted row. It may change or revoke its own separate self-grant row, but that leaves the automatic ADMIN capability intact.
4. **Is the Phase 2.8 SQL model correct? — Yes, with the newly explicit grantor assertion.** It expects exactly two direct membership rows for the operator: bootstrap/platform `ADMIN TRUE`, `SET FALSE`, `INHERIT FALSE`; and operator-granted `ADMIN FALSE`, `SET TRUE`, `INHERIT FALSE`. It asserts that the ADMIN row's grantor differs from the member and that the SET-only row's grantor is the member. It separately rejects API-role membership and checks effective SET/USAGE/ADMIN behavior. This is a static compatibility conclusion; actual target output remains required.

## Supplied target observations

The disposable observation reports PostgreSQL 17.11, `session_user = current_user = postgres`, `CREATEROLE = true`, and membership of `postgres` in `supabase_privileged_role` with `ADMIN FALSE`, `INHERIT TRUE`, `SET TRUE`. `supabase_etl_admin` is also a member of that parent role, and API roles are not members of it.

These facts are consistent with the platform-admin model, but do not establish:

- whether `postgres` has `rolsuper = false` (the validation SQL requires this);
- whether the actual migration connection uses `postgres`, a temporary CLI login role, or another identity;
- the effective privileges granted to `supabase_privileged_role` or any other inherited/SETtable parent role;
- whether the target accepts the required `public`/`private` schema grants and custom ownership transitions.

The fact that API roles are not members of `supabase_privileged_role` is useful but does not answer the separate question of whether the migration operator is sufficiently bounded. A role name or membership option set is not an inventory of its privileges.

## Findings

| Severity | Finding | Location / disposition |
|---|---|---|
| High | The actual migration operator and `postgres.rolsuper` status are not established by the supplied observations. SQL Editor identity does not prove the CLI migration identity. | `phase-2.6-validation-runbook.md`, identity preflight. Must verify through the intended migration route; SQL preflight aborts for superuser or identity mismatch. |
| High | The privileges inherited from or reachable through `supabase_privileged_role` are unknown. Trusting the ADMIN-capable creator without reviewing this chain is not a complete least-privilege assessment. | `phase-2.6-validation-runbook.md`, Phase 0; SQL now prints a read-only membership-chain diagnostic before DDL. Inspect role attributes and relevant grants manually; stop if unexplained. |
| Medium | Prior wording did not clearly explain how the two same-pair rows coexist or that GRANT behavior is grantor-specific. | Corrected in the validation SQL, runbook, Phase 2.5 plan, schema draft, architecture and security review. The SQL now checks the grantor distinction. |
| Low | The supplied membership observation could be mistaken for proof that the API roles can or cannot assume `incux_rpc_owner`. | API roles remain checked directly against the owner role by the SQL; the new report distinguishes the parent-role observation from the owner-role assertion. |

## Safety assessment and corrected model

The automatic ADMIN membership is real delegation authority: its holder can grant membership in the owner role to other roles. The SQL does not weaken that fact or claim ADMIN is non-delegable. API roles are explicitly excluded from the owner role. The design can be acceptable only when the exact migration identity is a trusted deployment principal and its full role chain is understood and controlled.

If the team does not accept ADMIN authority on the migration principal, do not try to revoke the platform-created row. Use a separately provisioned deployment login with only an explicit non-admin `SET TRUE`, `INHERIT FALSE` membership and the minimum schema grant options required for migrations, while keeping the platform-created role creator as a separately controlled provisioning/break-glass identity. This alternative is only a proposal: Supabase support for the exact migration connection, grants, and object ownership must be validated before adoption. Otherwise redesign around invoker/RLS or a trusted server-side boundary.

## Static corrections made

- Updated `scripts/validation/phase-2.6-role-validation.sql` to require the bootstrap ADMIN row to have a different grantor from the member, and the SET-only row to be granted by the member. Added a read-only recursive operator role-chain diagnostic before DDL.
- Updated `docs/database/phase-2-schema-draft.sql` to state grantor-specific behavior and assert a distinct grantor on the automatic row.
- Updated Phase 2.6 runbook and Phase 2.5 H6 plan to require inspection of the actual CLI migration identity and the operator's inherited/SETtable role chain.
- Updated architecture/security notes and Phase 2.8 correction history to avoid implying that a second grant is an edit to the platform grant.

## Exact remaining validation gates

1. Confirm `postgres.rolsuper = false` in the disposable project.
2. Observe `session_user` and `current_user` through the exact migration runner, not only SQL Editor or read-only CLI access. Identify any `cli_login_postgres` or other role transition.
3. Review all direct and transitive memberships, attributes, and relevant grants for the actual operator, including `supabase_privileged_role` if present. Decide explicitly whether the operator's full authority is acceptable.
4. In the disposable project only, create the owner using the actual operator and inspect the two `pg_auth_members` rows, their grantors, and all three options. Confirm API roles remain excluded.
5. Validate schema grant options, ownership transfers, later migrations, and PostgREST checks through the intended execution path.

## References

- PostgreSQL 17 [role attributes](https://www.postgresql.org/docs/17/role-attributes.html), [GRANT role membership and option changes](https://www.postgresql.org/docs/17/sql-grant.html), [REVOKE role membership options](https://www.postgresql.org/docs/17/sql-revoke.html), [membership catalog](https://www.postgresql.org/docs/17/catalog-pg-auth-members.html), and [PostgreSQL 16 release notes on multiple membership records](https://www.postgresql.org/docs/16/release-16.html).
- Supabase [Postgres roles](https://supabase.com/docs/guides/database/postgres/roles) and [Can't revoke a membership granted by `supabase_admin`](https://supabase.com/kb/troubleshooting/cant-revoke-a-role-membership-granted-by-supabase_admin-d08922).
