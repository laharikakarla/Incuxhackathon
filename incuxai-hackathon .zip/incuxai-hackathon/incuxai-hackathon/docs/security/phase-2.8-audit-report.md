# Phase 2.8 — PostgreSQL 17 Role Membership Static Audit

> **Superseded:** The READY decision below is limited to the earlier package state. Phase 2.8.1 added grantor-specific semantics and found the actual Supabase operator privilege chain and migration identity still need confirmation. See [Phase 2.8.1 membership review](phase-2.8.1-membership-review.md) for the current decision.

**Review type:** static audit of the corrected validation SQL, Phase 2.6 runbook, Phase 2.5 H6 plan, Phase 2.7 report, Phase 2 schema draft, architecture, security review, RLS matrix, and Phase 2.3/2.4 finding records. **No SQL was executed, no Supabase project was contacted, and no runtime compatibility is claimed.**

## Decision

# READY FOR CONTROLLED DISPOSABLE VALIDATION

The package now models PostgreSQL 17's automatic ADMIN membership instead of requiring an impossible effective `ADMIN FALSE` state for the CREATEROLE role creator. It is ready for a controlled disposable test only, after the operator completes the Dashboard/local-link checks and confirms the actual migration identity. H6 remains unresolved until those runtime checks pass. The selected ADMIN authority is conditional on accepting the trusted migration operator's ability to delegate owner-role membership.

## Finding summary and classifications

| Severity | Finding | Disposition |
|---|---|---|
| High | PostgreSQL 17 automatically grants ADMIN to the non-superuser CREATEROLE role creator; the former script required ADMIN FALSE and aborted. | Corrected in the design: accept the auto ADMIN path only for the trusted creator; create a separate SET-only membership path; reject API-role membership/admin. Target-project behavior remains to be tested. |
| High | The trusted migration operator can use ADMIN to grant owner-role membership to other roles. | Accepted as an explicit residual deployment risk. The operator must be tightly controlled and audited. PostgreSQL does not constrain the ADMIN holder to only the API-exclusion checks in this script. |
| High | Static review cannot prove that the actual Supabase migration route uses the role being checked or that role/schema/object privileges are supported. | Remains a runtime gate. The CLI dry run does not apply SQL or establish the database execution identity. |
| Medium | Prior API fixture assertion checked only direct `SELECT` on the base table. | Corrected: final checks cover table privileges and relevant column privileges for `authenticator`, `anon`, `authenticated`, and `service_role`, plus public/private view and RPC ACLs. |
| Medium | Prior ownership fixture exercised only `public` although the schema design uses both `public` and `private`. | Corrected: fixture creation, owner transfer, post-revoke checks, and later replacement now cover both schemas. |
| Low | Prior project-ref guard allowed two user-entered refs without pinning the expected disposable target. | Corrected: expected ref is pinned to `bhnhhaurdnnalcozsviq`; the operator must independently confirm Dashboard and local link record. SQL still cannot identify the connected project itself. |

## PostgreSQL 17 decision and alternatives

PostgreSQL 17 documents that a non-superuser with `CREATEROLE` creating a role receives an automatic membership in that role with `ADMIN TRUE`, `SET FALSE`, and `INHERIT FALSE`; the creator cannot change or remove that bootstrap-granted membership. [PostgreSQL 17 role attributes](https://www.postgresql.org/docs/17/role-attributes.html)

The corrected model expects two direct catalog rows for the trusted creator:

1. Automatic creator membership: `ADMIN TRUE`, `SET FALSE`, `INHERIT FALSE`.
2. Explicit membership granted by the creator: `ADMIN FALSE`, `SET TRUE`, `INHERIT FALSE`.

The script validates the exact row shape and effective capabilities. The operator must be able to `SET ROLE` but must not inherit owner privileges. Effective ADMIN for the creator is expected and explicitly reported. The operator can delegate membership; therefore this design is suitable only when the migration operator is a trusted deployment principal whose credentials and role changes are controlled. `authenticator`, `anon`, `authenticated`, and `service_role` must have no membership and no ADMIN capability.

A separately provisioned role with no automatic ADMIN membership would be more restrictive only if Supabase provides a supported provisioning path that can create the owner and issue the constrained grant. Supabase documents that normal project users do not have unrestricted superuser access, so this is not assumed available. [Supabase roles and superuser access](https://supabase.com/docs/guides/database/postgres/roles-superuser) If the team will not accept trusted-operator ADMIN, use a separately reviewed `SECURITY INVOKER`/RLS model or a trusted server-side boundary.

The explicit SET-only path supports ownership transfers and later object replacements without inheriting owner privileges. Temporary schema `CREATE` is granted to `incux_rpc_owner` immediately before each test transfer/update window, revoked immediately afterward, and asserted absent in both schemas. PostgreSQL requires the target owner to have schema `CREATE` and the operator to be able to `SET ROLE` for ownership changes. [PostgreSQL 17 ALTER FUNCTION](https://www.postgresql.org/docs/17/sql-alterfunction.html) [PostgreSQL 17 GRANT](https://www.postgresql.org/docs/17/sql-grant.html)

## Static inspection by requirement

| Check | Static result | Runtime evidence still required |
|---|---|---|
| Project targeting | Pinned expected ref, matching separately confirmed ref, format check, `current_database()='postgres'`, fresh-name guards. | Confirm Dashboard project name/ref, local `supabase/.temp/project-ref`, and connected SQL session are all the named disposable target. No SQL-only ref attestation exists. |
| Actual migration identity | Entry assertion requires `session_user = current_user = expected_operator`; role switch/reset checkpoints verify identity changes. | Determine and use the actual migration operator; a dry run or SQL Editor session under a different role is insufficient. |
| Role creation | Requires non-superuser CREATEROLE; creates a NOLOGIN/NOINHERIT/NOBYPASSRLS restricted role. | Supabase target must allow role creation and catalog inspection. |
| PG17 membership | Requires the automatic ADMIN row plus a separate creator-granted SET row; checks `admin_option`, `set_option`, `inherit_option`, effective SET/USAGE/ADMIN. | Verify the target exposes expected membership rows and accepts the grant. |
| API-role isolation | Rejects direct/indirect membership and ADMIN capability for `authenticator`, `anon`, `authenticated`, and `service_role`; revokes fixture ACLs and asserts table/column privileges. | PostgREST checks using disposable identities; confirm no API role can assume the owner. |
| `public`/`private` coverage | Fixture function/view in each schema; pregrant denial; temporary schema grant; ownership transfer; revoke and immediate assertion; later replacement and revoke assertion. | Verify the actual migration mechanism and target schema privileges. `private` is created only if absent and remains unexposed to PostgREST. |
| Later migrations | Simulates replacement of owner-controlled function/view under `SET ROLE incux_rpc_owner`. | Apply a subsequent disposable migration through the actual CLI/deployment runner if it adds identity/session behavior. |
| Cleanup | No `DROP` statement in the SQL. All DDL is within one transaction; successful run commits named fixtures. Runbook recommends deleting the full disposable project. | On failure, roll back/close the session. On success, confirm ref before project deletion. |
| PostgreSQL/Supabase compatibility | Uses PostgreSQL 17+ role options and `pg_auth_members` option columns; official PostgreSQL semantics align with the script. | Supabase-managed grants, exact operator identity, SQL client transaction behavior, PostgREST settings, and later migration behavior are project-specific. |

The Supabase CLI's `--dry-run` previews migrations without applying them. The reported “database is up to date” result is migration-history information, not a role-privilege or runtime validation. [Supabase CLI reference](https://supabase.com/docs/reference/cli/introduction)

## Review of the 15 Phase 2.3 findings

The current source was cross-checked against the Phase 2.4 correction log. H1–H5 and M1–M7, L1–L2 remain marked corrected by that earlier static review; this phase did not re-execute their functions or policies. H6 now has an explicit PostgreSQL 17-compatible design but remains unresolved until controlled execution.

| ID | Static status | Current design location |
|---|---|---|
| H1 | Prior static correction retained | `public.team_post_payment_exception` audit insert and snapshots. |
| H2 | Prior static correction retained | `public.community_moderate` restore/hide transitions. |
| H3 | Prior static correction retained | `public.certificate_verify` and final ACL. |
| H4 | Prior static correction retained | Admin invitation, communications, rubric, certificate-type, notification RPCs and ACLs. |
| H5 | Prior static correction retained | Webhook transaction state history and `public.payment_record_verified_webhook`. |
| H6 | Design corrected; runtime unresolved | `incux_rpc_owner` creator ADMIN + explicit SET membership; both-schema ownership tests and actual operator gate. |
| M1 | Prior static correction retained | RLS policy preamble in the schema draft. |
| M2 | Prior static correction retained | Announcement audience and target policies. |
| M3 | Prior static correction retained | Safe permission, audit, and invitation projections. |
| M4 | Prior static correction retained | Consent serialization and required-version semantics. |
| M5 | Prior static correction retained | RLS matrix matched to policies, views, RPCs, and ACLs. |
| M6 | Prior static correction retained | Registration/join withdrawal and moderation lifecycle operations. |
| M7 | Prior static correction retained | `public.payment_create_order` expiry/locking path. |
| L1 | Prior static correction retained | Certificate rate control at the server-side Edge boundary. |
| L2 | Prior static correction retained | Required reasons on privileged role/permission functions. |

“Prior static correction retained” is not runtime confirmation or a new independent functional test. See the original [Phase 2.3 review](phase-2.3-independent-review.md) and [Phase 2.4 correction log](phase-2.4-correction-log.md) for details.

## Manual disposable execution checklist

Before execution:

1. Confirm Dashboard name/ref is `incuxai-hackathon-validation` / `bhnhhaurdnnalcozsviq`.
2. Confirm local link record in `supabase/.temp/project-ref` matches; do not treat it as proof of the live connection.
3. Confirm PostgreSQL 17.11 (or other PG17 minor), disposable-only status, and no role/fixture collision.
4. Identify actual migration role. Fill the Dashboard-confirmed ref and expected operator placeholders; do not put credentials in files or reports.
5. Confirm the operator is non-superuser with CREATEROLE and required CREATE grant-option privileges on `public` and, if already present, `private`.
6. Run in one SQL session as the actual operator. If any statement errors, issue `ROLLBACK` or close the session; do not retry with broader grants.

If the transaction commits, manually inspect owners, role attributes, view/function/API access, every direct table privilege, and ensure `private` is not exposed through PostgREST. Then test a subsequent migration through the actual runner and delete the disposable project after recording only credential-free results.

## Remaining risks and readiness limits

1. ADMIN is intentionally accepted for the trusted creator. No database constraint in this draft prevents that operator from granting membership to another role; governance and audit are required.
2. The actual CLI migration operator and Supabase permissions have not been verified. The SQL only tests them when run under that exact identity.
3. The pinned ref and Dashboard confirmation do not let PostgreSQL verify the connected project. A wrong connection plus ignored manual checks remains possible.
4. API and RLS assertions in the script cover fixtures only; they do not validate the whole Phase 2 schema.
5. If the team rejects operator ADMIN, this design is not acceptable; select and review the alternative before applying the full schema.
6. This audit did not run a SQL parser, database, CLI, or PostgREST test. The schema and validation SQL remain proposed, unexecuted artifacts.

## Final assessment

**READY FOR CONTROLLED DISPOSABLE VALIDATION.** This means only that the static package now has a coherent PostgreSQL 17 membership model and safer public/private fixtures. It does not resolve H6, establish Supabase compatibility, or authorize production use. H6 closes only after the actual migration operator passes the disposable role, ownership, later-migration, API, and cleanup checks.
