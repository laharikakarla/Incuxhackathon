# Phase 2.2 updated static audit report

**Scope:** independent documentation-level review of the corrected Phase 2 database design. No SQL was executed and no Supabase project was contacted. Static review does not establish deployability or production readiness.

## Result summary

The earlier critical/high design gaps have corresponding constraints, policies, grants, views, and trusted-operation proposals in the corrected documents. Static inventory checks found 59 declared public tables, all 59 enabled for RLS, no enablement references to missing public tables, 61 explicitly named policies, and 57 public functions. Every public function name occurs in the final explicit function-privilege allow-list, which follows the function definitions. The authorization design also installs an internal policy for the non-login RPC owner on every table.

The references, snapshots, and privilege logic are reviewable proposals only. SQL parsing against the exact PostgreSQL/Supabase target, provider-specific webhook work, adversarial tests, race tests, Storage policy implementation, and product decisions remain required. **Readiness: not approved for migration or production use.**

## Findings

| Severity | Finding | Status / evidence |
|---|---|---|
| Critical | Payment success/refund/order integrity must never rely on browser state or independent writable status columns. | Addressed in proposal: composite snapshot/transaction/refund/receipt FKs, immutable paid facts, trusted webhook processing, serialized refund reservations, no client table grants. Schema payment section. Still requires execution-level validation. |
| Critical | Privileged role, permission, registration, payment, team, and evaluation changes must be unavailable by direct client writes. | Addressed in proposal: default revokes, narrow column grants, role lookup helpers using `auth.uid()`, fixed-path definer functions, final EXECUTE allow-list, trusted transition RPCs. Must validate function ownership and grants in a disposable project before migrations. |
| Critical | Team membership and evaluation assignment integrity need concurrency-safe constraints. | Addressed in proposal: active membership/leader uniqueness, deferred roster assertion, team row locks; assigned rubric composite keys, unique active judge/submission index, score bounds. Concurrency tests remain required. |
| High | Order locks, fee version snapshots, webhook idempotency and late capture behavior. | Addressed in proposal; late captures are retained but unapplied and need reconciliation/refund operations. Gateway semantics are unverified because no provider has been connected. |
| High | Recruiter data access can outlive consent or expose unrelated personal/payment/judge/team data. | Addressed in proposal with active role + grant + current versioned consent checks, account-private notes/shortlists, minimized views, and no workspace sharing. Final consent text/retention remains open. |
| High | Judge access can cross assignment/conflict boundaries or reveal unreleased scores. | Addressed in proposal with active assignment and conflict checks, rubric binding, private evaluations, and explicit release permission. Final moderation/appeal workflow and score-release rules remain open. |
| High | Lifecycle state and timestamp contradictions can weaken audit trails. | Transition checks, guards, state-history audit triggers, and trusted functions are proposed. Exact semantics need PostgreSQL-level review. |
| Medium | Public community/certificate views and moderation references can expose data or target the wrong content. | Same-post/cycle and moderation-target checks; restricted certificate verifier and consented display name are proposed. Public rate limits need operational tuning. |
| Medium | Index gaps can cause slow ownership, join, payment, recruiting, judge, notification, and audit queries. | FK/reference and workload indexes were added; benchmark and query-plan review are not yet possible without a database and representative data. |
| Medium | Product defaults could be mistaken for confirmed event policy. | Defaults and unresolved choices are separated in the security review and correction log. Obtain product-owner decisions before implementation. |

## Self-audit checklist

- **Tables and policies:** 59 public tables; all have RLS enabled and are covered by the dynamic internal-owner policy. Explicit user/service policies are named; raw financial, audit, role, and verification tables remain without ordinary client privileges.
- **Foreign keys:** every declared public target is a table in the draft; Auth references target `auth.users`. Composite targets are paired with unique keys for fee snapshots, transaction snapshots, same-order refunds, receipts, assignments, rubric evaluations, and criteria scores. These were statically inspected, not checked by PostgreSQL's parser.
- **Role/column permissions:** client grants are narrowly listed; sensitive state columns have no direct client write grant. Default privileges revoke future table, sequence, and function access.
- **Function security:** `SECURITY DEFINER` functions use fixed paths in the proposal; final ownership assigns functions to a non-login `NOBYPASSRLS` role; `EXECUTE` is revoked before explicit authenticated/anon/service allow-lists. No catch-all SQL RPC is provided.
- **Team rules:** one active team per participant, exactly one active leader, leader counts in policy size, versioned team size policy, transaction locks, safe unlock on failed/expired payment, permanent paid lock, audited Super Admin exception.
- **Payment rules:** one pending-or-paid order per team, immutable amount/currency/fee version snapshot, verified transaction required for paid state, same-order transaction/refund linkage, per-transaction cumulative refund reservation, receipt bound to paid transaction, duplicate event idempotency, existing orders retain fee snapshot.
- **Recruiter/judge boundaries:** consent/grant/role are checked at read time; current assignment/no conflict gates judge access; score release is separately permissioned; recruiters and moderators have no private discussion/judge/payment access.
- **Lifecycle/audit:** sensitive transitions record actor/time/reason where applicable; financial and consent histories are preserved; webhook raw bodies/secrets are not retained by default.
- **Phase boundaries:** only documentation files are in scope for this correction; no SQL execution, Supabase connection, migration, frontend change, dependency operation, commit, or push.

## Outstanding approval gates

1. Product owner resolves the open decisions in [the security review](phase-2-security-review.md#unresolved-decisions).
2. A database engineer validates the draft against the intended PostgreSQL/Supabase versions, especially role creation/ownership, policy recursion, `SECURITY DEFINER`, trigger timing, composite deferred constraints, view security behavior, and transaction semantics.
3. Security review confirms every view and function grant in a disposable local/staging database and tests cross-user denial, staff privilege boundaries, and RLS behavior.
4. Concurrency and payment tests verify team joins, payment callbacks, expiry, duplicate/late capture, refund reservation, and roster lock transitions.
5. Gateway, Edge Function, Storage, rate-limit, secrets, retention, and incident-response designs are completed before any external integration.

**Final readiness:** corrected documentation is suitable for the next engineering review, not for direct production execution. Await product-owner approval before implementation work.
