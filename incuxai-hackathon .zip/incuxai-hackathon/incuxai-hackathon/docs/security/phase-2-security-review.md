# Phase 2 security review and open decisions

**Review status:** design-only review. No Supabase project, database, storage bucket, Auth provider, Edge Function, or payment gateway was contacted or configured. The companion schema is a review draft only.

**Correction status:** this reflects Phase 2.2 corrections. The SQL contains proposed policies and function bodies, but remains unexecuted and requires PostgreSQL/Supabase validation before migration work.

**Phase 2.4 review note:** the Phase 2.3 findings are addressed in the current SQL and RLS-matrix proposals except for target-project role/ownership compatibility, which remains unverified without the prohibited Supabase validation step. See [Phase 2.4 correction log](phase-2.4-correction-log.md).

**Phase 2.8 membership correction:** PostgreSQL 17 automatically gives a non-superuser CREATEROLE creator a bootstrap ADMIN membership in a new role, which that creator cannot remove. The design now accepts this ADMIN capability only for the trusted migration operator, while requiring a separate explicit `SET TRUE`, `INHERIT FALSE`, `ADMIN FALSE` membership path and complete exclusion of API roles. This delegation authority is a documented operational risk, not a non-delegable grant. The validation also covers ownership transfers in both `public` and `private`. Supabase target-project support, later-migration behavior, and PostgREST/RLS effects remain unverified. See [Phase 2.8 correction log](phase-2.8-correction-log.md) and [Phase 2.8 audit report](phase-2.8-audit-report.md).

**Phase 2.8.1 membership-semantics note:** The automatic row is platform/bootstrap-granted, while the operator's explicit self-grant has a different grantor. PostgreSQL 16+ supports both rows for the same role/member pair; the validator now checks this grantor distinction. The observed `postgres` membership in `supabase_privileged_role` does not prove the privileges of that parent role or identify the CLI migration operator. Those are manual gates. See [Phase 2.8.1 membership review](phase-2.8.1-membership-review.md).

## Security boundaries

### Authentication and authorization

- Supabase Auth verifies identity; `auth.uid()` identifies the caller. Passwords stay exclusively in Auth.
- PostgreSQL RLS is the authorization boundary for API access. React route guards may improve user experience, but they are not security controls.
- Roles and delegated permissions are stored in grant tables and checked on every sensitive operation. Never rely on editable client state, user metadata, request JSON, or an unsigned role claim.
- The initial Super Admin must be established through a controlled bootstrap/operator process. Public signup never assigns staff roles. A partial unique constraint keeps only one active Super Admin; a documented recovery procedure is still needed if that account is lost.
- Keep public projections narrow. Do not expose `auth.users`, raw role tables, audit snapshots, candidate-private fields, webhook records, or judge evaluations through broad views.

### Privileged functions and service credentials

The dedicated `incux_rpc_owner` is non-login, non-inheriting, and `NOBYPASSRLS`. The trusted migration operator needs `SET ROLE` access with inheritance disabled. On PostgreSQL 17 the creator also holds the automatic ADMIN capability; API roles receive no membership or ADMIN capability. Temporary schema `CREATE` is granted only around ownership transfer and removed before runtime. Future migrations must use the same bounded grant / `SET ROLE` / `RESET ROLE` / revoke sequence. The disposable validation must confirm the exact membership rows, API exclusion, and schema privileges using the actual migration operator.

- Service-role keys bypass RLS. Store them only in Supabase Edge Function secrets, never in `VITE_*` variables, browser bundles, source control, or error logs.
- Use security-definer functions only for operations that require atomic privileged behavior. Fix `search_path`, qualify object names, revoke `EXECUTE` from `public`, grant only to the intended database role, validate the authenticated subject, and write audit records in the same transaction.
- Prefer invoker-security functions and narrowly scoped Edge Function service clients where possible. Do not expose a general “run SQL” RPC.
- Auth invitation, role assignment, fee changes, payment order creation, webhook processing, refund, evaluation publication, and certificate issue/revoke all require trusted paths.

### Payment integrity

- Initial registration is free; the later participation fee is one amount per team, paid by the active team leader. Currency is INR. The fee amount is **TBD** and is not seeded or hardcoded.
- The payment order snapshots the applicable fee version and amount in integer paise. No floating-point money and no browser-authoritative amount.
- A payment is successful only after server-side gateway verification of signature, gateway order, transaction, amount, currency, and expected state. Browser redirects cannot update payment state.
- Unique provider/event and transaction IDs, row locks, and order state transitions provide idempotency under callback retries and concurrent attempts. A failed normalized transaction can advance once to succeeded only through verified webhook processing; immutable webhook events preserve both status reports, and captures for terminal orders remain unapplied for reconciliation.
- The order is a workflow record; successful transaction and refund rows preserve financial history. Do not delete or edit a paid order’s payer, amount, currency, team, or gateway identifiers.
- A pending order freezes its roster. Definitive failure, cancellation, or expiry unlocks through a trusted operation. A paid team remains locked unless Super Admin approves an audited exception; financial history remains intact.
- Unpaid orders preserve their fee snapshot through expiry; fee changes affect new orders only.
- Gateway secrets and webhook signing secrets belong only in server secrets. Restrict egress, log redaction, refund permissions, alerting, reconciliation, and operational access.

### Personal information and recruiter visibility

- Collect only fields needed for participation. Phone, academic details, city/state, professional links, and interests should each have a clear purpose and visibility rule.
- Email remains in Auth; do not duplicate it into a generally readable profile row.
- Participant discovery should default to not discoverable until explicit opt-in. Allow consent withdrawal. Recruiters see a limited candidate projection only; they never see payment data, private team discussion, or judge evaluations.
- Recruiter notes are confidential recruiter data. Define an acceptable-use policy, retention period, and escalation process; discourage storing sensitive or discriminatory information.
- Avoid writing full rows, contact data, access tokens, or webhook bodies to logs. Retention/deletion and incident response require owner decisions.

### Team and submission integrity

- Unique partial indexes prevent one active team per participant and one active leader per team. All membership changes lock the team and recheck size/payment state in a single transaction.
- Invitations and join requests do not grant access until the serialized acceptance RPC succeeds.
- Final submission deadlines use server time. Revisions are preserved. GitHub OAuth tokens are never stored in submission rows; URLs and metadata are sufficient for the initial phase.
- Storage rules must check current team membership, not only path naming. A leaked URL must expire quickly and should not outlive membership authorization.

### Judge confidentiality and moderation

- Judge access requires a current assignment to the exact submission and no unresolved conflict. Conflict declaration must revoke assignment-based reads immediately.
- Rubric version, criterion weights, and scores are validated server-side. Scores and feedback remain private until a separately authorized release.
- Recruiters, moderators, and participants do not receive judge data by virtue of another role. Role combinations need explicit policy.
- Moderators can manage community content and reports only; all actions carry actor, time, target, and reason. This role grants no broad admin or payment access.

### Certificates and public verification

- Verification codes should be high-entropy, unguessable IDs generated server-side, with rate limits and abuse monitoring. The verifier RPC is service-role-only; the public Edge Function is the only supported route and must apply per-source and global abuse limits before calling it.
- The public verifier returns only validity, certificate kind, event issuer, and a consented display name. It does not reveal email, phone, profile URL, team roster, internal UUIDs, or certificate files.
- Revocation is recorded without deleting the original issue history. Certificate issuance must be tied to approved participation/result state.

## Main threats and controls

| Threat | Main controls | Remaining work |
|---|---|---|
| User alters frontend role/payment amount | RLS, server-only permission checks, immutable fee/order snapshots, no client write policies | Adversarial tests and review of every function grant. |
| Concurrent joins create oversize/multiple teams | Row-level team lock, one transaction, partial unique indexes, current policy check | Race tests at realistic concurrency. |
| Duplicate/faked payment callback | Signature verification, expected amount/currency/order check, unique event/transaction IDs, idempotent state function | Gateway-specific verification and reconciliation after Razorpay is approved. |
| Admin account compromise changes fee | One Super Admin, narrow delegated permission, MFA for staff, append-only audit, alerting | Decide recovery and two-person review for high-impact changes. |
| RLS policy mistakenly reveals data | Default deny, per-table matrix, safe views, negative access tests, no service key in browser | Policy review by a second engineer and staging tests. |
| Recruiter scrapes private candidate data | Explicit opt-in, field-minimized view, scoped recruiter grant, pagination/rate limit | Define consent UI, purposes, export limits, retention. |
| Judge conflict or premature score disclosure | Assignment-scoped policy, conflict check on reads/writes, draft/submit/publish states | Decide conflict rules, publication timing, appeal process. |
| Storage object exposed through guessed path | Private bucket, object-level RLS, short signed URL, authorization on issue | Test every bucket and stale membership/assignment behavior. |
| Audit/log leaks sensitive data | Allow-listed audit fields, no secrets/raw payment payloads, restricted read | Define audit retention, access review, deletion/legal hold. |
| Certificate code enumeration reveals a person | High entropy, rate limiting, safe projection, optional name consent | Define abuse thresholds and public naming policy. |

## Adopted defaults and unresolved decisions

### Adopted defaults

- Initial registration is free; one team leader pays once per team, in INR.
- The leader counts toward configurable team limits. Every team records the immutable size-policy version chosen at creation.
- One active team per participant; exactly one active leader per active team; active roster size must satisfy its recorded policy.
- Roster locks at payment initiation and stays locked after success. Definitive failure, cancellation, or expiry unlocks through trusted logic. Post-payment changes require Super Admin approval and an audit record.
- Orders expire after 24 hours by default. Treat this as a configurable design default to confirm before implementation.
- Fee changes create immutable versions recording administrator, old/new amount, reason, and timestamp. Existing orders keep their fee version.
- Refunds require authorized approval and a serialized refundable-balance check; original payment history is preserved.
- Recruiters need an active Recruiter role, explicit access grant, and current versioned participant consent. Shared recruiter workspaces are not supported.
- Judge scores remain confidential until explicitly released by an authorized evaluation administrator.

### Unresolved decisions

1. **Fee:** actual INR amount, effective time, tax treatment, and payment deadline; current amount remains TBD.
2. **Team size:** actual minimum/maximum and treatment of existing teams if policy limits later change.
3. **Refunds:** final policy, exceptions, deadlines, fees/tax treatment, and financial treatment of approved post-payment roster changes.
4. **Event:** actual dates, location, timezone, and submission deadline.
5. **Eligibility:** registration requirements and which states permit payment, submission, and certificates.
6. **Recruiting:** consent wording, exposed fields/scopes, acceptable use, retention, and export rights.
7. **Judging:** rubric, score scale, judge count, conflict rules, tie-break/appeal process, and release schedule.
8. **Certificates:** eligibility, award categories, public naming choices, and revocation appeal.
9. **Privacy/retention:** retention/deletion and de-identification, minors/guardian consent if applicable, notices, data export, incident response, and statutory records.
10. **Staff operations:** role combinations/separation of duties, Super Admin recovery, and high-impact change review.
11. **Community:** posting eligibility, report handling, retention, appeals, and whether a separately designed emergency team-discussion access process is ever needed.
12. **Gateway:** Razorpay account ownership, webhook coverage/key rotation, reconciliation, disputes, and refund approval level. No gateway integration is part of this phase.

## Review gate

Before implementation: product owner signs off the open decisions; engineering reviews the SQL draft and RLS matrix; security reviews definer functions, Storage rules, and service-role boundaries; tests cover cross-user access, race conditions, payment idempotency, and score confidentiality. Only then create actual migration files and apply them to a disposable Supabase development project under an explicitly approved implementation phase.
