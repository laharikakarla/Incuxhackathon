# AICUXORA Phase 4 — Backend Readiness Assessment

**Assessment date:** 2026-11-13 (updated after Phase 4.1 decision)  
**Scope:** Static inspection of the local repository only. No Supabase connection, SQL execution, migration, or secret inspection was performed.  
**Decision:** **NO-GO for backend implementation and database migrations.** Continue with requirements and security design reconciliation. The frontend remains a preview and the database files remain proposals.

## 1. Executive summary

The repository contains a React, TypeScript, Vite, and Tailwind application with public pages and student/admin preview screens. The forms and dashboards do not use a Supabase client, authentication SDK, or persistent backend calls. Their visible flows are local UI states, static content, empty states, or disabled preview actions. They must not be treated as real registration, authentication, team, or admin functionality.

There is a substantial proposed PostgreSQL schema draft, but no local `supabase/migrations` directory and no deployment evidence. The draft is explicitly not proof that objects exist in any database. The accepted architecture documents retain a NO-GO due to unresolved migration identity and ownership lifecycle, exact least-privilege grants, audit actor authenticity, system runtime identity/pooler behavior, and other implementation details.

The product owner has now confirmed the registration model: accounts, verified email, profiles, and individual event registration precede payment; payment will be added later and charged per participant. The fee, provider, and venue remain undecided. This resolves the earlier free-versus-paid product conflict, but the earlier database draft and security decisions assumed free initial registration and one payment per team. Those assumptions must be reconciled with the confirmed per-participant model before designing payment tables or operations. This decision does not resolve the security and migration blockers.

## 2. Evidence reviewed and limits

Reviewed local Supabase configuration, package/dependency and source references, router and portal page implementations, SQL schema draft, Phase 2 architecture/relationships/RLS/security docs, correction/audit docs, and Phase 2.14.2–2.14.5 architecture reconciliation and security reviews.

The original Phase 2.12, 2.13, and 2.13.1 source specifications are not present in this checkout or its inspected Git history. Phase 2.14.4 states that its matrices are a proposed reconstruction from the current SQL draft, not a verbatim copy of those missing specifications. Accordingly, this assessment preserves only decisions evidenced by the surviving later documents and does not invent historical decisions.

The schema draft declares many tables, functions, and views. These are **proposed objects only**. No remote catalog was inspected, and no object is classified as deployed/verified based on SQL text.

## 3. Existing application and configuration

### Frontend/backend boundary

- The app has public routes and student/admin preview routes in the React router.
- No Supabase JavaScript client or `createClient` usage was found in the application source. `@supabase/supabase-js` is not a declared application dependency.
- No real auth API request, persisted registration, team mutation, submission, or administrator operation was found. Registration and login use client-side validation and presentation state. Email verification is described as a preview; no email is sent. Recovery/reset screens do not perform a real Supabase recovery flow.
- Student profile, team, announcements, and submissions screens show previews/static states. Admin pages display empty or unavailable states and disabled controls; they do not enforce permissions or persist changes.
- This is consistent with the prior product restriction against pretending backend operations work.

### Supabase configuration

- `supabase/config.toml` exists. It contains a local project identifier and local Auth configuration; this is not evidence of the active remote project or of deployed schema state.
- Local Auth config enables email signup and disables email confirmation. Local `site_url` and redirect configuration use port 3000, while the Vite development server convention is port 5173. Reconcile callback URLs before implementing a real browser auth flow; do not infer hosted settings from local config.
- The configuration indicates PostgreSQL major version 17 and local transaction-pooler configuration. This does not establish hosted behavior for custom roles, pooler identity, ownership transfer, or migration execution.
- No `supabase/migrations` directory is present. The repository does not yet provide a migration history/deployment workflow for this backend.

No secrets or credential values were read or included in this report.

## 4. Requirements-to-database mapping

Status labels describe backend readiness, not whether a mock screen exists:

- **Existing and verified:** observed as an implemented backend object/flow. None of the requested backend capabilities meet this standard in the local evidence.
- **Proposed but not verified:** represented in an unexecuted SQL draft or architecture document, without deployment/runtime evidence.
- **Missing:** no adequate backend object or approved implementation specification was found.
- **Conflicting with approved architecture:** the available product/business requirements disagree with an earlier accepted decision or draft behavior.
- **Blocked by unresolved security decisions:** a design direction exists, but authorization, identity, grants, migration feasibility, or runtime proof is insufficient to implement safely.

| Requirement | Local evidence | Readiness classification | Gaps and security conditions |
|---|---|---|---|
| 1. Student authentication and identity | Supabase local Auth config exists; frontend has preview login/register/recovery screens. No client SDK or real auth flow. Draft references `auth.users` through profile identity and has registration/auth functions. | **Proposed but not verified; blocked by unresolved security decisions** | Accounts may be created before payment. Email verification is required. Need hosted Auth configuration, verified email/recovery callbacks, session handling, account lifecycle and tested JWT propagation. User identity must come from verified JWT claims and `auth.uid()`, never a browser-supplied actor ID. Local redirect port mismatch must be resolved. |
| 2. Student profiles | Draft proposes `profiles`, `participant_skills`, `participant_interests`, and `profile_links`. UI displays/editing preview only; profile fields are disabled/static. | **Proposed but not verified; blocked by unresolved security decisions** | Students may complete profiles independently of payment. Define ownership and editable-field boundaries, private/public profile projections, deletion/retention, and RLS. Role and admin permission fields must not be user-editable. |
| 3. Event registration | Draft proposes `participant_registrations`, `registration_submit`, `registration_withdraw`, and admin decision function. Frontend form is not persisted. | **Proposed but not verified; blocked by unresolved security decisions** | Confirmed model is an individual event registration submitted independently of payment. Registration submission must not imply payment or mark an account paid. The draft's free-registration assumption must be reconciled with later per-participant payment. Define eligibility and registration states/transitions server-side. |
| 4. Team creation and membership | Draft proposes team policy versions, `teams`, `team_memberships`, join requests, skills, and team RPCs. UI is preview only. | **Proposed but not verified; blocked by unresolved security decisions** | Confirmed team size is 2–5 members. Need validated serialization, one active team per participant, exactly one active leader, capacity enforcement, transaction-safe operations, and a decision on how individual payment interacts with team lifecycle. Never infer a participant's payment state from a leader or another teammate. |
| 5. Team invitations | Draft proposes `team_invitations`, join requests, and invitation operations. UI invitation/join flows are previews. | **Proposed but not verified; blocked by unresolved security decisions** | Bind invite acceptance to `auth.uid()`, enforce expiry/single use/capacity/one-team constraint atomically, prevent invitee identity spoofing, and audit lifecycle changes. |
| 6. Submissions | Draft proposes `team_submissions`, `submission_versions`, technology links, save/finalize operations, and event deadlines. UI is a static dashboard. | **Proposed but not verified; blocked by unresolved security decisions** | Define GitHub URL validation and immutable/version history, team authorization, deadline/time-zone semantics, finalization lock, update-after-finalize rule, and reviewer visibility. No GitHub integration is established. |
| 7. Announcements | Draft proposes `announcements`, targeting, notifications, and admin announcement functions. UI shows static/empty data. | **Proposed but not verified; blocked by unresolved security decisions** | Define published/public/targeted visibility, audience authorization, admin content permission checks, notification delivery/outbox, and audit. Draft policy details are not accepted as safe runtime behavior. |
| 8. Domains and prizes | Public website presents event domains/prize information as content, but no data-backed admin functionality was verified. Draft has skills, interest areas and technology tables; no clear authoritative event-domain or prize-management tables were found in the table inventory. | **Missing** (backend management); public information is present in frontend content | Decide whether these are fixed launch content or admin-managed records. If editable, specify authoritative data model, publication rules, audit, and public projection. Proposed static website content is not a database source of truth. |
| 9. FAQ and event settings | FAQ is part of the public requirements/UI, but no FAQ table or FAQ admin persistence was found in the draft. Draft includes `event_schedule` and deadline versions, but no general event-settings model was identified. | **Missing** for FAQ and general settings; **Proposed but not verified** for schedule/deadlines | Choose whether FAQs/settings are static for launch or managed. If managed, define publication/versioning, content-admin authorization, safe public fields, time zones, and audit. Do not imply UI edits persist. |
| 10. Administrator identities and permissions | Draft proposes `user_role_grants`, `admin_permission_grants`, `admin_invitations` and admin functions. Admin UI is an unsecured preview. | **Proposed but not verified; blocked by unresolved security decisions** | Must use protected database role/permission records, not editable profile/JWT metadata. Define initial Super Admin bootstrap, invitation claim proof, permission boundaries, last-Super-Admin protection, immediate revocation, and audited changes. Backend enforcement is absent. |
| 11. Audit logs | Draft proposes `audit_log` and audit-related functions/triggers, but Phase 2.14.5 found the design needs actor-authenticity and writer-privilege decisions. | **Proposed but not verified; blocked by unresolved security decisions** | Need append-only trusted writer, non-forgeable user/system/webhook actor binding, event coverage, atomicity, retention, and protections against direct API inserts/updates/deletes. Trigger ownership and identity context are not validated. |

### Registration and payment boundary

Phase 4.1 confirms that accounts and individual event registration come before payment, and future fees are per participant. Earlier database documents instead assumed free initial registration and one payment per team by the leader. This is now a **design conflict in the old database proposal**, not an unresolved product decision: update/review the proposal before implementation. The fee and provider remain TBD. Future payment must be a separate participant-level lifecycle, idempotently linked to the correct participant and event registration; a team leader's payment cannot set another participant's status. Preserve provider signature verification, unique webhook event IDs, amount/currency/order verification, refunds, immutable financial history, and auditability. The old team-payment roster lock must not be applied to individual charges without a fresh product/security decision. Do not display or simulate successful payment.

For planning purposes only, distinguish these state concepts (exact enum names and database representation remain for later approved design):

- **Authentication:** unverified email, verified active account, and disabled/deleted account as supported by the chosen Auth lifecycle.
- **Profile:** incomplete or complete; completion is independent of payment.
- **Event registration:** not submitted, submitted/pending review if review is required, accepted/declined/withdrawn as applicable. The product owner has not yet confirmed whether manual approval is needed.
- **Payment per participant:** not configured/not due before payment launch, pending, succeeded, failed/expired, refund pending, partially refunded, or refunded, with an explicit exception/reconciliation state if required. A registration submission must not transition payment state.

These are lifecycle requirements, not a proposal to add specific schema objects before the architecture review.

## 5. Minimum secure backend for first launch

The smallest defensible backend is the subset required for the launch scope, not all future hackathon portals at once:

1. **Verified identity:** Supabase Auth with explicit email confirmation/recovery and correct local/hosted callback URLs. The application must treat the signed JWT as the identity source and use `auth.uid()` in policies/transactions.
2. **Participant profile and registration:** server-enforced ownership, validated fields, explicit registration lifecycle, and only the minimum participant data required by the confirmed eligibility rules.
3. **Team lifecycle:** policy-versioned 2–5 member rule (or the finally approved limits), one active team per participant, exactly one leader, and locked-roster/payment behavior only after the payment model is decided. All concurrent membership transitions must be transactional and audited.
4. **Submissions:** team-authorized draft/version/finalize lifecycle with deadline enforcement and no client authority to change review status.
5. **Published event content:** read-only public projections for announcements, domains, prizes, FAQ, and schedule. If this content remains fixed for launch, static content can be retained; if administrators must edit it, a secure content-management backend and permissions become launch dependencies.
6. **Admin bootstrap and authorization:** protected admin identities/permissions, controlled first Super Admin setup, backend authorization for every privileged action, and append-only audit. An admin preview route is not an authorization boundary.
7. **Payment (later phase):** account creation, profile completion, and individual event registration must work before payment activation. When payment is introduced, decide fee and provider first, then implement individual participant records and validate the independent payment runtime, provider verification, idempotency, refunds and database authorization. Registration submission must never imply payment success. Whether the event can open registration before payment activates is a launch sequencing decision; it is not a reason to couple account creation to payment.

Do not create new tables or policies from this assessment. The draft must first be reconciled with this minimal launch scope and the accepted security architecture.

## 6. Proposed authentication and authorization flow

1. The browser begins signup/sign-in/password recovery through the approved Supabase Auth client only after callback URLs and hosted Auth settings are reviewed.
2. Email confirmation and recovery use Supabase-issued one-time links/tokens. UI state alone never marks an account verified or a password reset complete.
3. Authenticated requests carry the signed access token to the database API or a narrowly scoped Edge orchestration endpoint. For user operations, the database derives the actor from verified JWT context using `auth.uid()`; never trust a user ID supplied in form data or RPC parameters as proof.
4. A profile is linked to the authenticated principal under a protected, idempotent flow. User-owned profile fields are guarded by RLS and column boundaries. Privileged role/permission fields cannot be updated through participant profile operations.
5. Every operation rechecks current authorization and lifecycle state in the transaction. Team membership, invitation validity, submission deadline, recruiter consent, judge assignment and admin permissions cannot rely only on stale frontend state.
6. Administrative operations use backend-enforced permissions and trusted transaction boundaries. System and webhook operations use separately authenticated identities; they are not impersonated as a participant by passing actor IDs or setting ordinary session variables.
7. Audit events are written atomically by the approved trusted audit mechanism. The API cannot fabricate, edit, or delete audit rows.

This is a target flow from the surviving Phase 2.14 architecture, not a verified hosted-project capability.

## 7. RLS and security requirements before implementation

- Enable default-deny access and grant only needed schema/table/column/function privileges. RLS being enabled by itself is not sufficient.
- For participant-owned records, authorize through `auth.uid()` and test both allowed and denied cases. Team data requires current authorized membership; leadership-only actions require current leader status.
- Invitations and join requests must be scoped to their real inviter/invitee/team and transition atomically. Clients must not choose another user's actor identity.
- Registration approval, admin roles, payment status, evaluation results, roster payment state, and certificate issuance/revocation are not direct participant writes.
- Team capacity and one-active-team rules need database uniqueness/locking or equivalent transaction-safe enforcement, not only a UI check.
- Submission write/finalize permissions must be team-scoped and enforce deadline/lifecycle state in the database.
- Public content projections expose only published, intended fields. Recruiter data requires active recruiter authorization plus current participant consent. Judge data requires active assignment; private evaluations remain confidential until authorized release.
- Prefer SECURITY INVOKER and RLS. Where an atomic privileged operation requires SECURITY DEFINER, use a narrowly scoped NOLOGIN owner, fixed safe search path, schema-qualified references, restricted EXECUTE grants and reviewed nested call graph. Hosted role ownership/replacement remains unproven.
- Do not use a universal `incux_rpc_owner`, broad `service_role` table access, mutable user metadata as an admin source, or untrusted actor IDs/custom GUCs as proof of actor identity.
- Protect audit records with trusted append-only insertion and deny ordinary API modification/deletion. Audit atomicity does not independently prove actor authenticity.
- Payment requires immutable fee-version snapshots, matching order/transaction currency and amount, verified provider signatures, unique provider event IDs, idempotent retries, serialized refund limits, and an independently controlled payment/webhook runtime. No payment route is ready for implementation today.

## 8. Migration and implementation dependency sequence

This is a planning sequence; it does not authorize SQL drafting, migrations, or database changes.

1. **Reconcile confirmed product decisions into database design:** replace the obsolete free-initial/per-team payment assumptions with account/profile/individual registration before payment and later individual participant payment. Confirm fee, provider, eligibility, whether registration approval is required, team/payment interactions, event dates/location, content ownership, and launch sequencing.
2. **Restore traceability:** preserve the current Phase 2.14.4/2.14.5 baseline and obtain or explicitly ratify reconstructed 79-function, 30-view, and 18-helper/trigger matrices. The missing Phase 2.12/2.13 source documents must not be silently treated as present.
3. **Complete security specifications:** exact function signatures/callers/EXECUTE grants, owners, table/column reads and writes, RLS policies, helper call graph, view projections, audit actor binding, outbox/inbox, runtime identities, and role isolation.
4. **Resolve migration feasibility:** establish actual migration execution identity separately from CLI login and read-only query identity; validate disposable-project NOLOGIN owner creation, ownership transfer, subsequent replacement, temporary privilege lifecycle, transaction/failure recovery and migration history. This requires a separately approved controlled validation; no such probe is authorized here.
5. **Reconcile Auth config:** align redirect/callback URLs with Vite local development and the intended hosted domains; document email confirmation, recovery, session refresh and user deletion behavior.
6. **Draft reviewed migrations only after gates pass:** lay down required extensions/schemas/types and constraints; then identity/profile/RLS; registration and team constraints/transactions; submissions; published content and admin authorization; audit/outbox; and payment only after its product and worker decisions are approved. The exact ordering must follow FK and function dependencies.
7. **Validate in disposable project only:** positive and negative RLS/ACL tests, concurrency, failure injection, trigger identity, function replacement lifecycle, runtime pooler identity, payment idempotency and recovery. Never infer hosted behavior from static SQL or CLI dry run.
8. **Release gate:** independent review, approved migration diff, backup/recovery plan, and explicit authorization before any production deployment. Production is outside the scope of this assessment.

## 9. Principal blockers and risks

| Severity | Blocker |
|---|---|
| Critical | No implemented backend/auth client or migrations; frontend preview actions are not persistent or secured. |
| Critical | Accepted architecture remains NO-GO: actual migration identity, domain-owner function replacement, precise grants/RLS, audit identity and system runtime feasibility are unresolved. |
| Critical | The accepted product decision (individual registration before later per-participant payment) conflicts with the existing draft's free-initial/per-team payment model; fee/provider and payment states/authorization remain unspecified. |
| High | Existing SQL draft contains legacy security patterns that conflict with the accepted architecture; it must not be applied as-is. |
| High | FAQ, event-settings, domain and prize management are not represented by a verified backend model; determine static versus admin-managed launch content. |
| High | Auth callback config uses port 3000 while the local Vite convention is 5173; real email confirmation/recovery flow would need reconciliation. |
| High | Super Admin bootstrap, admin permissions, audit actor trust, and revocation behavior remain design/validation dependencies. |
| Medium | Event-specific eligibility, retention/privacy, public profile projection and submission/GitHub workflow need product decisions. |

## 10. Recommendation

**NO-GO for beginning backend implementation or drafting/applying database migrations.** Phase 4.1 resolves the registration business model at the product level, but the old database model still needs reconciliation and security/migration blockers remain. The UI may continue to be presented as a clearly labeled preview, but it must not imply functional authentication, persistence, payment, or secured administration.

The safe next work is to reconcile the approved per-participant payment lifecycle into the architecture, confirm remaining eligibility/approval/launch decisions, ratify the recovered architecture matrices, and close the Phase 2.14.5 security and migration-feasibility blockers. Backend implementation can begin only after those decisions are explicit and the required disposable-project validation has separate approval and evidence.
