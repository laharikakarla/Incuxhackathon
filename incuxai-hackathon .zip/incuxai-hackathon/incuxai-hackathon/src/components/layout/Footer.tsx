import { ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-top">
        <div>
          <Link to="/" className="brand" aria-label="AICUXORA 2027 home">
            <img className="brand-logo" src="/assets/brand/incux-ai-logo.jpeg" alt="IncuX AI" />
            <span className="brand-text">
              AICUXORA <b>2027</b>
              <small>BY INCUX AI</small>
            </span>
          </Link>
          <p className="muted footer-note">
            INNOVATE. BUILD. SOLVE. TRANSFORM.
            <br />
            A premier student hackathon organized by IncuX AI.
          </p>
        </div>
        <div className="footer-links">
          <div>
            <strong>Explore</strong>
            <Link to="/explore">Explore Challenges</Link>
            <Link to="/domains">Domains & Tracks</Link>
            <Link to="/timeline">Timeline</Link>
            <Link to="/prizes">Prizes</Link>
            <Link to="/evaluation">Evaluation</Link>
            <Link to="/about">About AICUXORA</Link>
          </div>
          <div>
            <strong>Participate</strong>
            <Link to="/register">
              Student Registration <ArrowUpRight size={13} />
            </Link>
            <Link to="/login">Sign In</Link>
            <Link to="/rules">Rules & FAQs</Link>
            <Link to="/community">Team Discovery</Link>
            <Link to="/contact">Contact</Link>
            <Link to="/admin">Admin Console</Link>
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} IncuX AI · AICUXORA 2027</span>
        <span>Registration fee and venue to be announced</span>
      </div>
    </footer>
  )
}
